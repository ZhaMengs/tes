import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak ID numerik dari path URL video Bstation
# Contoh: /id/video/2009228331
EPISODE_ID_PATTERN = re.compile(r"/video/(\d+)")

async def extract_episode_id(url: str) -> int:
    """
    Mengekstrak Episode ID (ep_id) dari URL Bstation.
    
    :param url: URL video Bstation.
    :return: Integer Episode ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = EPISODE_ID_PATTERN.search(path)
    if match:
        return int(match.group(1))

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Episode ID dari URL: {url}")
