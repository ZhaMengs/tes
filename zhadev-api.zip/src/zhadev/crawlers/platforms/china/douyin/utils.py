import re
import httpx
from typing import Optional, Dict
from urllib.parse import urlencode

from ....crawlers.exceptions import ContentNotFoundError
from .abogus import ABogus
from .xbogus import XBogus

URL_PATTERN = re.compile(r"https?:\/\/(?:www\.)?douyin\.com\/[a-zA-Z0-9\/-]+")
VIDEO_ID_PATTERN = re.compile(r"/video/(\d{19})")

class BogusManager:
    """
    Mengelola pembuatan signature a_bogus dan X-Bogus.
    """
    def __init__(self, user_agent: str):
        self.user_agent = user_agent
        self.abogus_gen = ABogus(user_agent=self.user_agent)
        self.xbogus_gen = XBogus(user_agent=self.user_agent)

    def sign_params_with_abogus(self, params: Dict) -> Dict:
        """
        Menerima parameter dictionary, menghasilkan a_bogus, dan
        menambahkannya kembali ke dictionary.
        """
        signed_params = params.copy()
        abogus_signature = self.abogus_gen.generate(signed_params)
        signed_params['a_bogus'] = abogus_signature
        return signed_params

    def sign_url_with_xbogus(self, base_url: str, params: Dict) -> str:
        """
        Menerima URL dasar dan parameter, menghasilkan X-Bogus,
        dan mengembalikan URL lengkap yang sudah ditandatangani.
        """
        query_string = urlencode(params)
        full_url = f"{base_url}?{query_string}"
        signed_url, _ = self.xbogus_gen.getXBogus(full_url)
        return signed_url


async def extract_aweme_id(url_or_text: str) -> str:
    """
    Mengekstrak `aweme_id` (ID video/post) dari berbagai format input.
    """
    url_match = URL_PATTERN.search(url_or_text)
    if not url_match:
        raise ContentNotFoundError("Tidak ditemukan URL Douyin yang valid dalam input.")
    url = url_match.group(0)

    id_match = VIDEO_ID_PATTERN.search(url)
    if id_match:
        return id_match.group(1)

    try:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            response = await client.head(url, timeout=15)
            final_url = str(response.url)
            id_match_final = VIDEO_ID_PATTERN.search(final_url)
            if id_match_final:
                return id_match_final.group(1)
            else:
                raise ContentNotFoundError(f"URL final ({final_url}) tidak mengandung aweme_id.")
    except httpx.RequestError as e:
        raise ContentNotFoundError(f"Gagal menghubungi server Douyin untuk memproses URL: {e}")
