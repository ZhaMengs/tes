class DouyinEndpoints:
    """
    Kelas statis untuk menyimpan semua endpoint API Douyin (versi Web).
    Ini membantu dalam mengelola dan memperbarui URL API di satu tempat.
    """
    # Endpoint utama untuk mengambil detail lengkap dari sebuah postingan (video/gambar).
    # Menggunakan `aweme_id` sebagai parameter utama.
    POST_DETAIL: str = "https://www.douyin.com/aweme/v1/web/aweme/detail/"
