from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

# Model untuk endpoint /x/web-interface/view
class OwnerRaw(BaseModel):
    mid: int
    name: str
    face: str

class PageRaw(BaseModel):
    cid: int
    page: int
    part: str
    duration: int

class StatRaw(BaseModel):
    view: int
    danmaku: int
    reply: int
    favorite: int
    coin: int
    share: int
    like: int

class VideoViewDataRaw(BaseModel):
    bvid: str
    aid: int
    title: str
    pubdate: int
    desc: str
    owner: OwnerRaw
    stat: StatRaw
    pages: List[PageRaw]
    pic: str # Cover image

class BilibiliViewRawResponse(BaseModel):
    code: int
    message: str
    data: Optional[VideoViewDataRaw] = None

# Model untuk endpoint /x/player/playurl
class StreamInfoRaw(BaseModel):
    id: int
    base_url: str = Field(..., alias="baseUrl")
    codecs: str
    width: int
    height: int
    frame_rate: str = Field(..., alias="frameRate")
    bandwidth: int

class DashRaw(BaseModel):
    video: Optional[List[StreamInfoRaw]] = None
    audio: Optional[List[StreamInfoRaw]] = None

class PlayUrlDataRaw(BaseModel):
    quality: int
    format: str
    dash: Optional[DashRaw] = None

class BilibiliPlayUrlRawResponse(BaseModel):
    code: int
    message: str
    data: Optional[PlayUrlDataRaw] = None

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    mid: int
    name: str
    avatar_url: str

class StreamInfo(BaseModel):
    quality_id: int
    url: str
    codecs: str
    width: int
    height: int
    frame_rate: str
    bandwidth_kbps: int

class StatisticsInfo(BaseModel):
    views: int
    danmaku: int
    comments: int
    favorites: int
    coins: int
    shares: int
    likes: int

class BilibiliVideoData(BaseModel):
    """Output akhir yang komprehensif dari Bilibili Crawler."""
    status: str = "success"
    platform: str = "bilibili"
    bvid: str
    aid: int
    cid: int
    title: str
    description: str
    cover_url: str
    published_at_timestamp: int
    duration_seconds: int
    author: AuthorInfo
    statistics: StatisticsInfo
    video_streams: List[StreamInfo]
    audio_streams: List[StreamInfo]
