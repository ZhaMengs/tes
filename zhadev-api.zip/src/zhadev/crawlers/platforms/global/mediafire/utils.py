# zhadev/src/zhadev/crawlers/platforms/global/mediafire/utils.py

import re

# Pola Regex untuk menemukan URL unduhan langsung di dalam source code HTML.
# URL ini biasanya mengarah ke domain seperti downloadXXXX.mediafire.com
DIRECT_DOWNLOAD_PATTERN = re.compile(
    r'href\s*=\s*"(https://download\d+\.mediafire\.com/[^"]+)"'
)