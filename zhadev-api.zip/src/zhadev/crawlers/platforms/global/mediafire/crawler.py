# zhadev/src/zhadev/crawlers/platforms/global/mediafire/crawler.py

import os
import yaml
from typing import Any

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .models import MediafireFileData
from .utils import DIRECT_DOWNLOAD_PATTERN

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class MediafireCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk MediaFire yang secara cerdas mengekstrak
    link unduhan langsung dari halaman web.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['mediafire']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_download_data(self, url: str) -> MediafireFileData:
        """
        Metode utama untuk mengambil link unduhan langsung dari URL MediaFire.
        """
        try:
            # 1. Ambil konten HTML dari halaman MediaFire
            html = await self.fetch_text(url)
            
            # 2. Cari link unduhan langsung menggunakan Regex
            match = DIRECT_DOWNLOAD_PATTERN.search(html)
            if not match:
                raise ContentNotFoundError("Tidak dapat menemukan link unduhan langsung. File mungkin telah dihapus atau link tidak valid.")
            
            direct_download_url = match.group(1)
            
            # 3. Parse HTML dengan BeautifulSoup untuk mendapatkan metadata
            soup = BeautifulSoup(html, "html.parser")
            
            return self._parse_metadata(soup, direct_download_url)

        except ContentNotFoundError as e:
            raise e
        except Exception as e:
            raise ParsingError(f"Gagal mem-parsing halaman MediaFire. Struktur web mungkin berubah. Error: {e}")

    def _parse_metadata(self, soup: BeautifulSoup, direct_url: str) -> MediafireFileData:
        """
        Mengekstrak metadata file dari objek BeautifulSoup.
        """
        try:
            # Ekstrak nama file
            file_name_tag = soup.find('div', class_='filename')
            if not file_name_tag:
                raise ParsingError("Elemen nama file tidak ditemukan.")
            file_name = file_name_tag.text.strip()
            
            # Ekstrak detail file (ukuran dan tanggal upload)
            details_list = soup.find('ul', class_='details')
            if not details_list:
                raise ParsingError("Blok detail file tidak ditemukan.")

            list_items = details_list.find_all('li')
            
            # Ukuran file biasanya ada di span pertama
            file_size_tag = list_items[0].find('span')
            file_size = file_size_tag.text.strip() if file_size_tag else "Unknown"

            # Tanggal upload biasanya ada di span kedua
            uploaded_on_tag = list_items[1].find('span')
            uploaded_on = uploaded_on_tag.text.strip() if uploaded_on_tag else "Unknown"
            
            return MediafireFileData(
                file_name=file_name,
                file_size=file_size,
                uploaded_on=uploaded_on,
                direct_download_url=direct_url
            )
        except (AttributeError, IndexError) as e:
            raise ParsingError(f"Gagal mengekstrak metadata dari halaman. Error: {e}")