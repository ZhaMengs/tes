# zhadev/src/zhadev/crawlers/platforms/global/spotify/__init__.py

from .crawler import SpotifyCrawler

__all__ = ["SpotifyCrawler"]