# zhadev/src/zhadev/crawlers/platforms/global/spotify/utils.py

import re
from urllib.parse import urlparse
from typing import Tuple

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak Tipe dan ID dari URL Spotify.
# Contoh: /track/{ID}, /artist/{ID}, /album/{ID}
URL_PATTERN = re.compile(r"/(track|artist|album)/([a-zA-Z0-9]+)")

async def parse_spotify_url(url: str) -> Tuple[str, str]:
    """
    Mem-parsing URL Spotify untuk mendapatkan tipe konten dan ID-nya.
    
    :param url: URL konten Spotify.
    :return: Tuple berisi (tipe, id). Contoh: ('track', '...').
    :raises ContentNotFoundError: Jika format URL tidak valid.
    """
    parsed_url = urlparse(url)
    match = URL_PATTERN.search(parsed_url.path)
    
    if match:
        content_type = match.group(1)
        content_id = match.group(2)
        return content_type, content_id

    raise ContentNotFoundError(f"Format URL Spotify tidak valid atau tidak didukung: {url}")