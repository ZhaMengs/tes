# zhadev/src/zhadev/crawlers/platforms/global/pinterest/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model-model ini dirancang untuk mem-parsing data dari blok JSON yang ter-embed,
# bukan dari API call langsung.
# ==============================================================================

class PinnerInfo(BaseModel):
    """Mewakili informasi pengguna yang membuat Pin."""
    id: str
    username: str
    full_name: str
    avatar_url: str

class MediaURL(BaseModel):
    """Mewakili satu resolusi atau format media."""
    url: str
    width: int
    height: int

class MediaInfo(BaseModel):
    """Mewakili media dari sebuah Pin, bisa berupa gambar atau video."""
    type: str  # 'image' atau 'video'
    original_url: str
    # Untuk gambar, berisi berbagai resolusi
    image_versions: Optional[Dict[str, MediaURL]] = None
    # Untuk video, berisi berbagai kualitas
    video_versions: Optional[Dict[str, MediaURL]] = None

class StatisticsInfo(BaseModel):
    repin_count: int
    comment_count: int

class PinterestPinData(BaseModel):
    """Output akhir yang komprehensif dari Pinterest Crawler."""
    status: str = "success"
    platform: str = "pinterest"
    id: str
    created_at: str
    title: str
    description: str
    pinner: PinnerInfo
    media: MediaInfo
    statistics: StatisticsInfo