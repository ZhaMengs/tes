# zhadev/src/zhadev/crawlers/platforms/global/terabox/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak "share key" dari URL Terabox
# Contoh: /s/1ABCDEFG-HIJKLMNOPQRSTUVWXYZ
SHARE_KEY_PATTERN = re.compile(r"/(?:s|sharing)/([a-zA-Z0-9_-]+)")

async def extract_share_key(url: str) -> str:
    """
    Mengekstrak share key dari URL Terabox.
    
    :param url: URL file Terabox.
    :return: String share key.
    :raises ContentNotFoundError: Jika kunci tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = SHARE_KEY_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Share Key dari URL: {url}")