from typing import Dict

# Regex untuk mengekstrak nomor episode dari judul atau URL
EPISODE_NUMBER_PATTERN = re.compile(r"episode[ -]?(\d+)", re.IGNORECASE)

class LanguageConverter:
    """
    Utilitas untuk mengonversi nama hari dari Bahasa Indonesia ke Bahasa Inggris
    sesuai dengan ID elemen di halaman jadwal Donghub.
    """
    DAY_MAP: Dict[str, str] = {
        "senin": "monday",
        "selasa": "tuesday",
        "rabu": "wednesday",
        "kamis": "thursday",
        "jumat": "friday",
        "sabtu": "saturday",
        "minggu": "sunday",
    }

    @classmethod
    def to_english_day(cls, day_in_indonesian: str) -> str:
        """Mengonversi nama hari ke Bahasa Inggris (lowercase)."""
        return cls.DAY_MAP.get(day_in_indonesian.lower(), day_in_indonesian.lower())

def extract_episode_number(text: str) -> Optional[int]:
    """Mengekstrak angka episode dari string."""
    match = EPISODE_NUMBER_PATTERN.search(text)
    if match:
        return int(match.group(1))
    return None
