class DonghubEndpoints:
    """
    Menyimpan endpoint dan path untuk Donghub.
    """
    BASE_URL: str = "https://donghub.vip"
    SEARCH_PATH: str = "/" # Pencarian dilakukan dari root dengan parameter `s`
    SCHEDULE_PATH: str = "/schedule"
