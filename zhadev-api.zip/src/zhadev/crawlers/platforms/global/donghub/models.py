from typing import List, Optional, Dict

# ==============================================================================
# Model untuk Berbagai Fungsi Crawler
# ==============================================================================

class DonghuaSearchResult(BaseModel):
    """Mewakili satu item hasil pencarian."""
    title: str
    url: str
    cover_url: str

class EpisodeInfo(BaseModel):
    """Mewakili satu episode dalam daftar di halaman info."""
    episode_title: str
    episode_url: str
    episode_number: Optional[int] = None

class DonghuaInfo(BaseModel):
    """Mewakili data lengkap dari halaman info sebuah Donghua."""
    english_title: str
    china_title: Optional[str] = None
    cover_url: str
    details: Dict[str, str] # Untuk Status, Network, Studio, dll.
    synopsis: Dict[str, str] # Kunci: "english", "indonesia"
    episodes: List[EpisodeInfo]

class DonghuaScheduleItem(BaseModel):
    """Mewakili satu item dalam jadwal harian."""
    title: str
    url: str
    cover_url: str
    day: str
