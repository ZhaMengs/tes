# zhadev/src/zhadev/crawlers/platforms/global/threads/crawler.py

import os
import re
import json
import yaml
from typing import Any, Dict, List

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .models import ThreadsPostData, AuthorInfo, MediaInfo, StatisticsInfo
from .utils import extract_post_shortcode

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class ThreadsCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Threads. Bekerja dengan mengekstrak
    blok data JSON dari sumber halaman untuk mendapatkan data yang akurat.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['threads']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_post_data(self, url: str) -> ThreadsPostData:
        """
        Metode utama untuk mengambil data postingan dari URL Threads.
        """
        shortcode = await extract_post_shortcode(url)
        
        # 1. Ambil konten HTML halaman
        html = await self.fetch_text(url)
        
        # 2. Cari data JSON yang ter-embed di dalam HTML.
        # Data ini biasanya ada di dalam tag <script> yang mengandung "ScheduledServerJS".
        # Kita gunakan regex untuk menemukan objek JSON yang relevan.
        json_match = re.search(r'{"props":{"response":.*?}}', html)
        if not json_match:
            raise ParsingError("Tidak dapat menemukan blok data JSON. Struktur halaman Threads mungkin berubah.")
            
        try:
            # 3. Parse JSON dan navigasi ke data postingan yang relevan
            full_data = json.loads(json_match.group(0))
            # Jalur navigasi bisa sangat dalam dan spesifik
            post_data_raw = full_data['props']['response']['data']['data']['post']
            thread_items = post_data_raw['thread_items'][0]
            post_info = thread_items['post']
            
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            raise ParsingError(f"Gagal mem-parsing atau menavigasi data JSON. Mungkin postingan tidak tersedia atau privat. Error: {e}")

        # 4. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(post_info, shortcode, url)

    def _transform_to_clean_data(self, raw_post: Dict[str, Any], shortcode: str, url: str) -> ThreadsPostData:
        """
        Mengubah dictionary data mentah dari JSON menjadi model Pydantic yang bersih.
        """
        user_raw = raw_post['user']
        author_info = AuthorInfo(
            id=user_raw['id'],
            username=user_raw['username'],
            profile_pic_url=user_raw['profile_pic_url'],
            is_verified=user_raw['is_verified']
        )
        
        caption_text = raw_post['caption']['text'] if raw_post.get('caption') else ""

        media_list: List[MediaInfo] = []
        # Cek untuk postingan carousel (album)
        if 'carousel_media' in raw_post and raw_post['carousel_media']:
            for media in raw_post['carousel_media']:
                media_list.append(self._parse_media_item(media))
        # Postingan tunggal (gambar atau video)
        else:
            media_list.append(self._parse_media_item(raw_post))
            
        stats_info = StatisticsInfo(
            like_count=raw_post.get('like_count', 0),
            reply_count=thread_items.get('view_replies_count', 0)
        )

        return ThreadsPostData(
            id=raw_post['pk'],
            shortcode=shortcode,
            url=url,
            caption=caption_text,
            published_at_timestamp=raw_post['taken_at'],
            author=author_info,
            media=media_list,
            statistics=stats_info
        )
    
    def _parse_media_item(self, media_data: Dict[str, Any]) -> MediaInfo:
        """Helper untuk mem-parsing satu item media (gambar atau video)."""
        is_video = 'video_versions' in media_data and media_data['video_versions']
        
        if is_video:
            # Ambil video dengan kualitas terbaik (biasanya yang pertama)
            best_video = media_data['video_versions'][0]
            return MediaInfo(
                type='video',
                display_url=media_data['image_versions2']['candidates'][0]['url'],
                video_url=best_video['url'],
                width=best_video['width'],
                height=best_video['height']
            )
        else: # Ini adalah gambar
            # Ambil gambar dengan kualitas terbaik (biasanya yang pertama)
            best_image = media_data['image_versions2']['candidates'][0]
            return MediaInfo(
                type='image',
                display_url=best_image['url'],
                video_url=None,
                width=best_image['width'],
                height=best_image['height']
            )