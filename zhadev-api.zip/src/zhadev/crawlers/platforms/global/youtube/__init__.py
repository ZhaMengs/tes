# zhadev/src/zhadev/crawlers/platforms/global/youtube/__init__.py

from .crawler import YouTubeCrawler

__all__ = ["YouTubeCrawler"]