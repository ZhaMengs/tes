"""
ZhaDev Crawlers Package
Comprehensive web crawlers for various platforms.
"""

# Base classes
from .base_crawler import BaseCrawler

# Exceptions - sesuai dengan file exceptions.py Anda
from .exceptions import (
    CrawlerError, NetworkError, APIError, 
    AuthenticationError, ContentNotFoundError, ParsingError
)

# Platform-specific crawlers - hanya export yang sudah ada
# China platforms
from .platforms.china.bstation.crawler import BstationCrawler
from .platforms.china.bstation.models import BstationVideoData

# Tambahkan platform lain yang sudah ada di sini
from .platforms.china.bilibili.crawler import BilibiliCrawler
from .platforms.china.bilibili.models import BilibiliVideoData
from .platforms.china.douyin.crawler import DouyinCrawler  
from .platforms.china.douyin.models import DouyinVideoData
from .platforms.china.weibo.crawler import WeiboCrawler
from .platforms.china.weibo.models import WeiboVideoData
from .platforms.china.xiaohongshu.crawler import XiaohongshuCrawler
from .platforms.china.xiaohongshu.models import XiaohongshuVideoData

# Global platforms  
from .platforms.global.youtube.crawler import YoutubeCrawler
from .platforms.global.youtube.models import YoutubeVideoData
from .platforms.global.tiktok.crawler import TiktokCrawler
from .platforms.global.tiktok.models import TiktokVideoData
from .platforms.global.instagram.crawler import InstagramCrawler
from .platforms.global.instagram.models import InstagramVideoData
from .platforms.global.twitter.crawler import TwitterCrawler
from .platforms.global.twitter.models import TwitterVideoData
from .platforms.global.facebook.crawler import FacebookCrawler
from .platforms.global.facebook.models import FacebookVideoData
from .platforms.global.spotify.crawler import SpotifyCrawler
from .platforms.global.spotify.models import SpotifyAudioData
from .platforms.global.pinterest.crawler import PinterestCrawler
from .platforms.global.pinterest.models import PinterestVideoData
from .platforms.global.github.crawler import GithubCrawler
from .platforms.global.github.models import GithubRepoData
from .platforms.global.dailymotion.crawler import DailymotionCrawler
from .platforms.global.dailymotion.models import DailymotionVideoData
from .platforms.global.mediafire.crawler import MediafireCrawler
from .platforms.global.mediafire.models import MediafireFileData
from .platforms.global.pixeldrain.crawler import PixeldrainCrawler
from .platforms.global.pixeldrain.models import PixeldrainFileData
from .platforms.global.snackvideo.crawler import SnackvideoCrawler
from .platforms.global.snackvideo.models import SnackvideoVideoData
from .platforms.global.terabox.crawler import TeraboxCrawler
from .platforms.global.terabox.models import TeraboxFileData
from .platforms.global.threads.crawler import ThreadsCrawler
from .platforms.global.threads.models import ThreadsVideoData
from .platforms.global.gdrive.crawler import GdriveCrawler
from .platforms.global.gdrive.models import GdriveFileData
from .platforms.global.capcut.crawler import CapcutCrawler
from .platforms.global.capcut.models import CapcutVideoData
from .platforms.global.donghub.crawler import DonghubCrawler
from .platforms.global.donghub.models import DonghubVideoData

# Export all yang sudah di-uncomment di atas
__all__ = [
    # Base
    'BaseCrawler',
    
    # Exceptions
    'CrawlerError', 'NetworkError', 'APIError', 
    'AuthenticationError', 'ContentNotFoundError', 'ParsingError',
    
    # China Platforms - hanya yang sudah ada
    'BstationCrawler', 'BstationVideoData',
    
    # Global Platforms - uncomment ketika crawler sudah dibuat
    'BilibiliCrawler', 'BilibiliVideoData',
    'DouyinCrawler', 'DouyinVideoData',
    'WeiboCrawler', 'WeiboVideoData', 
    'XiaohongshuCrawler', 'XiaohongshuVideoData',
    'YoutubeCrawler', 'YoutubeVideoData',
    'TiktokCrawler', 'TiktokVideoData',
    'InstagramCrawler', 'InstagramVideoData',
    'TwitterCrawler', 'TwitterVideoData',
    'FacebookCrawler', 'FacebookVideoData',
    'SpotifyCrawler', 'SpotifyAudioData',
    'PinterestCrawler', 'PinterestVideoData',
    'GithubCrawler', 'GithubRepoData',
    'DailymotionCrawler', 'DailymotionVideoData',
    'MediafireCrawler', 'MediafireFileData',
    'PixeldrainCrawler', 'PixeldrainFileData',
    'SnackvideoCrawler', 'SnackvideoVideoData',
    'TeraboxCrawler', 'TeraboxFileData',
    'ThreadsCrawler', 'ThreadsVideoData',
    'GdriveCrawler', 'GdriveFileData',
    'CapcutCrawler', 'CapcutVideoData',
    'DonghubCrawler', 'DonghubVideoData',
]