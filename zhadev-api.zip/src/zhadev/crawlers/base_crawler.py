# zhadev/src/zhadev/crawlers/base_crawler.py

import httpx
import logging
from typing import Optional, Dict, Any

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from .exceptions import APIError, NetworkError, AuthenticationError, ContentNotFoundError

# Konfigurasi logging dasar untuk crawler
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class BaseCrawler:
    """
    BaseCrawler yang disempurnakan dengan retry otomatis, logging,
    dan penanganan exception yang detail.
    """
    def __init__(
        self,
        headers: Optional[Dict[str, str]] = None,
        proxies: Optional[Dict[str, Any]] = None,
        timeout: int = 20,
        retries: int = 3
    ):
        self._base_headers = headers or {}
        self._proxies = proxies
        self._timeout = timeout
        self._retries = retries
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Inisialisasi atau kembalikan instance AsyncClient yang ada."""
        if self._client is None or self._client.is_closed:
            logger.info("Menginisialisasi instance httpx.AsyncClient baru.")
            self._client = httpx.AsyncClient(
                headers=self._base_headers,
                proxies=self._proxies,
                timeout=self._timeout,
                follow_redirects=True,
            )
        return self._client

    @retry(
        stop=stop_after_attempt(3),  # Coba maksimal 3 kali
        wait=wait_exponential(multiplier=1, min=2, max=10),  # Waktu tunggu eksponensial
        retry=retry_if_exception_type(NetworkError),  # Hanya retry jika NetworkError
        before_sleep=lambda retry_state: logger.warning(
            f"Percobaan ulang ke-{retry_state.attempt_number} karena NetworkError: {retry_state.outcome.exception()}"
        )
    )
    async def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """Metode inti untuk semua permintaan HTTP, dilengkapi dengan retry dan error handling."""
        client = await self._get_client()
        logger.info(f"Memulai permintaan {method} ke: {url}")
        
        try:
            response = await client.request(method, url, **kwargs)
            response.raise_for_status()
            logger.info(f"Permintaan berhasil (Status: {response.status_code}) ke: {url}")
            return response
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            message = f"HTTP Error saat mengakses {e.request.url}"
            logger.error(f"{message} (Status: {status})")
            if status in [401, 403]:
                raise AuthenticationError(message, status, e.response.text) from e
            if status == 404:
                raise ContentNotFoundError(message, status, e.response.text) from e
            raise APIError(message, status, e.response.text) from e
        except httpx.RequestError as e:
            message = f"Masalah jaringan saat mengakses {e.request.url}"
            logger.error(f"{message}: {e}")
            raise NetworkError(message) from e

    async def fetch_json(self, url: str, **kwargs) -> Any:
        """Melakukan GET request dan mengembalikan respons JSON."""
        response = await self._request("GET", url, **kwargs)
        return response.json()

    async def fetch_text(self, url: str, **kwargs) -> str:
        """Melakukan GET request dan mengembalikan respons teks (HTML)."""
        response = await self._request("GET", url, **kwargs)
        return response.text

    async def post_json(self, url: str, **kwargs) -> Any:
        """Melakukan POST request dan mengembalikan respons JSON."""
        response = await self._request("POST", url, **kwargs)
        return response.json()

    async def close(self):
        """Menutup sesi AsyncClient jika ada."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            logger.info("Sesi httpx.AsyncClient telah ditutup.")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()