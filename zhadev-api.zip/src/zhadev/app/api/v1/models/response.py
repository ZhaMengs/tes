# /zhadev/app/api/v1/models/response.py

from pydantic import BaseModel, Field
from typing import Any, Generic, TypeVar, Optional

# T adalah generic TypeVar, memungkinkan kita menggunakan model ini untuk
# tipe data apa pun (contoh: StandardResponse[DouyinVideoData]).
T = TypeVar('T')

class StandardResponse(BaseModel, Generic[T]):
    """
    Model respons standar untuk semua panggilan API yang berhasil.
    Menggunakan generic type untuk fleksibilitas data.
    """
    status: str = "success"
    execution_time_ms: Optional[float] = Field(None, description="Waktu eksekusi permintaan dalam milidetik.")
    data: Optional[T] = None

class ErrorResponse(BaseModel):
    """
    Model respons standar untuk semua panggilan API yang gagal.
    """
    status: str = "error"
    message: str
    detail: Optional[Any] = Field(None, description="Detail teknis dari error (opsional).")