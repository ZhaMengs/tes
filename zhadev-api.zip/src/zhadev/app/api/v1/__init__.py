# /zhadev/app/api/__init__.py

from .router import api_v1_router

# Mengekspos router utama V1 agar mudah diimpor oleh file main.py
__all__ = ["api_v1_router"]