# /zhadev/app/api/v1/downloader/xiaohongshu.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import XiaohongshuCrawler, XiaohongshuNoteData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[XiaohongshuNoteData],
    responses={
        404: {"model": ErrorResponse, "description": "Postingan tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data postingan (Note) dari Xiaohongshu",
    description="Masukkan URL postingan Xiaohongshu untuk mendapatkan metadata lengkap dan link unduhan media."
)
async def get_xiaohongshu_data(
    url: str = Query(..., description="URL lengkap postingan dari xiaohongshu.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi postingan dari Xiaohongshu.
    """
    start_time = time.time()
    
    try:
        async with XiaohongshuCrawler() as crawler:
            data = await crawler.get_note_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")