# /zhadev/app/api/v1/downloader/instagram.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import InstagramCrawler, InstagramPostData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[InstagramPostData],
    responses={
        403: {"model": ErrorResponse, "description": "Crawler tidak dikonfigurasi dengan benar (cookie `sessionid` hilang)."},
        404: {"model": ErrorResponse, "description": "Postingan tidak ditemukan, bersifat privat, atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data postingan dari Instagram (Wajib Cookie)",
    description="Masukkan URL postingan Instagram untuk mendapatkan metadata lengkap dan link unduhan media (gambar/video). Memerlukan `sessionid` yang valid di konfigurasi crawler."
)
async def get_instagram_data(
    url: str = Query(..., description="URL lengkap postingan dari instagram.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi postingan dari Instagram.
    """
    start_time = time.time()
    
    try:
        async with InstagramCrawler() as crawler:
            data = await crawler.get_post_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlingError as e:
        # Menangkap error jika cookie tidak ada
        if "wajib ada" in str(e):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")