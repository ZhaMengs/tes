# /zhadev/app/api/v1/downloader/twitter.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import TwitterCrawler, TwitterTweetData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[TwitterTweetData],
    responses={
        403: {"model": ErrorResponse, "description": "Crawler tidak dikonfigurasi dengan benar (cookie `auth_token` hilang)."},
        404: {"model": ErrorResponse, "description": "Tweet tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data Tweet dari Twitter/X (Wajib Cookie)",
    description="Masukkan URL Tweet untuk mendapatkan metadata lengkap dan link unduhan media. Memerlukan `auth_token` dan `ct0` yang valid di konfigurasi crawler."
)
async def get_twitter_data(
    url: str = Query(..., description="URL lengkap Tweet dari twitter.com atau x.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi Tweet dari Twitter/X.
    """
    start_time = time.time()
    
    try:
        async with TwitterCrawler() as crawler:
            data = await crawler.get_tweet_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlingError as e:
        # Menangkap error jika cookie tidak ada
        if "wajib diisi" in str(e):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")