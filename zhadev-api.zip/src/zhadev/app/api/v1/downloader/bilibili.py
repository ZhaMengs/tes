# /zhadev/app/api/v1/downloader/bilibili.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BilibiliCrawler, BilibiliVideoData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[BilibiliVideoData],
    responses={
        404: {"model": ErrorResponse, "description": "Konten tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data video dari Bilibili (bilibili.com)",
    description="Masukkan URL video Bilibili (termasuk b23.tv) untuk mendapatkan metadata lengkap dan link unduhan stream."
)
async def get_bilibili_data(
    url: str = Query(..., description="URL lengkap video dari bilibili.com atau b23.tv."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi video dari Bilibili.
    """
    start_time = time.time()
    
    try:
        async with BilibiliCrawler() as crawler:
            data = await crawler.get_video_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")