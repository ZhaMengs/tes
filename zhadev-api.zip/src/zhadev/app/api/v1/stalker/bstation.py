# /zhadev/app/api/v1/stalker/bstation.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
# Asumsi crawler Bstation memiliki method get_user_info
from src.zhadev.crawlers import BstationCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk data profil pengguna Bstation
class BstationProfileData(BaseModel):
    mid: int
    name: str
    avatar_url: str
    follower_count: int
    following_count: int
    description: str

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[BstationProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Bstation (bilibili.tv)",
    description="Masukkan URL profil pengguna Bstation untuk mendapatkan informasi detail."
)
async def get_bstation_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari bilibili.tv."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Bstation.
    """
    start_time = time.time()
    
    try:
        async with BstationCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")