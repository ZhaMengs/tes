# /zhadev/app/api/v1/stalker/bilibili.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BilibiliCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk data profil pengguna Bilibili
class BilibiliProfileData(BaseModel):
    mid: int
    name: str
    avatar_url: str
    sign: str
    level: int
    follower_count: int
    following_count: int

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[BilibiliProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Bilibili (bilibili.com)",
    description="Masukkan URL profil pengguna Bilibili untuk mendapatkan informasi detail."
)
async def get_bilibili_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari space.bilibili.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Bilibili.
    """
    start_time = time.time()
    
    try:
        async with BilibiliCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")