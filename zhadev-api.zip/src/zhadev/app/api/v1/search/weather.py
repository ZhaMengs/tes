# /zhadev/app/api/v1/search/weather.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel
from typing import List, Dict

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BaseCrawler, CrawlerError
from ....core.config import settings

class WeatherInfo(BaseModel):
    main: str
    description: str
    icon: str

class WeatherData(BaseModel):
    city_name: str
    country: str
    temperature_celsius: float
    feels_like_celsius: float
    pressure_hpa: int
    humidity_percent: int
    visibility_meters: int
    wind_speed_mps: float
    weather: List[WeatherInfo]

router = APIRouter()
WEATHER_API_URL = "http://googleusercontent.com/openweathermap.org/0"

@router.get(
    "/",
    response_model=StandardResponse[WeatherData],
    responses={404: {"model": ErrorResponse}, 503: {"model": ErrorResponse}},
    summary="Mendapatkan data cuaca terkini untuk sebuah kota",
)
async def get_weather(
    city: str = Query(..., description="Nama kota, contoh: 'Jakarta', 'Tokyo', 'London'."),
    api_key: str = Depends(validate_api_key)
):
    """
    Mengambil data cuaca dari OpenWeatherMap API.
    """
    start_time = time.time()
    owm_key = settings.OPENWEATHER_API_KEY
    if not owm_key:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan cuaca tidak dikonfigurasi di server.")

    params = {"q": city, "appid": owm_key, "units": "metric"}
    try:
        async with BaseCrawler() as crawler:
            data = await crawler.fetch_json(WEATHER_API_URL, params=params)
        
        # Transformasi data mentah ke model yang bersih
        result = WeatherData(
            city_name=data['name'],
            country=data['sys']['country'],
            temperature_celsius=data['main']['temp'],
            feels_like_celsius=data['main']['feels_like'],
            pressure_hpa=data['main']['pressure'],
            humidity_percent=data['main']['humidity'],
            visibility_meters=data['visibility'],
            wind_speed_mps=data['wind']['speed'],
            weather=[WeatherInfo(**w) for w in data['weather']]
        )
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)
        
    except APIError as e:
        if e.status_code == 404:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Kota '{city}' tidak ditemukan.")
        raise HTTPException(status_code=e.status_code, detail=f"Error dari API cuaca: {e.response_text}")
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menghubungi API cuaca: {e}")