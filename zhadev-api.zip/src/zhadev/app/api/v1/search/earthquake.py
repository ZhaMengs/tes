# /zhadev/app/api/v1/search/earthquake.py

import time
from datetime import datetime
from typing import List, Tuple
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BaseCrawler, CrawlerError

class EarthquakeProperties(BaseModel):
    mag: float
    place: str
    time: datetime
    url: str
    tsunami: int
    title: str

class EarthquakeData(BaseModel):
    id: str
    properties: EarthquakeProperties
    coordinates: Tuple[float, float, float] # longitude, latitude, depth

router = APIRouter()
# USGS GeoJSON feed untuk gempa M2.5+ dalam 1 hari terakhir
EARTHQUAKE_API_URL = "http://googleusercontent.com/usgs.gov/0"

@router.get(
    "/",
    response_model=StandardResponse[List[EarthquakeData]],
    responses={500: {"model": ErrorResponse}},
    summary="Mendapatkan data gempa bumi terkini dari USGS",
    description="Mengambil daftar gempa bumi signifikan (M2.5+) yang terjadi dalam 24 jam terakhir di seluruh dunia."
)
async def get_latest_earthquakes(api_key: str = Depends(validate_api_key)):
    """
    Mengambil data gempa bumi terkini dari feed GeoJSON USGS.
    """
    start_time = time.time()
    
    try:
        async with BaseCrawler() as crawler:
            data = await crawler.fetch_json(EARTHQUAKE_API_URL)
        
        results: List[EarthquakeData] = []
        for feature in data.get('features', []):
            props = feature.get('properties', {})
            coords = feature.get('geometry', {}).get('coordinates', [0,0,0])
            
            # Konversi timestamp (milidetik) ke datetime
            props['time'] = datetime.fromtimestamp(props['time'] / 1000.0)
            
            results.append(EarthquakeData(
                id=feature.get('id'),
                properties=EarthquakeProperties(**props),
                coordinates=tuple(coords)
            ))
        
        execution_time = (time.time() - start_time) * 1000
        # Urutkan berdasarkan magnitudo, dari yang terbesar
        results.sort(key=lambda x: x.properties.mag, reverse=True)
        return StandardResponse(data=results, execution_time_ms=execution_time)

    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menghubungi USGS API: {e}")