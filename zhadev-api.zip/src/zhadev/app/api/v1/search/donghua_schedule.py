# /zhadev/app/api/v1/search/donghua_schedule.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import DonghubCrawler, DonghuaScheduleItem, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[DonghuaScheduleItem]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mendapatkan jadwal rilis donghua mingguan dari Donghub",
    description="Filter berdasarkan hari dalam Bahasa Indonesia (Senin, Selasa, dst)."
)
async def get_donghua_schedule(
    day: str = Query(..., description="Nama hari dalam Bahasa Indonesia (case-insensitive)."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mendapatkan jadwal rilis Donghua dari Donghub.vip/schedule.
    """
    start_time = time.time()
    
    try:
        async with DonghubCrawler() as crawler:
            # Panggil method get_schedule yang sudah kita definisikan di crawler Donghub
            data = await crawler.get_schedule(day)
            if not data:
                raise ContentNotFoundError(f"Tidak ada jadwal yang ditemukan untuk hari '{day}'.")

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")