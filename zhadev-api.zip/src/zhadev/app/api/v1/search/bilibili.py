# /zhadev/app/api/v1/search/bilibili.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BilibiliCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk hasil pencarian Bilibili
class BilibiliSearchResult(BaseModel):
    title: str # Judul bisa mengandung tag HTML <em class="keyword">
    url: str
    cover_url: str
    author: str
    duration: str # format "MM:SS"
    play_count: int
    danmaku_count: int

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[BilibiliSearchResult]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mencari video di Bilibili (bilibili.com)",
    description="Masukkan query pencarian untuk mendapatkan daftar video yang relevan."
)
async def search_bilibili(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian di Bilibili.
    """
    start_time = time.time()
    
    try:
        async with BilibiliCrawler() as crawler:
          
            data = await crawler.search(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")