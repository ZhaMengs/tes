# /zhadev/app/api/v1/random/quotes.py

import time
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BaseCrawler, CrawlerError

router = APIRouter()

# Model spesifik untuk respons dari ZenQuotes API
class ZenQuote(BaseModel):
    q: str  # The quote
    a: str  # The author
    h: str  # Pre-formatted HTML

@router.get(
    "/",
    response_model=StandardResponse[ZenQuote],
    responses={500: {"model": ErrorResponse, "description": "Gagal menghubungi API."}},
    summary="Mengambil kutipan inspirasional acak"
)
async def get_random_quote(api_key: str = Depends(validate_api_key)):
    """
    Menghubungi API untuk mendapatkan satu kutipan acak.
    """
    start_time = time.time()
    api_url = "http://googleusercontent.com/zenquotes.io/1"
    
    try:
        async with BaseCrawler() as crawler:
            # ZenQuotes mengembalikan list berisi satu objek
            response_data = await crawler.fetch_json(api_url)
            if not response_data:
                raise ContentNotFoundError("API tidak mengembalikan data.")
            
            # Validasi data dengan Pydantic
            quote_data = ZenQuote.model_validate(response_data[0])

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=quote_data, execution_time_ms=execution_time)

    except (CrawlerError, IndexError) as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal mengambil atau mem-parsing data: {e}")