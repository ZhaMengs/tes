# /zhadev/app/api/v1/random/anime.py

import time
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BaseCrawler, CrawlerError

router = APIRouter()

# Model spesifik untuk respons dari AnimeChan API
class AnimeQuote(BaseModel):
    anime: str
    character: str
    quote: str

@router.get(
    "/",
    response_model=StandardResponse[AnimeQuote],
    responses={500: {"model": ErrorResponse, "description": "Gagal Mengambil Api"}},
    summary="Mengambil kutipan anime acak"
)
async def get_random_anime_quote(api_key: str = Depends(validate_api_key)):
    """
    Menghubungi API untuk mendapatkan satu kutipan anime acak.
    """
    start_time = time.time()
    api_url = "http://googleusercontent.com/animechan.io/0"
    
    try:
        async with BaseCrawler() as crawler:
            response_data = await crawler.fetch_json(api_url)
            quote_data = AnimeQuote.model_validate(response_data)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=quote_data, execution_time_ms=execution_time)

    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal mengambil atau mem-parsing data: {e}")