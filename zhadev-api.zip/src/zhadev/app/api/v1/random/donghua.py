# /zhadev/app/api/v1/random/donghua.py

import time
import random
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from bs4 import BeautifulSoup

from ..models import StandardResponse, ErrorResponse, validate_api_key
from src.zhadev.crawlers import BaseCrawler, CrawlerError, ParsingError, ContentNotFoundError

router = APIRouter()

# Target situs. Menggunakan situs arsip yang lebih sederhana lebih andal.
# Qidian asli sangat dilindungi.
NOVEL_LIST_URL = "https://www.wuxiaworld.com/novels" # Contoh: Wuxiaworld

class DonghuaQuote(BaseModel):
    source_novel: str
    source_chapter_url: str
    quote_text: str

@router.get(
    "/",
    response_model=StandardResponse[DonghuaQuote],
    responses={
        404: {"model": ErrorResponse, "description": "Gagal menemukan konten (novel/chapter)."},
        500: {"model": ErrorResponse, "description": "Gagal mem-parsing halaman web."}
    },
    summary="Mengambil kutipan acak dari novel China (Donghua)"
)
async def get_random_donghua_quote(api_key: str = Depends(validate_api_key)):
    """
    Endpoint kompleks yang melakukan scraping multi-langkah:
    1. Mengambil daftar novel.
    2. Memilih novel acak.
    3. Mengambil daftar chapter dari novel tersebut.
    4. Memilih chapter acak.
    5. Mengambil paragraf acak dari chapter sebagai 'kutipan'.
    """
    start_time = time.time()
    
    try:
        async with BaseCrawler() as crawler:
            # --- Langkah 1: Ambil daftar novel ---
            console.log("Langkah 1: Mengambil daftar novel...")
            novel_list_html = await crawler.fetch_text(NOVEL_LIST_URL)
            soup = BeautifulSoup(novel_list_html, "html.parser")
            novel_links = soup.select("div.novel-item a.novel-name")
            if not novel_links:
                raise ParsingError("Tidak dapat menemukan link novel di halaman daftar.")
            
            # --- Langkah 2: Pilih novel acak dan dapatkan URL-nya ---
            random_novel_tag = random.choice(novel_links)
            novel_title = random_novel_tag.get_text(strip=True)
            novel_url = random_novel_tag['href']
            if not novel_url.startswith("http"):
                novel_url = "https://www.wuxiaworld.com" + novel_url
            
            # --- Langkah 3: Ambil daftar chapter ---
            console.log(f"Langkah 2: Mengambil chapter dari '{novel_title}'...")
            chapter_list_html = await crawler.fetch_text(novel_url)
            soup = BeautifulSoup(chapter_list_html, "html.parser")
            chapter_links = soup.select("li.chapter-item a")
            if not chapter_links:
                raise ParsingError("Tidak dapat menemukan link chapter di halaman novel.")
            
            # --- Langkah 4: Pilih chapter acak ---
            random_chapter_tag = random.choice(chapter_links)
            chapter_url = random_chapter_tag['href']
            if not chapter_url.startswith("http"):
                chapter_url = "https://www.wuxiaworld.com" + chapter_url
            
            # --- Langkah 5: Ambil konten chapter ---
            console.log("Langkah 3: Mengambil konten dari chapter acak...")
            chapter_html = await crawler.fetch_text(chapter_url)
            soup = BeautifulSoup(chapter_html, "html.parser")
            content_div = soup.find("div", id="chapter-content")
            if not content_div:
                raise ParsingError("Tidak dapat menemukan div konten chapter.")
            
            # --- Langkah 6: Ekstrak paragraf acak sebagai 'kutipan' ---
            paragraphs = content_div.find_all("p")
            # Filter paragraf yang terlalu pendek atau tidak berisi teks
            valid_paragraphs = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 50]
            if not valid_paragraphs:
                raise ContentNotFoundError("Tidak ada paragraf yang cocok untuk dijadikan kutipan di chapter ini.")
            
            quote_text = random.choice(valid_paragraphs)
            
            # --- Finalisasi ---
            result = DonghuaQuote(
                source_novel=novel_title,
                source_chapter_url=chapter_url,
                quote_text=quote_text
            )
            
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except (ContentNotFoundError, ParsingError, CrawlerError) as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Proses scraping gagal: {e}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal tak terduga: {str(e)}")