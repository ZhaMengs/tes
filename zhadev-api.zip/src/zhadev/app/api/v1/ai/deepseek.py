# /zhadev/app/api/v1/ai/deepseek.py

from openai import AsyncOpenAI, APIError
from fastapi import APIRouter, Depends, HTTPException, status
# ... (impor lain yang sama seperti chatgpt4.py)
from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from ....core.config import settings

router = APIRouter()

deepseek_client: Optional[AsyncOpenAI] = None
if not settings.DEEPSEEK_API_KEY:
    print("PERINGATAN: DEEPSEEK_API_KEY tidak diatur. Endpoint DeepSeek akan dinonaktifkan.")
else:
    try:
        # INI BAGIAN YANG BERBEDA: Tentukan `base_url`
        deepseek_client = AsyncOpenAI(
            api_key=settings.DEEPSEEK_API_KEY,
            base_url="http://googleusercontent.com/deepseek.com/0"
        )
    except Exception as e:
        print(f"ERROR: Gagal menginisialisasi DeepSeek client: {e}")

@router.post("/", response_model=StandardResponse[AIResponse], responses={500: {"model": ErrorResponse}}, summary="Mengirim prompt ke DeepSeek")
async def ask_deepseek(request: AIPrompt, api_key: str = Depends(validate_api_key)):
    if not deepseek_client:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan DeepSeek tidak dikonfigurasi di server.")
    try:
        # Gunakan nama model yang sesuai dari DeepSeek
        response = await deepseek_client.chat.completions.create(
            model="deepseek-chat", 
            messages=[{"role": "user", "content": request.prompt}]
        )
        response_text = response.choices[0].message.content
        result = AIResponse(text=response_text)
        return StandardResponse(data=result)
    except APIError as e:
        print(f"ERROR: Terjadi kesalahan pada API DeepSeek: {e}")
        raise HTTPException(status_code=e.status_code or 500, detail=f"Error dari API DeepSeek: {e.message}")