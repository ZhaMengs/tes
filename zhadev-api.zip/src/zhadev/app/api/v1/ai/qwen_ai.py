# /zhadev/app/api/v1/ai/qwen_ai.py

import httpx
import json
from fastapi import APIRouter, Depends, HTTPException, status
from ....core.config import settings
from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from typing import Optional, Dict, Any

router = APIRouter()

class QwenAIClient:
    def __init__(self):
        self.api_key = getattr(settings, 'QWEN_API_KEY', None)
        self.base_url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
        self.client = None
        self.available_models = {
            "qwen-turbo": "qwen-turbo",
            "qwen-plus": "qwen-plus", 
            "qwen-max": "qwen-max",
            "qwen-long": "qwen-long"
        }
        
    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()
            
    async def generate_response(self, prompt: str, model: str = "qwen-turbo", **kwargs) -> Dict[str, Any]:
        """Generate response menggunakan DashScope API"""
        if not self.api_key:
            raise Exception("QWEN_API_KEY tidak dikonfigurasi")
            
        if model not in self.available_models:
            model = "qwen-turbo"  # Fallback ke model default
            
        payload = {
            "model": model,
            "input": {
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            },
            "parameters": {
                "result_format": "message",
                **kwargs
            }
        }
        
        try:
            response = await self.client.post(
                self.base_url,
                json=payload
            )
            
            if response.status_code == 200:
                data = response.json()
                return self._parse_response(data)
            else:
                error_msg = f"API Error: {response.status_code} - {response.text}"
                raise Exception(error_msg)
                
        except Exception as e:
            raise Exception(f"Qwen API request failed: {str(e)}")
            
    def _parse_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse response dari DashScope API"""
        try:
            if "output" in data and "choices" in data["output"]:
                choices = data["output"]["choices"]
                if choices and len(choices) > 0:
                    message = choices[0]["message"]
                    return {
                        "text": message.get("content", ""),
                        "role": message.get("role", "assistant"),
                        "usage": data.get("usage", {}),
                        "request_id": data.get("request_id", "")
                    }
            
            raise Exception("Invalid response format from Qwen API")
            
        except Exception as e:
            raise Exception(f"Failed to parse Qwen response: {str(e)}")

# Global client instance
qwen_client: Optional[QwenAIClient] = None

if not getattr(settings, 'QWEN_API_KEY', None):
    print("PERINGATAN: QWEN_API_KEY tidak diatur. Endpoint Qwen akan dinonaktifkan.")
else:
    try:
        qwen_client = QwenAIClient()
        print("SUKSES: Qwen AI client berhasil diinisialisasi dengan DashScope API")
    except Exception as e:
        print(f"ERROR: Gagal menginisialisasi Qwen AI client: {e}")

@router.post("/", 
             response_model=StandardResponse[AIResponse], 
             responses={500: {"model": ErrorResponse}}, 
             summary="Mengirim prompt ke Alibaba Qwen via DashScope API")
async def ask_qwen(
    request: AIPrompt, 
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk berinteraksi dengan model AI Qwen dari Alibaba Cloud.
    
    Menggunakan DashScope API official dengan support untuk berbagai model:
    - qwen-turbo: Model cepat dan efisien
    - qwen-plus: Model dengan kemampuan lebih baik  
    - qwen-max: Model paling canggih
    - qwen-long: Model dengan context window panjang
    """
    if not qwen_client:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, 
            detail="Layanan Qwen tidak dikonfigurasi di server."
        )
    
    try:
        async with qwen_client as client:
            # Gunakan model dari request atau default ke qwen-turbo
            model = getattr(request, 'model', 'qwen-turbo')
            
            result = await client.generate_response(
                prompt=request.prompt,
                model=model,
                temperature=getattr(request, 'temperature', 0.7),
                top_p=getattr(request, 'top_p', 0.8),
                max_tokens=getattr(request, 'max_tokens', 2000)
            )
            
            response_data = AIResponse(
                text=result["text"],
                metadata={
                    "model": model,
                    "usage": result.get("usage", {}),
                    "request_id": result.get("request_id", "")
                }
            )
            
            return StandardResponse(data=response_data)
            
    except Exception as e:
        error_msg = f"Error dari API Qwen: {str(e)}"
        print(f"Qwen API Error: {error_msg}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
            detail=error_msg
        )

@router.get("/models", 
             summary="Mendapatkan daftar model Qwen yang tersedia")
async def get_qwen_models(api_key: str = Depends(validate_api_key)):
    """Mendapatkan informasi tentang model-model Qwen yang tersedia"""
    if not qwen_client:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Layanan Qwen tidak dikonfigurasi"
        )
    
    models_info = {
        "qwen-turbo": {
            "description": "Model cepat dan efisien untuk tugas umum",
            "max_tokens": 2000,
            "context_window": 8192,
            "best_for": "Chat cepat, tugas sehari-hari"
        },
        "qwen-plus": {
            "description": "Model dengan kemampuan lebih baik dan pemahaman mendalam", 
            "max_tokens": 2000,
            "context_window": 32768,
            "best_for": "Analisis kompleks, coding, reasoning"
        },
        "qwen-max": {
            "description": "Model paling canggih dengan kemampuan terbaik",
            "max_tokens": 2000, 
            "context_window": 32768,
            "best_for": "Tugas kompleks, kreativitas tinggi"
        },
        "qwen-long": {
            "description": "Model dengan context window sangat panjang",
            "max_tokens": 8000,
            "context_window": 1024000,  # 1M tokens
            "best_for": "Dokumen panjang, analisis ekstensif"
        }
    }
    
    return StandardResponse(data={"models": models_info})

# Update model request untuk support parameter tambahan
class AIPromptWithParams(AIPrompt):
    model: Optional[str] = "qwen-turbo"
    temperature: Optional[float] = 0.7
    top_p: Optional[float] = 0.8
    max_tokens: Optional[int] = 2000