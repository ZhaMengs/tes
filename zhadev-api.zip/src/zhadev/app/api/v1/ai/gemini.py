# /zhadev/app/api/v1/ai/gemini.py

import google.generativeai as genai
from fastapi import APIRouter, Depends, HTTPException, status

from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from ....core.config import settings

router = APIRouter()

if not settings.GEMINI_API_KEY:
    print("PERINGATAN: GEMINI_API_KEY tidak diatur. Endpoint Gemini akan dinonaktifkan.")
else:
    try:
        genai.configure(api_key=settings.GEMINI_API_KEY)
    except Exception as e:
        print(f"ERROR: Gagal mengkonfigurasi Gemini SDK: {e}")

@router.post("/", response_model=StandardResponse[AIResponse], responses={500: {"model": ErrorResponse}}, summary="Mengirim prompt ke Google Gemini")
async def ask_gemini(request: AIPrompt, api_key: str = Depends(validate_api_key)):
    if not settings.GEMINI_API_KEY:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan Gemini tidak dikonfigurasi di server.")
    try:
        model = genai.GenerativeModel('gemini-pro')
        response = await model.generate_content_async(request.prompt)
        if not response.parts:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Model tidak menghasilkan respons. Prompt mungkin melanggar kebijakan keamanan.")
        result = AIResponse(text=response.text)
        return StandardResponse(data=result)
    except Exception as e:
        print(f"ERROR: Terjadi kesalahan pada API Gemini: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal saat berkomunikasi dengan Gemini: {str(e)}")