# /zhadev/app/api/v1/tools/background_removal.py

import time
import replicate
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class RemoveBgOutput(BaseModel):
    output_url: str

# ID Model `rembg` di Replicate
REMBG_MODEL_VERSION = "f2f27f8a3c8c0b8af5c4c062c019941a8c3d390a7863777553f1915f0135d0e7"

@router.get(
    "/",
    response_model=StandardResponse[RemoveBgOutput],
    summary="Menghapus latar belakang dari gambar"
)
async def remove_background(
    url: str = Query(..., description="URL ke file gambar (png, jpg). Video belum didukung oleh model ini."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    try:
        output_url = replicate.run(
            f"cj-w-lee/rembg:{REMBG_MODEL_VERSION}",
            input={"image": url}
        )
        
        result = RemoveBgOutput(output_url=output_url)
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model: {str(e)}")