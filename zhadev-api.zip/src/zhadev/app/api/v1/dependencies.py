# /zhadev/app/api/v1/dependencies.py

import re
import time
from typing import Set, Dict, List

from fastapi import Security, HTTPException, status, Depends
from fastapi.security import APIKeyQuery

# --- API KEY VALIDATION ---

API_KEY_NAME = "apikey"
FREE_KEYS: Set[str] = {
    "zhadev_restapi",
    "zhadev_freekey",
    "zhadev_freeapi",
}
PREM_KEY_PATTERN = re.compile(r"^zhadev-prem-[a-zA-Z0-9]{16}$")

api_key_query = APIKeyQuery(name=API_KEY_NAME, auto_error=False)

async def validate_api_key(api_key: str = Security(api_key_query)):
    """
    Dependency untuk memvalidasi API Key.
    Mengecek terhadap daftar kunci gratis atau pola kunci premium.
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API Key tidak ditemukan. Silakan sertakan parameter 'apikey'.",
        )

    if api_key in FREE_KEYS or PREM_KEY_PATTERN.match(api_key):
        return api_key

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="API Key yang Anda berikan tidak valid atau tidak sah.",
    )

# --- RATE LIMITING ---

RATE_LIMIT_CACHE: Dict[str, List[float]] = {}
RATE_LIMIT_DURATION_SECONDS = 60  # Jendela waktu: 1 menit
RATE_LIMIT_REQUESTS = 30  # Jumlah maksimal permintaan per jendela waktu

async def rate_limiter(api_key: str = Depends(validate_api_key)):
    """
    Dependency kompleks untuk Rate Limiting.
    Dependency ini secara otomatis juga menjalankan `validate_api_key` terlebih dahulu.
    """
    current_time = time.time()
    
    request_timestamps = RATE_LIMIT_CACHE.get(api_key, [])
    
    valid_timestamps = [t for t in request_timestamps if t > current_time - RATE_LIMIT_DURATION_SECONDS]
    
    if len(valid_timestamps) >= RATE_LIMIT_REQUESTS:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit terlampaui. Coba lagi setelah {int(valid_timestamps[0] + RATE_LIMIT_DURATION_SECONDS - current_time)} detik.",
        )
    
    valid_timestamps.append(current_time)
    RATE_LIMIT_CACHE[api_key] = valid_timestamps
    
    return api_key