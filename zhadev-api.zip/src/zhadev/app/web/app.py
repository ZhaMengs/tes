from fastapi import APIRouter
from pywebio.platform.fastapi import webio_routes
from pywebio.session import go_app

# Impor dari __init__.py
from .routes import (
    about, ai, downloader, random, stalker, documentation,
    easter_egg, tools, search, parser, shortcuts
)

# Halaman default
def index():
    go_app('downloader', new_window=False)

# Dapatkan list routes dari PyWebIO
pywebio_routes_list = webio_routes(applications={
    'index': index,
    'about': about,
    'ai': ai,
    'downloader': downloader,
    'random': random,
    'stalker': stalker,
    'documentation': documentation,
    'easter_egg': easter_egg,
    'tools': tools,
    'search': search,
    'parser': parser,
    'shortcuts': shortcuts,
})

# Convert list routes ke APIRouter
web_router = APIRouter()

for route in pywebio_routes_list:
    web_router.routes.append(route)

__all__ = ['web_router']