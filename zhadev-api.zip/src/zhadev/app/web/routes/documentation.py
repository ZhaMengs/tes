# /zhadev/app/web/routes/documentation.py

from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

async def app():
    """Halaman dokumentasi interaktif untuk API."""
    set_env(title="ZhaDev Tools - Documentation")
    render_navbar(active_page='documentation')

    put_html("<h1>📚 ZhaDev API Documentation</h1>")
    put_markdown("""
    **Base URL:** `http://localhost:8000/api/v1`
    **Autentikasi:** Tambahkan `?apikey=YOUR_API_KEY` di setiap request
    
    ### 🔑 API Keys Gratis:
    - `zhadev_restapi`
    - `zhadev_freekey` 
    - `zhadev_freeapi`
    """)

    # SEMUA ENDPOINT YANG TERSEDIA
    put_collapse("📥 DOWNLOADER ENDPOINTS", [
        put_markdown("""
        ### 🎵 Video & Audio Downloader
        - `GET /api/v1/downloader/tiktok/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/youtube/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/instagram/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/facebook/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/twitter/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/douyin/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/bilibili/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/bstation/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/weibo/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/xiaohongshu/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/dailymotion/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/snackvideo/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/terabox/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/threads/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/donghub/?url=URL&apikey=KEY`
        
        ### ☁️ File Downloader
        - `GET /api/v1/downloader/gdrive/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/mediafire/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/pixeldrain/?url=URL&apikey=KEY`
        
        ### 🎵 Music Downloader
        - `GET /api/v1/downloader/spotify/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/capcut/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/github/?url=URL&apikey=KEY`
        - `GET /api/v1/downloader/pinterest/?url=URL&apikey=KEY`
        """)
    ])

    put_collapse("🔍 STALKER ENDPOINTS", [
        put_markdown("""
        ### 👤 Profile Stalker
        - `GET /api/v1/stalker/tiktok/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/instagram/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/facebook/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/twitter/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/youtube/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/douyin/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/bilibili/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/bstation/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/weibo/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/xiaohongshu/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/capcut/?url=URL&apikey=KEY`
        - `GET /api/v1/stalker/donghub/?url=URL&apikey=KEY`
        """)
    ])

    put_collapse("🔎 SEARCH ENDPOINTS", [
        put_markdown("""
        ### 🌐 Search Engines
        - `GET /api/v1/search/youtube/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/tiktok/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/twitter/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/pinterest/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/spotify/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/douyin/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/bilibili/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/bstation/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/weibo/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/xiaohongshu/?q=QUERY&apikey=KEY`
        - `GET /api/v1/search/donghub/?q=QUERY&apikey=KEY`
        
        ### 📊 Information Search
        - `GET /api/v1/search/weather/?q=CITY&apikey=KEY`
        - `GET /api/v1/search/earthquake/?q=REGION&apikey=KEY`
        - `GET /api/v1/search/prayer_schedule/?q=CITY&apikey=KEY`
        - `GET /api/v1/search/anime_schedule/?q=DAY&apikey=KEY`
        - `GET /api/v1/search/donghua_schedule/?q=DAY&apikey=KEY`
        - `GET /api/v1/search/recipes/?q=FOOD&apikey=KEY`
        """)
    ])

    put_collapse("🤖 AI ENDPOINTS", [
        put_markdown("""
        ### 🧠 AI Models (POST Requests)
        - `POST /api/v1/ai/deepseek/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/gemini/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/claude/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/chatgpt4/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/qwen_ai/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/character_ai/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        - `POST /api/v1/ai/felo_ai/?apikey=KEY` + JSON: `{"prompt": "your text"}`
        
        ### 💻 AI Coding Assistants
        - `POST /api/v1/ai/coding/?apikey=KEY` + JSON: `{"prompt": "code here"}`
        - `POST /api/v1/ai/gpt_logic/?apikey=KEY` + JSON: `{"prompt": "logic problem"}`
        """)
    ])

    put_collapse("🛠️ TOOLS ENDPOINTS", [
        put_markdown("""
        ### 🖼️ Image Tools
        - `POST /api/v1/tools/image_enhancement/?apikey=KEY` + image file
        - `POST /api/v1/tools/image_upscaling/?apikey=KEY` + image file
        - `POST /api/v1/tools/background_removal/?apikey=KEY` + image file
        - `POST /api/v1/tools/remini/?apikey=KEY` + image file
        - `POST /api/v1/tools/text_to_image/?apikey=KEY` + JSON: `{"text": "description"}`
        
        ### 🎵 Audio Tools
        - `POST /api/v1/tools/audio/?apikey=KEY` + audio file
        
        ### 🎬 Video Tools
        - `POST /api/v1/tools/video_enhancement/?apikey=KEY` + video file
        - `POST /api/v1/tools/video_upscaling/?apikey=KEY` + video file
        
        ### 📝 Text Tools
        - `POST /api/v1/tools/ocr/?apikey=KEY` + image file
        - `GET /api/v1/tools/url_shortener/?url=URL&apikey=KEY`
        
        ### 📦 Utility Tools
        - `GET /api/v1/tools/shipment_tracking/?tracking=CODE&apikey=KEY`
        """)
    ])

    put_collapse("🎲 RANDOM ENDPOINTS", [
        put_markdown("""
        ### 💫 Random Content
        - `GET /api/v1/random/quotes/?apikey=KEY`
        - `GET /api/v1/random/anime/?apikey=KEY`
        - `GET /api/v1/random/donghua/?apikey=KEY`
        """)
    ])

    # URL GENERATOR
    put_scope("generator_scope")
    
    while True:
        with use_scope("generator_scope", clear=True):
            put_html("<hr><h3>🔧 URL Generator</h3>")
            
            data = await input_group("Buat Contoh Permintaan", [
                select("Pilih Modul", name="module", options=[
                    ("📥 Downloader", "downloader"),
                    ("🔍 Stalker", "stalker"), 
                    ("🔎 Search", "search"),
                    ("🤖 AI", "ai"),
                    ("🛠️ Tools", "tools"),
                    ("🎲 Random", "random")
                ]),
                select("Pilih Endpoint", name="endpoint", options=[
                    # Downloader endpoints
                    ("TikTok", "tiktok"), ("YouTube", "youtube"), ("Instagram", "instagram"),
                    ("Facebook", "facebook"), ("Twitter", "twitter"), ("Douyin", "douyin"),
                    ("Bilibili", "bilibili"), ("BStation", "bstation"), ("Weibo", "weibo"),
                    ("Xiaohongshu", "xiaohongshu"), ("Spotify", "spotify"),
                    # Stalker endpoints  
                    ("TikTok Stalk", "tiktok"), ("Instagram Stalk", "instagram"),
                    # Search endpoints
                    ("YouTube Search", "youtube"), ("Weather", "weather"),
                    # AI endpoints
                    ("Gemini", "gemini"), ("DeepSeek", "deepseek"), ("Claude", "claude"),
                    # Tools endpoints
                    ("URL Shortener", "url_shortener"), ("OCR", "ocr"),
                    # Random endpoints
                    ("Quotes", "quotes"), ("Anime Quotes", "anime")
                ]),
                input("Kunci API", name="apikey", value="zhadev_restapi"),
                textarea("Parameter", name="param", 
                        placeholder="URL untuk downloader/stalker\nQuery untuk search\nPrompt untuk AI\nFile untuk tools"),
            ])
        
        module = data['module']
        endpoint = data['endpoint']
        apikey = data['apikey']
        param = data['param']
        
        if module == "ai":
            # AI menggunakan POST
            curl_command = f"""curl -X POST "http://localhost:8000/api/v1/{module}/{endpoint}/?apikey={apikey}" \\
-H "Content-Type: application/json" \\
-d '{{"prompt": "{param}"}}'"""
            
            put_markdown("**Contoh cURL Command:**")
            put_code(curl_command, language='bash')
            put_markdown("**Atau gunakan JavaScript Fetch:**")
            js_code = f"""fetch("http://localhost:8000/api/v1/{module}/{endpoint}/?apikey={apikey}", {{
    method: "POST",
    headers: {{ "Content-Type": "application/json" }},
    body: JSON.stringify({{ prompt: "{param}" }})
}})
.then(response => response.json())
.then(data => console.log(data));"""
            put_code(js_code, language='javascript')
            
        elif module == "tools" and endpoint in ["ocr", "image_enhancement", "audio"]:
            # Tools yang butuh file upload
            put_markdown("**Endpoint ini memerlukan file upload**")
            put_info("Gunakan tools seperti Postman atau curl dengan form-data")
            
        else:
            # GET requests
            if module == "downloader" or module == "stalker":
                url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?url={param}&apikey={apikey}"
            elif module == "search":
                url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?q={param}&apikey={apikey}"
            elif module == "random":
                url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?apikey={apikey}"
            elif module == "tools" and endpoint == "url_shortener":
                url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?url={param}&apikey={apikey}"
            else:
                url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?param={param}&apikey={apikey}"
            
            put_markdown("**Generated URL:**")
            put_html(f'<p><a href="{url}" target="_blank">{url}</a></p>')
            put_markdown("**Contoh cURL:**")
            put_code(f'curl "{url}"', language='bash')