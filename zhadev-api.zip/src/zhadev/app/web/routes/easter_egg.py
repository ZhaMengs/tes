# /zhadev/app/web/routes/easter_egg.py

import pyfiglet
from pywebio.output import *
from pywebio.session import set_env
from .utils import render_navbar

async def app():
    """Halaman Easter Egg."""
    set_env(title="ZhaDev Tools - ???")
    # Sengaja tidak ada navbar untuk membuatnya tersembunyi
    
    put_html("<h1 align='center'>🎉 You Found a Secret! 🎉</h1>")
    
    # Generate ASCII art
    text = "ZhaDev"
    ascii_art = pyfiglet.figlet_format(text, font="slant")
    
    put_code(ascii_art)
    put_markdown("---")
    put_html("<center>✨ Terima kasih telah menjelajahi proyek ini! ✨</center>")  # ← PERBAIKAN DI SINI
    
    # Tambahkan beberapa efek visual menarik
    put_html("""
    <style>
    @keyframes rainbow {
        0% { color: #ff0000; }
        16% { color: #ff8000; }
        33% { color: #ffff00; }
        50% { color: #00ff00; }
        66% { color: #0000ff; }
        83% { color: #8000ff; }
        100% { color: #ff0080; }
    }
    .rainbow-text {
        animation: rainbow 3s infinite;
        font-weight: bold;
        font-size: 1.2em;
    }
    </style>
    """)
    
    put_html('<p class="rainbow-text" align="center">🎊 Selamat! Anda adalah pengguna yang penasaran! 🎊</p>')
    
    # Tambahkan beberapa fakta menarik
    put_collapse("🤫 Fakta Rahasia", [
        put_markdown("""
        **Fakta-fakta tentang ZhaDev:**
        
        - 🕵️ **Easter Egg ini** hanya bisa diakses dengan langsung mengunjungi URL
        - 🔧 **Dibangun dengan** FastAPI + PyWebIO + HTTPX
        - 🎯 **Target**: Menjadi all-in-one API platform
        - 📊 **Total Endpoint**: 70+ dan terus bertambah!
        - 💡 **Fun Fact**: Project ini dimulai sebagai eksperimen weekend
        
        **Tips:**
        - Coba akses `/api/v1/random/quotes/` untuk kutipan inspiratif
        - Gunakan AI assistant untuk bantuan coding
        - Explore semua 20+ downloader platforms!
        """)
    ])
    
    # Tombol untuk kembali
    put_buttons(['🏠 Kembali ke Home'], onclick=lambda: run_js('window.location.href = "/"'))