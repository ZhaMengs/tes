# /zhadev/app/web/routes/shortcuts.py

import httpx
import json
from urllib.parse import urlparse, parse_qs
from pywebio.output import *
from pywebio.session import set_env, eval_js, run_js

API_BASE_URL = "http://localhost:8000/api/v1"
INTERNAL_API_KEY = "zhadev_restapi"

# Extended platform mapping for iOS Shortcuts
PLATFORM_MAP = {
    # Video Platforms
    "douyin.com": "downloader/douyin", "tiktok.com": "downloader/tiktok", "vm.tiktok.com": "downloader/tiktok",
    "bilibili.com": "downloader/bilibili", "bilibili.tv": "downloader/bstation", "b23.tv": "downloader/bilibili",
    "instagram.com": "downloader/instagram", "threads.net": "downloader/threads",
    "youtube.com": "downloader/youtube", "youtu.be": "downloader/youtube", 
    "twitter.com": "downloader/twitter", "x.com": "downloader/twitter",
    "facebook.com": "downloader/facebook",
    "dailymotion.com": "downloader/dailymotion",
    "snackvideo.com": "downloader/snackvideo",
    
    # Audio Platforms
    "spotify.com": "downloader/spotify",
    
    # File Hosting
    "mediafire.com": "downloader/mediafire",
    "pixeldrain.com": "downloader/pixeldrain",
    "terabox.com": "downloader/terabox",
    "drive.google.com": "downloader/gdrive",
}

async def app():
    """
    Backend untuk iOS Shortcuts integration.
    Menerima parameter dari URL, memprosesnya, dan mengembalikan hasil ke aplikasi Pintasan.
    """
    set_env(title="ZhaDev Shortcuts Backend")
    put_html("<h1 align='center'>🔄 Processing Shortcut Request...</h1>")
    put_loading(shape='grow', color='primary')

    try:
        # 1. Dapatkan parameter dari URL query
        query_string = await eval_js("window.location.search")
        params = parse_qs(query_string.lstrip('?'))
        
        action = params.get('action', [None])[0]
        url = params.get('url', [None])[0]
        platform = params.get('platform', [None])[0]  # Optional: force platform
        callback_shortcut = params.get('callback', ['ZhaDevProcessor'])[0]

        if not action or not url:
            raise ValueError("❌ Parameter 'action' dan 'url' wajib ada.")

        put_html(f"<center>🔍 Processing: {action} for {url}</center>")

        # 2. Lakukan aksi yang diminta
        if action == 'download':
            # Deteksi atau gunakan platform yang ditentukan
            if not platform:
                domain = urlparse(url).hostname.replace("www.", "") if urlparse(url).hostname else ""
                platform = next((plat for dom, plat in PLATFORM_MAP.items() if dom in domain), None)
            
            if not platform:
                available_platforms = ", ".join(set([p.split('/')[1] for p in PLATFORM_MAP.values()]))
                raise ValueError(f"❌ Platform tidak didukung. Platform yang tersedia: {available_platforms}")

            put_html(f"<center>📱 Platform: {platform.split('/')[1].upper()}</center>")

            # Panggil API yang sesuai
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result_data = response.json().get('data', {})
            
            # 3. Ekstrak link unduhan utama berdasarkan platform
            download_link = extract_download_link(result_data, platform)
            
            if not download_link:
                # Fallback: return JSON data for Shortcuts to parse
                download_link = json.dumps(result_data)

            # 4. Kirim kembali hasil ke iOS Shortcuts
            put_success("✅ Proses selesai!")
            put_html("<center>📲 Mengembalikan hasil ke aplikasi Pintasan...</center>")
            
            # URL encode untuk safety
            import urllib.parse
            encoded_result = urllib.parse.quote(download_link)
            
            # Callback ke iOS Shortcuts
            shortcuts_url = f"shortcuts://run-shortcut?name={callback_shortcut}&input=text&text={encoded_result}"
            run_js(f'window.location.href = "{shortcuts_url}";')

        elif action == 'ai':
            # AI Assistant via Shortcuts
            prompt = params.get('prompt', [None])[0]
            model = params.get('model', ['gemini'])[0]
            
            if not prompt:
                raise ValueError("❌ Parameter 'prompt' wajib untuk aksi AI")

            put_html(f"<center>🤖 AI: {model.upper()} - Processing...</center>")

            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    f"{API_BASE_URL}/ai/{model}/",
                    params={"apikey": INTERNAL_API_KEY},
                    json={"prompt": prompt}
                )
                response.raise_for_status()
                result_data = response.json().get('data', {})
            
            ai_response = result_data.get('text', 'No response from AI')
            
            put_success("✅ AI Response Ready!")
            
            # Kirim ke Shortcuts
            encoded_response = urllib.parse.quote(ai_response)
            shortcuts_url = f"shortcuts://run-shortcut?name={callback_shortcut}&input=text&text={encoded_response}"
            run_js(f'window.location.href = "{shortcuts_url}";')

        else:
            raise ValueError(f"❌ Aksi '{action}' tidak didukung. Gunakan 'download' atau 'ai'")

    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP Error {e.response.status_code}: {e.response.text}"
        put_error("❌ Server Error", error_msg)
        # run_js(f'window.location.href = "shortcuts://run-shortcut?name={callback_shortcut}&input=text&text=ERROR:{urllib.parse.quote(error_msg)}"')
        
    except Exception as e:
        error_detail = ""
        if hasattr(e, 'response') and e.response:
            try:
                error_detail = e.response.json().get('detail', str(e))
            except:
                error_detail = str(e)
        else:
            error_detail = str(e)
            
        put_error("💥 Terjadi Kesalahan", error_detail)
        # run_js(f'window.location.href = "shortcuts://run-shortcut?name={callback_shortcut}&input=text&text=ERROR:{urllib.parse.quote(error_detail)}"')

def extract_download_link(result_data, platform):
    """Extract download link based on platform response structure"""
    platform_name = platform.split('/')[1] if '/' in platform else platform
    
    download_structures = {
        'tiktok': lambda d: d.get('video', {}).get('url_no_watermark', ''),
        'douyin': lambda d: d.get('video', {}).get('url_no_watermark', ''),
        'youtube': lambda d: d.get('video_url', ''),
        'instagram': lambda d: next((item.get('video_url') or item.get('display_url', '') 
                                   for item in d.get('media_items', [])), ''),
        'spotify': lambda d: d.get('audio_url', ''),
        'mediafire': lambda d: d.get('download_url', ''),
        'pixeldrain': lambda d: d.get('download_url', ''),
        'terabox': lambda d: d.get('download_url', ''),
        'gdrive': lambda d: d.get('download_url', ''),
    }
    
    extractor = download_structures.get(platform_name, lambda d: d.get('download_url', ''))
    return extractor(result_data) or result_data.get('video_url', '')