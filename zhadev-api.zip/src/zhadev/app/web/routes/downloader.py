# /zhadev/app/web/routes/downloader.py

import httpx
import json
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env

from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/downloader"
INTERNAL_API_KEY = "zhadev_restapi"

PLATFORM_MAP = {
    "douyin.com": "douyin", "tiktok.com": "tiktok", "vm.tiktok.com": "tiktok",
    "bilibili.com": "bilibili", "bilibili.tv": "bstation", "b23.tv": "bilibili",
    "instagram.com": "instagram", "threads.net": "threads",
    "youtube.com": "youtube", "youtu.be": "youtube", "twitter.com": "twitter", "x.com": "twitter",
    # ... tambahkan domain lain yang relevan
}

async def app():
    """Aplikasi PyWebIO untuk halaman Downloader."""
    set_env(title="ZhaDev Tools - Universal Downloader")
    render_navbar(active_page='downloader')
    put_html("<h1 align='center'><strong>Universal Content Downloader</strong></h1>")

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input("Masukkan URL Konten", type="text", required=True,
                              placeholder="Contoh: https://www.tiktok.com/@username/video/123...")
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')
            put_html("<center>Menganalisis URL dan mengambil data...</center>")  # ← PERBAIKAN DI SINI

        try:
            domain = urlparse(url).hostname.replace("www.", "")
            platform = None
            for key, value in PLATFORM_MAP.items():
                if key in domain:
                    platform = value
                    break
            
            if not platform:
                raise ValueError(f"Platform untuk domain '{domain}' tidak didukung atau tidak terdaftar.")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                put_success("Data Berhasil Diambil!")
                
                # Tampilkan data yang lebih user-friendly, bukan hanya JSON
                data = result.get('data', {})
                
                if data.get('title'):
                    put_html(f"<h3>📹 {data['title']}</h3>")
                
                if data.get('author'):
                    put_html(f"<p><strong>Creator:</strong> {data['author']}</p>")
                
                if data.get('duration'):
                    put_html(f"<p><strong>Durasi:</strong> {data['duration']}</p>")
                
                # Tampilkan thumbnail jika ada
                if data.get('thumbnail'):
                    put_image(data['thumbnail'])
                
                # Tombol download
                if data.get('video_url'):
                    put_link("⬇️ Download Video", href=data['video_url'], new_window=True)
                
                # Juga tampilkan JSON untuk debug
                put_collapse("📊 Data Lengkap (JSON)", 
                            put_code(json.dumps(data, indent=2, ensure_ascii=False), language='json'))

        except Exception as e:
            with use_scope("result_scope", clear=True):
                if hasattr(e, 'response') and e.response:
                    try:
                        error_detail = e.response.json().get('detail', str(e))
                    except:
                        error_detail = str(e)
                else:
                    error_detail = str(e)
                
                put_error("Terjadi Kesalahan", error_detail)
                
                # Tombol untuk coba lagi
                put_buttons(['Coba URL Lain'], onclick=lambda: run_js('location.reload()'))