# /zhadev/app/web/routes/parser.py

import httpx
import json
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env

from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1"
INTERNAL_API_KEY = "zhadev_restapi"

# Mapping domain ke modul API (downloader atau stalker)
PLATFORM_MAP = {
    "douyin.com": ("downloader", "douyin"), 
    "tiktok.com": ("downloader", "tiktok"), "vm.tiktok.com": ("downloader", "tiktok"),
    "bilibili.com": ("downloader", "bilibili"), "bilibili.tv": ("downloader", "bstation"), "b23.tv": ("downloader", "bilibili"),
    "instagram.com": ("downloader", "instagram"), 
    "twitter.com": ("downloader", "twitter"), "x.com": ("downloader", "twitter"),
    "youtube.com": ("downloader", "youtube"), "youtu.be": ("downloader", "youtube"),
    "facebook.com": ("downloader", "facebook"),
    "mediafire.com": ("downloader", "mediafire"),
    "pinterest.com": ("downloader", "pinterest"),
    "spotify.com": ("downloader", "spotify"),
    "github.com": ("downloader", "github"),
    "dailymotion.com": ("downloader", "dailymotion"),
    "pixeldrain.com": ("downloader", "pixeldrain"),
    "snackvideo.com": ("downloader", "snackvideo"),
    "terabox.com": ("downloader", "terabox"),
    "threads.net": ("downloader", "threads"),
    "drive.google.com": ("downloader", "gdrive"),
    "capcut.com": ("downloader", "capcut"),
    "weibo.com": ("downloader", "weibo"),
    "xiaohongshu.com": ("downloader", "xiaohongshu"),
    "donghub.com": ("downloader", "donghub"),
}

async def app():
    """Aplikasi PyWebIO untuk halaman Parser."""
    set_env(title="ZhaDev Tools - Raw API Parser")
    render_navbar(active_page='parser')
    put_html("<h1 align='center'><strong>🔧 Raw API Parser</strong></h1>")
    put_markdown("""
    **Alat ini memanggil endpoint API yang relevan dan menampilkan respons JSON mentah.** 
    Berguna untuk *debugging* dan pengembangan.
    
    ### Cara Kerja:
    1. Masukkan URL dari platform yang didukung
    2. Sistem akan otomatis detect platform
    3. Panggil API endpoint yang sesuai
    4. Tampilkan raw JSON response
    """)

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input(
                "🌐 Masukkan URL Apapun yang Didukung", 
                type="text", 
                required=True,
                placeholder="Contoh: https://www.tiktok.com/@username/video/123456789"
            )
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow', color='primary')
            put_html("<center>🔄 Menganalisis URL dan memanggil API...</center>")  # ← PERBAIKAN DI SINI

        try:
            parsed_url = urlparse(url)
            domain = parsed_url.hostname.replace("www.", "") if parsed_url.hostname else ""
            
            if not domain:
                raise ValueError("URL tidak valid")
            
            module, platform = None, None
            for key, (mod, plat) in PLATFORM_MAP.items():
                if key in domain:
                    module, platform = mod, plat
                    break
            
            if not platform:
                raise ValueError(f"❌ Platform untuk domain '{domain}' tidak didukung.")

            # Tampilkan info tentang endpoint yang akan dipanggil
            with use_scope("result_scope", clear=True):
                put_info(f"🔍 Detected: {platform.upper()} → Calling: /api/v1/{module}/{platform}/")
                put_loading(shape='grow', color='primary')

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{module}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                put_success("✅ Respons API Berhasil Diterima")
                
                # Tampilkan info ringkas
                if 'data' in result:
                    data = result['data']
                    put_table([
                        ['Platform', 'Status', 'Data Type'],
                        [platform.upper(), 'Success', type(data).__name__]
                    ])
                
                # Tampilkan JSON raw dengan syntax highlighting
                put_html("<h4>📄 Raw JSON Response:</h4>")
                put_code(json.dumps(result, indent=2, ensure_ascii=False), language='json')
                
                # Tombol untuk parsing lagi
                put_buttons(['🔄 Parse URL Lain'], onclick=lambda: run_js('location.reload()'))

        except httpx.HTTPStatusError as e:
            with use_scope("result_scope", clear=True):
                put_error(f"❌ HTTP Error {e.response.status_code}", 
                         f"Server mengembalikan error: {e.response.text}")
                put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))
                
        except httpx.RequestError as e:
            with use_scope("result_scope", clear=True):
                put_error("🌐 Connection Error", 
                         f"Tidak dapat terhubung ke server API: {str(e)}")
                put_html("<p>Pastikan server ZhaDev API sedang berjalan di localhost:8000</p>")
                put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))
                
        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = ""
                if hasattr(e, 'response') and e.response:
                    try:
                        error_detail = e.response.json().get('detail', str(e))
                    except:
                        error_detail = str(e)
                else:
                    error_detail = str(e)
                    
                put_error("💥 Terjadi Kesalahan", error_detail)
                put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))