# /zhadev/app/web/routes/utils.py

from pywebio.output import put_html, put_markdown
from pywebio.session import run_js

def render_navbar(active_page: str):
    """Membuat dan menampilkan navbar dengan halaman aktif yang ditandai."""
    nav_items = {
        "📥 Downloader": "downloader",
        "👤 Stalker": "stalker", 
        "🔍 Search": "search",
        "🛠️ Tools": "tools",
        "🤖 AI Assistant": "ai",
        "🔧 Parser": "parser",
        "🎲 Random": "random",
        "📚 Documentation": "documentation",
        "ℹ️ About": "about",
    }
    
    styles = """
    <style>
        .navbar { 
            overflow: hidden; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin-bottom: 25px; 
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 0 10px;
        }
        .navbar-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }
        .navbar-btn { 
            float: left; 
            display: block; 
            color: white; 
            text-align: center; 
            padding: 14px 18px; 
            text-decoration: none; 
            font-size: 16px; 
            font-weight: 500;
            border: none; 
            background: none; 
            cursor: pointer; 
            transition: all 0.3s ease;
            border-radius: 6px;
            margin: 5px 2px;
        }
        .navbar-btn:hover { 
            background-color: rgba(255,255,255,0.2); 
            transform: translateY(-2px);
        }
        .navbar-btn.active { 
            background-color: #04AA6D; 
            color: white;
            box-shadow: 0 4px 8px rgba(4, 170, 109, 0.3);
        }
        .navbar-title {
            color: white;
            padding: 14px 20px;
            font-size: 20px;
            font-weight: bold;
            margin-right: auto;
        }
        @media (max-width: 768px) {
            .navbar-container {
                justify-content: flex-start;
            }
            .navbar-btn {
                padding: 12px 14px;
                font-size: 14px;
            }
        }
    </style>
    """
    
    buttons_html = ""
    for display, name in nav_items.items():
        active_class = 'active' if name == active_page else ''
        buttons_html += f'<button class="navbar-btn {active_class}" onclick="window.location.href=\'/?app={name}\'">{display}</button>'
    
    navbar_html = f"""
    {styles}
    <div class="navbar">
        <div class="navbar-container">
            <div class="navbar-title">🚀 ZhaDev Tools</div>
            {buttons_html}
        </div>
    </div>
    """
    
    put_html(navbar_html)

def put_loading_with_text(text: str):
    """Menampilkan loading dengan teks yang tercentang."""
    put_html(f"""
    <div style="text-align: center; padding: 20px;">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p style="margin-top: 15px; font-size: 16px; color: #666;">{text}</p>
    </div>
    """)

def put_success_message(title: str, message: str = ""):
    """Menampilkan pesan sukses yang konsisten."""
    put_html(f"""
    <div style="background: #d4edda; border: 1px solid #c3e6cb; border-radius: 8px; padding: 15px; margin: 15px 0;">
        <div style="display: flex; align-items: center;">
            <span style="color: #155724; font-size: 24px; margin-right: 10px;">✅</span>
            <div>
                <strong style="color: #155724; font-size: 16px;">{title}</strong>
                {f'<p style="color: #155724; margin: 5px 0 0 0;">{message}</p>' if message else ''}
            </div>
        </div>
    </div>
    """)

def put_error_message(title: str, message: str = ""):
    """Menampilkan pesan error yang konsisten."""
    put_html(f"""
    <div style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 8px; padding: 15px; margin: 15px 0;">
        <div style="display: flex; align-items: center;">
            <span style="color: #721c24; font-size: 24px; margin-right: 10px;">❌</span>
            <div>
                <strong style="color: #721c24; font-size: 16px;">{title}</strong>
                {f'<p style="color: #721c24; margin: 5px 0 0 0;">{message}</p>' if message else ''}
            </div>
        </div>
    </div>
    """)

def put_info_message(title: str, message: str = ""):
    """Menampilkan pesan info yang konsisten."""
    put_html(f"""
    <div style="background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 8px; padding: 15px; margin: 15px 0;">
        <div style="display: flex; align-items: center;">
            <span style="color: #0c5460; font-size: 24px; margin-right: 10px;">ℹ️</span>
            <div>
                <strong style="color: #0c5460; font-size: 16px;">{title}</strong>
                {f'<p style="color: #0c5460; margin: 5px 0 0 0;">{message}</p>' if message else ''}
            </div>
        </div>
    </div>
    """)

def render_footer():
    """Menampilkan footer di bawah halaman."""
    put_html("""
    <div style="text-align: center; margin-top: 40px; padding: 20px; color: #666; border-top: 1px solid #eee;">
        <p>🚀 Built with <strong>FastAPI</strong> + <strong>PyWebIO</strong> | 
           <a href="/?app=about" style="color: #667eea; text-decoration: none;">About</a> | 
           <a href="/?app=documentation" style="color: #667eea; text-decoration: none;">Documentation</a>
        </p>
        <p style="font-size: 14px;">&copy; 2024 ZhaDev Tools. All rights reserved.</p>
    </div>
    """)