# /zhadev/app/web/routes/ai.py

import httpx
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

# Asumsi API berjalan di localhost:8000
API_BASE_URL = "http://localhost:8000/api/v1"
# Gunakan salah satu API key gratis Anda untuk web UI
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman AI Assistant."""
    set_env(title="ZhaDev Tools - AI Assistant")
    render_navbar(active_page='ai')
    put_html("<h1 align='center'><strong>AI Assistant</strong></h1>")
    
    put_markdown("""
    💬 **Chat dengan berbagai model AI yang powerful:**
    - **Gemini** - Google's AI model
    - **Claude** - Anthropic's conversational AI  
    - **ChatGPT-4** - OpenAI's latest model
    - **DeepSeek** - Open-source AI model
    """)
    
    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            data = await input_group("Kirim prompt ke model AI", [
                select("Pilih Model AI", name="model", options=[
                    ("Gemini Pro", "gemini"),
                    ("Claude", "claude"), 
                    ("ChatGPT-4", "chatgpt4"),
                    ("DeepSeek", "deepseek")
                ], value="gemini"),
                textarea("Masukkan Prompt Anda", name="prompt", required=True, 
                        placeholder="Contoh: Jelaskan apa itu FastAPI dan keunggulannya?"),
            ])
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow', color='primary')
            put_html("<center>🧠 AI sedang berpikir...</center>")  # ← PERBAIKAN DI SINI

        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    f"{API_BASE_URL}/ai/{data['model']}/",
                    params={"apikey": INTERNAL_API_KEY},
                    json={"prompt": data['prompt']}
                )
                response.raise_for_status()
                result = response.json()
                
            with use_scope("result_scope", clear=True):
                put_success("✅ AI telah merespons!")
                put_html(f"<h3>🤖 Jawaban dari {data['model'].title()}:</h3>")
                
                # Tampilkan response dengan formatting yang lebih baik
                ai_response = result.get('data', {}).get('text', 'Tidak ada response')
                put_markdown(ai_response)
                
                # Tambahkan info tambahan jika ada
                if 'usage' in result.get('data', {}):
                    usage = result['data']['usage']
                    put_info(f"📊 Usage: {usage}")
                
                put_buttons(['Tanya Lagi'], onclick=lambda: run_js('location.reload()'))

        except httpx.HTTPStatusError as e:
            with use_scope("result_scope", clear=True):
                put_error(f"❌ Error {e.response.status_code}", 
                         f"Gagal menghubungi API: {e.response.text}")
                put_buttons(['Coba Lagi'], onclick=lambda: run_js('location.reload()'))
                
        except httpx.RequestError as e:
            with use_scope("result_scope", clear=True):
                put_error("🌐 Connection Error", 
                         f"Tidak dapat terhubung ke server: {str(e)}")
                put_html("<p>Pastikan server API sedang berjalan di localhost:8000</p>")
                put_buttons(['Coba Lagi'], onclick=lambda: run_js('location.reload()'))
                
        except Exception as e:
            with use_scope("result_scope", clear=True):
                put_error("💥 Terjadi Kesalahan", str(e))
                put_buttons(['Coba Lagi'], onclick=lambda: run_js('location.reload()'))
        
        # Scroll ke atas untuk form berikutnya
        run_js('window.scrollTo(0, 0);')