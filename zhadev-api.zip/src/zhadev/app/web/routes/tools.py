# /zhadev/app/web/routes/tools.py

import httpx
import json
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/tools"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Tools."""
    set_env(title="ZhaDev Tools - AI Tools")
    render_navbar(active_page='tools')
    put_html("<h1 align='center'><strong>🛠️ AI-Powered Tools</strong></h1>")
    
    put_markdown("""
    **Koleksi alat AI yang powerful untuk berbagai kebutuhan:**
    
    ### 🖼️ Image Tools
    - **Text-to-Image** - Generate gambar dari teks
    - **Image Enhancement** - Tingkatkan kualitas gambar
    - **Background Removal** - Hapus latar belakang
    - **Image Upscaling** - Perbesar resolusi gambar
    - **Waifu Penghitaman** - Ubah tampilan karakter anime
    
    ### 🎵 Audio Tools  
    - **Vocal Remover** - Pisahkan vokal dan instrumental
    
    ### 📝 Text Tools
    - **OCR** - Baca teks dari gambar
    - **URL Shortener** - Persingkat URL
    
    ### 📦 Utility Tools
    - **Shipment Tracking** - Lacak paket
    """)

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            tool = await select("Pilih Alat AI", options=[
                ("🖼️ Buat Gambar dari Teks", "text_to_image"),
                ("🎵 Hapus Vokal dari Audio", "audio_vocal_remover"),
                ("✨ Tingkatkan Resolusi Gambar", "image_enhancement"),
                ("🔍 Hapus Latar Belakang Gambar", "background_removal"),
                ("🔄 Ubah Tampilan Waifu", "wpw"),
                ("📖 Baca Teks dari Gambar (OCR)", "ocr"),
                ("🔗 Persingkat URL", "url_shortener"),
                ("📦 Lacak Paket", "shipment_tracking"),
                ("🔼 Perbesar Gambar (Upscaling)", "image_upscaling"),
                ("🎬 Enhance Video", "video_enhancement"),
            ])

        # Form dinamis berdasarkan pilihan
        if tool == "text_to_image":
            data = await input_group("🖼️ Text-to-Image", [
                textarea("Prompt", name="prompt", required=True, 
                        placeholder="Contoh: A beautiful anime girl standing in a neon-lit city at night"),
                textarea("Negative Prompt", name="negative_prompt", 
                        placeholder="ugly, blurry, low quality, distorted"),
                input("Jumlah Gambar", name="num_images", type="number", value=1, min=1, max=4),
            ])
            await run_tool(tool, data)
            
        elif tool == "wpw":
            data = await input_group("🔄 Waifu Penghitaman", [
                input("URL Gambar Waifu", name="url", type="url", required=True,
                     placeholder="https://example.com/waifu.jpg"),
                select("Pilih Efek", name="skin", options=[
                    ("Hitam", "hitam"),
                    ("Coklat", "coklat"), 
                    ("Nerd", "nerd"),
                    ("Albino", "albino"),
                    ("Botak", "botak")
                ])
            ])
            await run_tool(tool, data)
            
        elif tool == "url_shortener":
            data = await input_group("🔗 URL Shortener", [
                input("URL yang akan dipersingkat", name="url", type="url", required=True,
                     placeholder="https://example.com/very-long-url")
            ])
            await run_tool(tool, data)
            
        elif tool == "shipment_tracking":
            data = await input_group("📦 Lacak Paket", [
                input("Kode Tracking", name="tracking_number", required=True,
                     placeholder="123456789ABCD"),
                select("Kurir", name="courier", options=[
                    ("JNE", "jne"), ("TIKI", "tiki"), ("POS", "pos"), 
                    ("J&T", "jnt"), ("SiCepat", "sicepat")
                ])
            ])
            await run_tool(tool, data)
            
        else: 
            # Untuk tool yang butuh URL media
            data = await input_group(f"🛠️ {tool.replace('_', ' ').title()}", [
                input("URL Media (Gambar/Audio/Video)", name="url", type="url", required=True,
                     placeholder="https://example.com/image.jpg")
            ])
            await run_tool(tool, data)

async def run_tool(tool, data):
    with use_scope("result_scope", clear=True):
        put_loading(shape='grow', color='primary')
        put_html("<center>🔄 Memproses dengan model AI... Ini mungkin memakan waktu beberapa menit.</center>")

    try:
        # Tentukan metode dan payload berdasarkan tool
        if tool == "text_to_image":
            method = "POST"
            api_url = f"{API_BASE_URL}/{tool}/?apikey={INTERNAL_API_KEY}"
            payload = {"json": data}
            
        elif tool in ["url_shortener", "shipment_tracking"]:
            method = "GET"
            api_url = f"{API_BASE_URL}/{tool}/"
            payload = {"params": {**data, "apikey": INTERNAL_API_KEY}}
            
        else:
            # Untuk tool image/audio processing
            method = "POST"  # Biasanya POST untuk file processing
            api_url = f"{API_BASE_URL}/{tool}/?apikey={INTERNAL_API_KEY}"
            payload = {"json": data}

        async with httpx.AsyncClient(timeout=300.0) as client:
            if method == "POST":
                response = await client.post(api_url, **payload)
            else:
                response = await client.get(api_url, **payload)
                
            response.raise_for_status()
            result = response.json().get('data', {})

        with use_scope("result_scope", clear=True):
            put_success("✅ Proses Selesai!")
            
            # Tampilkan hasil berdasarkan jenis tool
            if tool == "text_to_image":
                if 'image_urls' in result:
                    put_html("<h4>🖼️ Generated Images:</h4>")
                    for img_url in result['image_urls']:
                        put_image(img_url, width="300px")
                        put_link("🔗 Download Image", img_url, new_window=True)
                        put_markdown("---")
                else:
                    put_warning("⚠️ Tidak ada gambar yang dihasilkan")
                    
            elif tool == "audio_vocal_remover":
                put_html("<h4>🎵 Audio Results:</h4>")
                put_table([
                    ['🎤 Vokal', put_link("⬇️ Download Vokal", result.get('vocals_url', '#'), new_window=True)],
                    ['🎵 Instrumental', put_link("⬇️ Download Instrumental", result.get('instrumental_url', '#'), new_window=True)],
                ])
                
            elif tool == "url_shortener":
                put_html("<h4>🔗 Shortened URL:</h4>")
                put_link(result.get('short_url', '#'), result.get('short_url', '#'), new_window=True)
                
            elif tool == "shipment_tracking":
                put_html("<h4>📦 Tracking Info:</h4>")
                tracking_info = result.get('tracking_info', {})
                put_table([
                    ['Status', tracking_info.get('status', 'N/A')],
                    ['Lokasi', tracking_info.get('location', 'N/A')],
                    ['Estimasi', tracking_info.get('estimated_delivery', 'N/A')],
                ])
                
            elif 'output_url' in result or 'image_url' in result:
                # Untuk tool image processing
                output_url = result.get('output_url') or result.get('image_url')
                put_html("<h4>🖼️ Processed Image:</h4>")
                put_image(output_url, width="400px")
                put_link("🔗 Download Result", output_url, new_window=True)
                
            else:
                # Fallback: tampilkan raw JSON
                put_collapse("📊 Raw Response", 
                            put_code(json.dumps(result, indent=2, ensure_ascii=False), language='json'))
            
            # Tombol untuk menggunakan tool lagi
            put_buttons(['🛠️ Gunakan Tool Lain'], onclick=lambda: run_js('location.reload()'))

    except httpx.HTTPStatusError as e:
        with use_scope("result_scope", clear=True):
            put_error(f"❌ HTTP Error {e.response.status_code}", 
                     f"Gagal memproses: {e.response.text}")
            put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))
            
    except httpx.RequestError as e:
        with use_scope("result_scope", clear=True):
            put_error("🌐 Connection Error", 
                     f"Tidak dapat terhubung ke server: {str(e)}")
            put_html("<p>Pastikan server API sedang berjalan di localhost:8000</p>")
            
    except Exception as e:
        with use_scope("result_scope", clear=True):
            error_detail = ""
            if hasattr(e, 'response') and e.response:
                try:
                    error_detail = e.response.json().get('detail', str(e))
                except:
                    error_detail = str(e)
            else:
                error_detail = str(e)
                
            put_error("💥 Terjadi Kesalahan", error_detail)
            put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))