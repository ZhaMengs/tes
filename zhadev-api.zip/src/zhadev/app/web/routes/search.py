# /zhadev/app/web/routes/search.py

import httpx
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env
from .utils import render_navbar

try:
    from bs4 import BeautifulSoup
except ImportError:
    # Fallback jika BeautifulSoup tidak tersedia
    class BeautifulSoup:
        @staticmethod
        def get_text(html):
            return html

API_BASE_URL = "http://localhost:8000/api/v1/search"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Search."""
    set_env(title="ZhaDev Tools - Universal Search")
    render_navbar(active_page='search')
    put_html("<h1 align='center'><strong>🔍 Universal Search</strong></h1>")
    
    put_markdown("""
    **Cari konten dari berbagai platform:**
    - 🎬 **YouTube** - Video dan channel
    - 🎵 **TikTok** - Video pendek
    - 📌 **Pinterest** - Gambar dan ide
    - 🇨🇳 **Bilibili** - Video dari China
    - 🎮 **Donghub** - Konten donghua
    - 🌤️ **Weather** - Info cuaca
    - 📖 **Recipes** - Resep masakan
    - 🕌 **Prayer Schedule** - Jadwal sholat
    - 🇯🇵 **Anime Schedule** - Jadwal anime
    - 🇨🇳 **Donghua Schedule** - Jadwal donghua
    - 🌋 **Earthquake** - Info gempa terkini
    """)

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            data = await input_group("Cari Konten", [
                select("Pilih Platform", name="platform", options=[
                    ("🎬 YouTube", "youtube"),
                    ("🎵 TikTok", "tiktok"),
                    ("🎮 Donghub", "donghub"),
                    ("📌 Pinterest", "pinterest"),
                    ("🇨🇳 Bilibili", "bilibili"),
                    ("🌤️ Weather", "weather"),
                    ("📖 Recipes", "recipes"),
                    ("🕌 Prayer Schedule", "prayer_schedule"),
                    ("🇯🇵 Anime Schedule", "anime_schedule"),
                    ("🇨🇳 Donghua Schedule", "donghua_schedule"),
                    ("🌋 Earthquake", "earthquake"),
                ]),
                input("Masukkan Kata Kunci", name="q", type="text", required=True,
                     placeholder="Masukkan query pencarian..."),
            ])
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow', color='primary')
            put_html(f"<center>🔍 Mencari '{data['q']}' di {data['platform']}...</center>")  # ← PERBAIKAN DI SINI

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{data['platform']}/",
                    params={"q": data['q'], "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                results = response.json().get('data', [])

            with use_scope("result_scope", clear=True):
                if not results:
                    put_warning(f"❌ Tidak ada hasil yang ditemukan untuk '{data['q']}' di {data['platform']}.")
                else:
                    put_success(f"✅ Ditemukan {len(results)} hasil untuk '{data['q']}':")
                    
                    # Handle different types of search results
                    if data['platform'] in ['weather', 'earthquake', 'prayer_schedule']:
                        # Info-based results (non-video)
                        for item in results:
                            put_table([
                                ['Field', 'Value']
                            ] + [[k, v] for k, v in item.items()])
                            put_markdown("---")
                            
                    elif data['platform'] in ['anime_schedule', 'donghua_schedule']:
                        # Schedule results
                        for item in results:
                            put_table([
                                ['Anime', 'Day', 'Time', 'Studio'],
                                [item.get('title', 'N/A'), item.get('day', 'N/A'), 
                                 item.get('time', 'N/A'), item.get('studio', 'N/A')]
                            ])
                            put_markdown("---")
                            
                    elif data['platform'] == 'recipes':
                        # Recipe results
                        for item in results:
                            put_html(f"<h3>🍳 {item.get('title', 'N/A')}</h3>")
                            put_markdown(f"**Bahan:** {item.get('ingredients', 'N/A')}")
                            put_markdown(f"**Cara Masak:** {item.get('instructions', 'N/A')}")
                            put_markdown("---")
                            
                    else:
                        # Video/Image platforms
                        table_data = []
                        for item in results:
                            # Clean title from HTML tags
                            title = item.get('title', 'N/A')
                            if isinstance(title, str) and '<' in title:
                                title = BeautifulSoup.get_text(title)
                            
                            # Create table row
                            row = [
                                put_image(item.get('cover_url', ''), width='120px', height='80px') 
                                if item.get('cover_url') else put_text("No Image"),
                                put_markdown(f"**{title}**\n\n👤 **Author:** {item.get('author', 'N/A')}\n\n🔗 [Buka Link]({item.get('url', '#')})")
                            ]
                            table_data.append(row)
                        
                        put_table(table_data, header=["🎬 Thumbnail", "📋 Detail"])

        except httpx.HTTPStatusError as e:
            with use_scope("result_scope", clear=True):
                put_error(f"❌ HTTP Error {e.response.status_code}", 
                         f"Gagal melakukan pencarian: {e.response.text}")
                
        except httpx.RequestError as e:
            with use_scope("result_scope", clear=True):
                put_error("🌐 Connection Error", 
                         f"Tidak dapat terhubung ke server: {str(e)}")
                put_html("<p>Pastikan server API sedang berjalan di localhost:8000</p>")
                
        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = ""
                if hasattr(e, 'response') and e.response:
                    try:
                        error_detail = e.response.json().get('detail', str(e))
                    except:
                        error_detail = str(e)
                else:
                    error_detail = str(e)
                    
                put_error("💥 Terjadi Kesalahan", error_detail)