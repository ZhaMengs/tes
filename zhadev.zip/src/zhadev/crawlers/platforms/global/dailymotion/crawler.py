import yaml
import httpx
from typing import Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import DailymotionEndpoints
from .models import DailymotionAPIRawResponse, DailymotionVideoData, AuthorInfo, StreamInfo, StatisticsInfo
from .utils import extract_video_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class DailymotionCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Dailymotion yang menggunakan GraphQL API
    dan mekanisme pengambilan cookie otomatis.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['dailymotion']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        self._is_session_initialized = False

    async def _initialize_session(self, client: httpx.AsyncClient):
        """
        Mengunjungi halaman utama untuk mendapatkan cookie sesi (guest)
        sebelum melakukan panggilan GraphQL.
        """
        if self._is_session_initialized:
            return
        try:
            await client.get(DailymotionEndpoints.BASE_URL)
            self._is_session_initialized = True
            print("Sesi Dailymotion berhasil diinisialisasi, cookie didapatkan.")
        except httpx.RequestError as e:
            raise CrawlingError(f"Gagal menginisialisasi sesi Dailymotion: {e}")

    def _build_graphql_query(self) -> str:
        """Membangun query GraphQL yang kompleks untuk mengambil semua data video."""
        return """
        query VideoQuery($videoId: ID!) {
          video(id: $videoId) {
            id
            title
            description
            owner {
              screenname
              url
            }
            viewsTotal
            qualities {
              auto {
                type
                url
              }
            }
            posterURL
            createdTime
          }
        }
        """

    async def get_video_data(self, url: str) -> DailymotionVideoData:
        """
        Metode utama untuk mengambil data video Dailymotion.
        """
        # 1. Ekstrak Video ID dari URL
        video_id = await extract_video_id(url)
        
        client = await self._get_client()
        
        # 2. Inisialisasi Sesi (Ambil Cookie Otomatis)
        await self._initialize_session(client)
        
        # 3. Siapkan dan lakukan panggilan GraphQL
        graphql_payload = {
            "query": self._build_graphql_query(),
            "variables": {"videoId": video_id},
            "operationName": "VideoQuery"
        }
        
        try:
            response_json = await self.post_json(DailymotionEndpoints.GRAPHQL_API, json=graphql_payload)
            validated_response = DailymotionAPIRawResponse.model_validate(response_json)

            if validated_response.errors or not validated_response.data or not validated_response.data.video:
                error_msg = validated_response.errors[0]['message'] if validated_response.errors else "Data video tidak ditemukan."
                raise ContentNotFoundError(f"API GraphQL Dailymotion mengembalikan error: {error_msg}")
            
            video_raw_data = validated_response.data.video
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API GraphQL Dailymotion berubah. Detail: {e}")

        # 4. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(video_raw_data)

    def _transform_to_clean_data(self, raw_data: Any) -> DailymotionVideoData:
        """
        Mengubah objek data mentah dari GraphQL menjadi model Pydantic yang bersih.
        """
        author_info = AuthorInfo(**raw_data.owner.model_dump())
        stats_info = StatisticsInfo(views=raw_data.views_total)
        
        streams = []
        if raw_data.qualities and raw_data.qualities.auto:
            for stream in raw_data.qualities.auto:
                # Menentukan format berdasarkan tipe MIME
                stream_format = "HLS" if "mpegURL" in stream.type else "Unknown"
                streams.append(StreamInfo(
                    quality="auto",
                    format=stream_format,
                    url=stream.url
                ))

        return DailymotionVideoData(
            id=raw_data.id,
            title=raw_data.title,
            description=raw_data.description,
            created_at_timestamp=raw_data.created_time,
            author=author_info,
            cover_url=raw_data.poster_url,
            statistics=stats_info,
            streams=streams
        )
