# zhadev/src/zhadev/crawlers/platforms/global/facebook/crawler.py

import os
import re
import json
import yaml
from typing import Any

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import FacebookEndpoints
from .models import FacebookVideoData, AuthorInfo, StatisticsInfo, StreamInfo
from .utils import extract_video_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class FacebookCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Facebook. Beroperasi dalam mode terbatas tanpa
    login, menargetkan konten video publik.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['facebook']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        # Ambil cookie dari config jika ada
        self.cookie = config.get('cookie')
        if self.cookie:
            config['headers']['Cookie'] = self.cookie
            print("Info: Cookie Facebook ditemukan, crawler berjalan dalam mode autentikasi.")
        else:
            print("Peringatan: Tidak ada cookie Facebook. Crawler berjalan dalam mode terbatas (hanya konten publik).")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_video_data(self, url: str) -> FacebookVideoData:
        """
        Metode utama untuk mengambil data video publik dari Facebook.
        """
        video_id = await extract_video_id(url)
        
        # Gunakan mbasic untuk HTML yang lebih sederhana
        video_url = f"{FacebookEndpoints.MBASIC_URL}/video.php?v={video_id}"
        
        try:
            html = await self.fetch_text(video_url)
            soup = BeautifulSoup(html, "html.parser")

            # Mencari data video dari berbagai kemungkinan lokasi di HTML
            sd_url, hd_url = self._find_stream_urls(html, soup)
            
            if not sd_url:
                raise ContentNotFoundError("Tidak dapat menemukan URL video. Konten mungkin tidak publik atau memerlukan login.")

            streams = []
            streams.append(StreamInfo(quality="SD", url=sd_url))
            if hd_url:
                streams.append(StreamInfo(quality="HD", url=hd_url))

            # Scraping metadata
            author_tag = soup.find('h3').find('a')
            author_info = AuthorInfo(
                name=author_tag.text,
                url=f"{FacebookEndpoints.BASE_URL}{author_tag['href']}"
            )
            
            text_content_tag = soup.select_one('div[data-ft] > p, div.msg > p')
            text_content = text_content_tag.text if text_content_tag else ""

            published_at_tag = soup.find('abbr')
            published_at = published_at_tag.text if published_at_tag else None

            # PERINGATAN: Statistik seringkali tidak tersedia tanpa login
            stats_info = StatisticsInfo() 
            thumbnail_url = soup.find('img', class_='bi')['src'] if soup.find('img', class_='bi') else None

            return FacebookVideoData(
                id=video_id,
                url=url,
                text_content=text_content,
                published_at=published_at,
                author=author_info,
                statistics=stats_info,
                streams=streams,
                thumbnail_url=thumbnail_url
            )
        except ContentNotFoundError as e:
            raise e # Lemparkan kembali error ContentNotFoundError
        except Exception as e:
            raise ParsingError(f"Gagal mem-parsing halaman video Facebook. Struktur web mungkin berubah. Error: {e}")

    def _find_stream_urls(self, html: str, soup: BeautifulSoup) -> (Optional[str], Optional[str]):
        """Mencari URL stream SD dan HD dari berbagai pola di dalam HTML."""
        # Pola 1: Mencari link langsung di dalam tag <a>
        video_link = soup.find("a", href=lambda href: href and "/video_redirect/" in href)
        if video_link:
            redirect_url = urlparse(video_link['href'])
            query_params = parse_qs(redirect_url.query)
            sd_url = query_params.get('src', [None])[0]
            return sd_url, None # HD sering tidak ada di sini

        # Pola 2: Mencari di dalam data JSON yang ter-embed
        # Pola ini lebih canggih dan sering digunakan pada web modern
        sd_match = re.search(r'sd_src_no_ratelimit:"([^"]+)"', html)
        hd_match = re.search(r'hd_src_no_ratelimit:"([^"]+)"', html)
        
        sd_url = sd_match.group(1).replace('\\', '') if sd_match else None
        hd_url = hd_match.group(1).replace('\\', '') if hd_match else None
        
        if sd_url or hd_url:
            return sd_url, hd_url
            
        return None, None