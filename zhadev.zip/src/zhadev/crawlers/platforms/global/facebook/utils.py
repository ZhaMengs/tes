# zhadev/src/zhadev/crawlers/platforms/global/facebook/utils.py

import re
from urllib.parse import urlparse, unquote

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak ID video dari berbagai format URL Facebook
# Contoh: /videos/12345, /watch/?v=12345, fbid=12345
VIDEO_ID_PATTERNS = [
    re.compile(r"/videos/(?:vb\.\d+/)?(\d+)"),
    re.compile(r"/watch/?\?v=(\d+)"),
    re.compile(r"fbid=(\d+)"),
    re.compile(r"/reel/(\d+)"),
]

async def extract_video_id(url: str) -> str:
    """
    Mengekstrak Video ID dari URL Facebook.
    
    :param url: URL video Facebook.
    :return: String Video ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    # Dekode URL untuk menangani karakter seperti %3A
    decoded_url = unquote(url)
    
    for pattern in VIDEO_ID_PATTERNS:
        match = pattern.search(decoded_url)
        if match:
            return match.group(1)
            
    # Fallback untuk URL yang lebih kompleks
    parsed_url = urlparse(decoded_url)
    if 'v' in parsed_url.path.split('/'):
        try:
            return parsed_url.path.split('/')[-2]
        except IndexError:
            pass

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Video ID dari URL: {url}")