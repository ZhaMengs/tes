import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak ID Template dari path URL.
# Contoh: /template-detail/7294212953491442945
TEMPLATE_ID_PATTERN = re.compile(r"/template-detail/([a-zA-Z0-9_-]+)")

async def extract_template_id(url: str) -> str:
    """
    Mengekstrak Template ID dari URL CapCut.
    
    :param url: URL template CapCut.
    :return: String Template ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = TEMPLATE_ID_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Template ID dari URL: {url}")
