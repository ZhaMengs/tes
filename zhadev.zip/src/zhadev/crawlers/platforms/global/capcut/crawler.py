import yaml
import httpx
from typing import Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import CapcutEndpoints
from .models import CapcutAPIRawResponse, CapcutTemplateData, AuthorInfo, VideoInfo, MusicInfo, StatisticsInfo
from .utils import extract_template_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class CapcutCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk CapCut dengan mekanisme pengambilan cookie otomatis.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['capcut']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        self._is_session_initialized = False

    async def _initialize_session(self, client: httpx.AsyncClient):
        """
        Secara otomatis "mengunjungi" halaman utama untuk mendapatkan cookie sesi (guest)
        yang diperlukan sebelum melakukan panggilan API.
        """
        if self._is_session_initialized:
            return
            
        try:
            await client.get(CapcutEndpoints.BASE_URL)
            self._is_session_initialized = True
            print("Sesi CapCut berhasil diinisialisasi, cookie didapatkan.")
        except httpx.RequestError as e:
            raise CrawlingError(f"Gagal menginisialisasi sesi dan mendapatkan cookie dari CapCut: {e}")

    async def get_template_data(self, url: str) -> CapcutTemplateData:
        """
        Metode utama untuk mengambil data template CapCut.
        """
        # 1. Ekstrak Template ID dari URL
        template_id = await extract_template_id(url)
        
        # Dapatkan klien HTTPX dari BaseCrawler
        client = await self._get_client()
        
        # 2. Inisialisasi Sesi (Ambil Cookie Secara Otomatis)
        await self._initialize_session(client)
        
        # 3. Panggil API detail template
        params = {"template_id": template_id}
        try:
            response_json = await self.fetch_json(CapcutEndpoints.TEMPLATE_DETAIL, params=params)
            validated_response = CapcutAPIRawResponse.model_validate(response_json)

            if validated_response.code != 0 or not validated_response.data:
                raise ContentNotFoundError(f"API CapCut mengembalikan error: {validated_response.message}")
            
            template_raw_data = validated_response.data
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API CapCut berubah. Detail: {e}")

        # 4. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(template_raw_data)

    def _transform_to_clean_data(self, raw_data: Any) -> CapcutTemplateData:
        """
        Mengubah objek data mentah dari API menjadi model Pydantic yang bersih.
        """
        author_info = AuthorInfo(**raw_data.author_info.model_dump())
        video_info = VideoInfo(**raw_data.video_info.model_dump())
        music_info = MusicInfo(**raw_data.music_info.model_dump()) if raw_data.music_info else None
        
        stats_info = StatisticsInfo(
            usage_count=raw_data.usage_amount,
            like_count=raw_data.like_count
        )

        return CapcutTemplateData(
            id=raw_data.id,
            title=raw_data.title,
            description=raw_data.description,
            created_at_timestamp=raw_data.create_time,
            author=author_info,
            video=video_info,
            music=music_info,
            statistics=stats_info
        )
