# zhadev/src/zhadev/crawlers/platforms/global/github/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime

# ==============================================================================
# Model-model ini secara ketat memetakan respons dari API resmi GitHub.
# ==============================================================================

class OwnerInfo(BaseModel):
    login: str
    id: int
    avatar_url: str = Field(..., alias="avatarUrl")
    html_url: str = Field(..., alias="htmlUrl")

class RepoInfo(BaseModel):
    """Mewakili data detail dari sebuah repositori."""
    id: int
    name: str
    full_name: str = Field(..., alias="fullName")
    owner: OwnerInfo
    private: bool
    html_url: str = Field(..., alias="htmlUrl")
    description: Optional[str] = None
    fork: bool
    url: str
    created_at: datetime = Field(..., alias="createdAt")
    updated_at: datetime = Field(..., alias="updatedAt")
    pushed_at: datetime = Field(..., alias="pushedAt")
    stargazers_count: int = Field(..., alias="stargazersCount")
    watchers_count: int = Field(..., alias="watchersCount")
    forks_count: int = Field(..., alias="forksCount")
    open_issues_count: int = Field(..., alias="openIssuesCount")
    license: Optional[Dict] = None
    topics: List[str]

class ReleaseAsset(BaseModel):
    """Mewakili satu file aset dalam sebuah rilis (misalnya .zip, .exe)."""
    id: int
    name: str
    label: Optional[str] = None
    content_type: str = Field(..., alias="contentType")
    size: int # dalam bytes
    download_count: int = Field(..., alias="downloadCount")
    browser_download_url: str = Field(..., alias="browserDownloadUrl")

class ReleaseInfo(BaseModel):
    """Mewakili data dari rilis terbaru sebuah repositori."""
    id: int
    tag_name: str = Field(..., alias="tagName")
    name: Optional[str] = None
    body: Optional[str] = None # Deskripsi rilis dalam Markdown
    prerelease: bool
    created_at: datetime = Field(..., alias="createdAt")
    published_at: datetime = Field(..., alias="publishedAt")
    assets: List[ReleaseAsset]