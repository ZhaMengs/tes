# zhadev/src/zhadev/crawlers/platforms/global/github/crawler.py

import os
import yaml
from typing import Any

from pydantic import ValidationError, TypeAdapter
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import GitHubEndpoints
from .models import RepoInfo, ReleaseInfo
from .utils import parse_repo_url

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class GitHubCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk GitHub yang menggunakan API resmi.
    Mendukung mode terautentikasi (dengan token) dan anonim.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['github']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        # Cek jika token ada, dan tambahkan ke header secara dinamis
        auth_token = config.get('auth_token')
        if auth_token:
            print("Info: Token GitHub ditemukan. Menggunakan mode terautentikasi.")
            config['headers']['Authorization'] = f"Bearer {auth_token}"
        else:
            print("Peringatan: Tidak ada token GitHub. Menggunakan mode anonim (rate limit 60/jam).")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_repo_info(self, repo_url: str) -> RepoInfo:
        """
        Mengambil informasi detail dari sebuah repositori GitHub.
        """
        # 1. Parsing URL untuk mendapatkan owner dan repo
        owner, repo = await parse_repo_url(repo_url)
        
        # 2. Bangun URL API
        api_url = f"{GitHubEndpoints.API_BASE_URL}{GitHubEndpoints.REPO_DETAIL.format(owner=owner, repo=repo)}"
        
        try:
            # 3. Panggil API
            response_json = await self.fetch_json(api_url)
            
            # 4. Validasi dan parsing dengan Pydantic
            # GitHub menggunakan snake_case, Pydantic v2 otomatis mengonversinya ke camelCase
            # jika model didefinisikan dengan alias. Untuk v1 perlu konfigurasi.
            # Kita akan konversi manual di sini untuk kejelasan.
            response_camel = self._snake_to_camel(response_json)
            repo_info = RepoInfo.model_validate(response_camel)
            return repo_info
            
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API GitHub (repo) berubah. Detail: {e}")
        except ContentNotFoundError as e: # API mengembalikan 404
             raise ContentNotFoundError(f"Repositori '{owner}/{repo}' tidak ditemukan.")

    async def get_latest_release(self, repo_url: str) -> ReleaseInfo:
        """
        Mengambil informasi rilis terbaru, termasuk aset unduhan.
        """
        owner, repo = await parse_repo_url(repo_url)
        api_url = f"{GitHubEndpoints.API_BASE_URL}{GitHubEndpoints.LATEST_RELEASE.format(owner=owner, repo=repo)}"
        
        try:
            response_json = await self.fetch_json(api_url)
            response_camel = self._snake_to_camel(response_json)
            release_info = ReleaseInfo.model_validate(response_camel)
            return release_info
            
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API GitHub (release) berubah. Detail: {e}")
        except ContentNotFoundError:
             raise ContentNotFoundError(f"Tidak ada rilis yang ditemukan untuk repositori '{owner}/{repo}'.")

    def _snake_to_camel(self, data: Any) -> Any:
        """

        Konverter rekursif untuk mengubah kunci dictionary dari snake_case ke camelCase
        agar sesuai dengan alias model Pydantic.
        """
        if isinstance(data, dict):
            camel_dict = {}
            for key, value in data.items():
                parts = key.split('_')
                camel_key = parts[0] + ''.join(x.title() for x in parts[1:])
                camel_dict[camel_key] = self._snake_to_camel(value)
            return camel_dict
        elif isinstance(data, list):
            return [self._snake_to_camel(item) for item in data]
        return data