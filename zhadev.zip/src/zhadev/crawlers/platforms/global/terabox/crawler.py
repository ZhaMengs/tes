# zhadev/src/zhadev/crawlers/platforms/global/terabox/crawler.py

import os
import re
import json
import yaml
import httpx
from typing import Any, Dict

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import TeraboxEndpoints
from .models import ShareListRawResponse, TeraboxFileData
from .utils import extract_share_key

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class TeraboxCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Terabox. Mengimplementasikan alur multi-langkah
    untuk mengekstrak link unduhan langsung.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['terabox']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_download_data(self, url: str) -> TeraboxFileData:
        """
        Metode utama untuk mendapatkan link unduhan langsung dari URL Terabox.
        """
        client = await self._get_client()
        
        # 1. Kunjungi URL asli untuk mendapatkan cookie sesi awal.
        try:
            initial_response = await client.get(url, follow_redirects=True)
            initial_response.raise_for_status()
            final_url = str(initial_response.url)
        except httpx.HTTPStatusError as e:
            raise ContentNotFoundError(f"URL Terabox tidak valid atau tidak dapat diakses. Status: {e.response.status_code}")
        
        share_key = await extract_share_key(final_url)
        
        # 2. Ekstrak data JS dari HTML untuk panggilan API berikutnya
        html_content = initial_response.text
        try:
            js_token_match = re.search(r'var\s+jsToken\s*=\s*"([^"]+)"', html_content)
            share_id_match = re.search(r'"shareid":(\d+)', html_content)
            uk_match = re.search(r'"uk":(\d+)', html_content)
            
            if not js_token_match or not share_id_match or not uk_match:
                raise ParsingError("Tidak dapat menemukan token atau ID penting di halaman. Struktur mungkin berubah.")

            js_token = js_token_match.group(1)
            share_id = int(share_id_match.group(1))
            uk = int(uk_match.group(1))
        except Exception as e:
             raise ParsingError(f"Gagal mengekstrak data dari HTML: {e}")

        # 3. Lakukan Panggilan API Pertama (/share/list) untuk mendapatkan info file
        params_list = {
            "app_id": "250528",
            "shorturl": share_key,
            "root": "1",
            "jsToken": js_token,
        }
        
        try:
            # Panggilan ini memerlukan cookie dari kunjungan awal
            list_response_json = await self.fetch_json(TeraboxEndpoints.SHARE_LIST, params=params_list)
            validated_list = ShareListRawResponse.model_validate(list_response_json)
            
            if validated_list.errno != 0 or not validated_list.list:
                raise ContentNotFoundError("API Terabox (list) tidak mengembalikan data file.")
                
            file_info = validated_list.list[0]
            
        except (ValidationError, IndexError) as e:
            raise ParsingError(f"Struktur respons API Terabox (list) berubah. Detail: {e}")

        # 4. Lakukan Panggilan API Kedua untuk mendapatkan link unduhan (dlink)
        # Endpoint ini seringkali sama dengan /share/list tapi dengan parameter berbeda
        params_download = {
            "app_id": "250528",
            "shorturl": share_key,
            "shareid": share_id,
            "uk": uk,
            "fsid": file_info.fs_id,
            "jsToken": js_token,
            "type": "download"
        }
        
        try:
            # Perhatikan: Terabox seringkali menyembunyikan dlink di dalam respons yang sama
            # dengan panggilan /list, tetapi dengan parameter yang berbeda.
            # Kita panggil lagi dengan parameter 'download'.
            download_response_json = await self.fetch_json(TeraboxEndpoints.SHARE_LIST, params=params_download)
            direct_download_url = download_response_json.get('dlink')
            
            if not direct_download_url:
                raise ParsingError("API Terabox tidak mengembalikan 'dlink' di respons kedua.")
        except Exception as e:
            raise ParsingError(f"Gagal mendapatkan link unduhan langsung dari API. Error: {e}")

        # 5. Transformasi data ke model akhir
        return self._transform_to_clean_data(share_key, file_info, direct_download_url)
    
    def _transform_to_clean_data(self, share_key: str, file_info: Any, dlink: str) -> TeraboxFileData:
        """
        Menggabungkan data dari berbagai sumber menjadi model output yang bersih.
        """
        return TeraboxFileData(
            share_key=share_key,
            file_id=file_info.fs_id,
            file_name=file_info.server_filename,
            size_bytes=file_info.size,
            direct_download_url=dlink
        )