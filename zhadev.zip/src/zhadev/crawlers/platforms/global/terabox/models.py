# zhadev/src/zhadev/crawlers/platforms/global/terabox/models.py

from pydantic import BaseModel, Field
from typing import List, Optional

# ==============================================================================
# Model-model ini dirancang untuk mem-parsing data dari panggilan API internal
# dan data JSON yang ter-embed di halaman.
# ==============================================================================

class FileInfoRaw(BaseModel):
    """Mewakili satu file dalam daftar share."""
    fs_id: int = Field(..., alias="fs_id")
    path: str
    server_filename: str = Field(..., alias="server_filename")
    size: int # dalam bytes

class ShareListRawResponse(BaseModel):
    """Memetakan respons dari API /share/list."""
    errno: int
    list: List[FileInfoRaw]
    shareid: int
    uk: int # User ID

class TeraboxFileData(BaseModel):
    """Output akhir yang komprehensif dari Terabox Crawler."""
    status: str = "success"
    platform: str = "terabox"
    share_key: str
    file_id: int
    file_name: str
    size_bytes: int
    direct_download_url: str