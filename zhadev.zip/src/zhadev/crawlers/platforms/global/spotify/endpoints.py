# zhadev/src/zhadev/crawlers/platforms/global/spotify/endpoints.py

class SpotifyEndpoints:
    """
    Menyimpan endpoint utama untuk API Spotify.
    """
    # Endpoint untuk autentikasi dan mendapatkan access token.
    AUTH_URL: str = "https://accounts.spotify.com/api/token"

    # Base URL untuk semua panggilan API data.
    API_BASE_URL: str = "https://api.spotify.com/v1"

    # Endpoint untuk mencari item (lagu, artis, album).
    SEARCH: str = f"{API_BASE_URL}/search"
    
    # Endpoint untuk mendapatkan detail sebuah lagu (track).
    TRACK_DETAIL: str = f"{API_BASE_URL}/tracks/{{id}}"