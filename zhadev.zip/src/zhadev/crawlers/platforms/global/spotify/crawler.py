# zhadev/src/zhadev/crawlers/platforms/global/spotify/crawler.py

import os
import yaml
import time
import base64
from typing import Any, Dict

from pydantic import ValidationError, TypeAdapter
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import SpotifyEndpoints
from .models import TrackInfo
from .utils import parse_spotify_url

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class SpotifyCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Spotify yang menggunakan API resmi dengan
    Client Credentials Flow untuk autentikasi otomatis.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['spotify']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        self.client_id = config.get('client_id')
        self.client_secret = config.get('client_secret')
        if not self.client_id or not self.client_secret:
            raise CrawlingError("`client_id` dan `client_secret` wajib ada di config.yaml untuk Spotify.")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        self._access_token: Optional[str] = None
        self._token_expiry_time: int = 0

    async def _get_access_token(self) -> str:
        """
        Mendapatkan access token baru jika tidak ada atau sudah kedaluwarsa.
        Ini adalah inti dari Client Credentials Flow.
        """
        # Cek jika token masih valid
        if self._access_token and time.time() < self._token_expiry_time:
            return self._access_token

        print("Info: Access token Spotify tidak ada atau kedaluwarsa, meminta yang baru...")
        auth_header = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode()).decode()
        
        headers = {
            "Authorization": f"Basic {auth_header}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {"grant_type": "client_credentials"}
        
        try:
            response = await self.post_json(SpotifyEndpoints.AUTH_URL, headers=headers, data=data)
            self._access_token = response['access_token']
            # Kurangi sedikit waktu kedaluwarsa untuk margin keamanan
            self._token_expiry_time = time.time() + response['expires_in'] - 60 
            print("Info: Access token Spotify berhasil didapatkan.")
            return self._access_token
        except Exception as e:
            raise CrawlingError(f"Gagal mendapatkan access token dari Spotify. Periksa Client ID/Secret. Error: {e}")

    async def _make_api_call(self, url: str, params: Dict = None) -> Any:
        """Wrapper untuk melakukan panggilan API dengan token autentikasi."""
        token = await self._get_access_token()
        headers = self.headers.copy()
        headers['Authorization'] = f"Bearer {token}"
        
        return await self.fetch_json(url, headers=headers, params=params)

    async def get_track_data(self, track_url: str) -> TrackInfo:
        """
        Mengambil informasi detail dari sebuah lagu (track) Spotify.
        """
        content_type, track_id = await parse_spotify_url(track_url)
        
        if content_type != 'track':
            raise ContentNotFoundError(f"URL yang diberikan bukan URL lagu (track). Tipe terdeteksi: {content_type}")
        
        api_url = SpotifyEndpoints.TRACK_DETAIL.format(id=track_id)
        
        try:
            response_json = await self._make_api_call(api_url)
            
            # Konversi snake_case ke camelCase untuk Pydantic
            response_camel = self._snake_to_camel(response_json)
            track_info = TrackInfo.model_validate(response_camel)
            return track_info
            
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Spotify (track) berubah. Detail: {e}")
        except ContentNotFoundError as e:
             raise ContentNotFoundError(f"Lagu dengan ID '{track_id}' tidak ditemukan.")

    def _snake_to_camel(self, data: Any) -> Any:
        """
        Konverter rekursif untuk mengubah kunci dictionary dari snake_case ke camelCase.
        """
        if isinstance(data, dict):
            camel_dict = {}
            for key, value in data.items():
                parts = key.split('_')
                camel_key = parts[0] + ''.join(x.title() for x in parts[1:])
                camel_dict[camel_key] = self._snake_to_camel(value)
            return camel_dict
        elif isinstance(data, list):
            return [self._snake_to_camel(item) for item in data]
        return data