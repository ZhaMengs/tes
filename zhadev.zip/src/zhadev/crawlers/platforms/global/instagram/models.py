# zhadev/src/zhadev/crawlers/platforms/global/instagram/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari GraphQL API (Raw API Models)
# ==============================================================================

class OwnerRaw(BaseModel):
    id: str
    username: str
    profile_pic_url: str = Field(..., alias="profile_pic_url")

class EdgeMediaToCaption(BaseModel):
    edges: List[Dict[str, Dict[str, str]]]

class EdgeSidecarToChildren(BaseModel):
    edges: List[Dict[str, Any]] # Untuk postingan carousel/album

class PostMediaRaw(BaseModel):
    id: str
    shortcode: str
    display_url: str = Field(..., alias="display_url")
    is_video: bool = Field(..., alias="is_video")
    video_url: Optional[str] = Field(None, alias="video_url")
    owner: OwnerRaw
    edge_media_to_caption: EdgeMediaToCaption = Field(..., alias="edge_media_to_caption")
    edge_sidecar_to_children: Optional[EdgeSidecarToChildren] = Field(None, alias="edge_sidecar_to_children")
    taken_at_timestamp: int = Field(..., alias="taken_at_timestamp")
    
class GraphQLData(BaseModel):
    shortcode_media: Optional[PostMediaRaw] = Field(None, alias="shortcode_media")

class InstagramAPIRawResponse(BaseModel):
    data: GraphQLData

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    id: str
    username: str
    avatar_url: str

class MediaItem(BaseModel):
    type: str # 'image' atau 'video'
    display_url: str
    video_url: Optional[str] = None

class InstagramPostData(BaseModel):
    """Output akhir yang komprehensif dari Instagram Crawler."""
    status: str = "success"
    platform: str = "instagram"
    id: str
    shortcode: str
    caption: str
    created_at_timestamp: int
    author: AuthorInfo
    media_items: List[MediaItem] # Daftar media, bisa 1 (post tunggal) atau lebih (carousel)