# zhadev/src/zhadev/crawlers/platforms/global/instagram/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak "shortcode" dari URL post atau reel
# Contoh: /p/CqZ1Xy.../ atau /reel/CqZ1Xy.../
SHORTCODE_PATTERN = re.compile(r"/(?:p|reel)/([a-zA-Z0-9_-]+)")

class GraphQLHashes:
    """
    Menyimpan nilai `query_hash` yang diperlukan untuk memanggil endpoint
    GraphQL Instagram. Hash ini bisa berubah jika Instagram update.
    """
    POST_DETAIL: str = "bfa387b2992c3a52dcbe447467b4b771"

async def extract_shortcode(url: str) -> str:
    """
    Mengekstrak shortcode dari URL postingan Instagram.
    
    :param url: URL postingan Instagram.
    :return: String shortcode.
    :raises ContentNotFoundError: Jika shortcode tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = SHORTCODE_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak shortcode dari URL: {url}")