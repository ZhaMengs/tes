# zhadev/src/zhadev/crawlers/platforms/global/instagram/__init__.py

from .crawler import InstagramCrawler

__all__ = ["InstagramCrawler"]