# zhadev/src/zhadev/crawlers/platforms/global/pinterest/endpoints.py

class PinterestEndpoints:
    """
    Menyimpan endpoint utama untuk Pinterest.
    """
    BASE_URL: str = "https://www.pinterest.com"