# zhadev/src/zhadev/crawlers/platforms/global/pinterest/__init__.py

from .crawler import PinterestCrawler

__all__ = ["PinterestCrawler"]