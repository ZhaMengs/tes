# zhadev/src/zhadev/crawlers/platforms/global/pinterest/crawler.py

import os
import json
import yaml
from typing import Any, Dict

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import PinterestEndpoints
from .models import PinterestPinData, PinnerInfo, MediaInfo, MediaURL, StatisticsInfo
from .utils import extract_pin_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class PinterestCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Pinterest. Bekerja dengan mengekstrak
    blok data JSON dari sumber halaman, bukan dari API call biasa.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['pinterest']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_pin_data(self, url: str) -> PinterestPinData:
        """
        Metode utama untuk mengambil data Pin dari URL Pinterest.
        """
        pin_id = await extract_pin_id(url)
        
        # 1. Ambil konten HTML halaman Pin
        html = await self.fetch_text(url)
        soup = BeautifulSoup(html, "html.parser")
        
        # 2. Cari blok data JSON yang tersembunyi di dalam tag <script>
        data_script = soup.find("script", id="__PWS_INITIAL_PROPS__")
        if not data_script:
            raise ParsingError("Tidak dapat menemukan blok data JSON (__PWS_INITIAL_PROPS__). Struktur halaman mungkin berubah.")
            
        try:
            # 3. Parse JSON dan navigasi ke data Pin yang relevan
            initial_data = json.loads(data_script.string)
            pin_data_raw = initial_data['props']['initialReduxState']['pins'][pin_id]
        except (json.JSONDecodeError, KeyError) as e:
            raise ParsingError(f"Gagal mem-parsing atau menavigasi data JSON. Mungkin Anda memerlukan cookie login. Error: {e}")

        # 4. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(pin_data_raw)

    def _transform_to_clean_data(self, raw_data: Dict[str, Any]) -> PinterestPinData:
        """
        Mengubah dictionary data mentah dari JSON menjadi model Pydantic yang bersih.
        """
        pinner_id = raw_data['pinner']['id']
        pinner_raw = raw_data['pinner']
        pinner_info = PinnerInfo(
            id=pinner_id,
            username=pinner_raw['username'],
            full_name=pinner_raw['full_name'],
            avatar_url=pinner_raw['image_xlarge_url']
        )
        
        is_video = 'videos' in raw_data and raw_data['videos'] is not None
        
        if is_video:
            video_list = raw_data['videos']['video_list']
            # Ambil kualitas video terbaik (biasanya yang terakhir)
            best_video = video_list[list(video_list.keys())[-1]]
            media = MediaInfo(
                type='video',
                original_url=best_video['url'],
                video_versions={key: MediaURL(**val) for key, val in video_list.items()}
            )
        else:
            image_urls = raw_data['images']
            # Ambil resolusi gambar 'originals'
            original_image = image_urls['orig']
            media = MediaInfo(
                type='image',
                original_url=original_image['url'],
                image_versions={key: MediaURL(**val) for key, val in image_urls.items()}
            )
            
        stats_info = StatisticsInfo(
            repin_count=raw_data['repin_count'],
            comment_count=raw_data['comment_count']
        )

        return PinterestPinData(
            id=raw_data['id'],
            created_at=raw_data['created_at'],
            title=raw_data.get('title', ''),
            description=raw_data.get('description', ''),
            pinner=pinner_info,
            media=media,
            statistics=stats_info
        )