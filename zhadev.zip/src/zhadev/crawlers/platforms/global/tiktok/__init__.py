# zhadev/src/zhadev/crawlers/platforms/global/tiktok/__init__.py

from .crawler import TikTokCrawler

__all__ = ["TikTokCrawler"]