# zhadev/src/zhadev/crawlers/platforms/global/tiktok/crawler.py

import os
import json
import yaml
from typing import Any, Dict

from bs4 import BeautifulSoup
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .models import TikTokVideoData, AuthorInfo, VideoInfo, MusicInfo, StatisticsInfo
from .utils import resolve_short_url

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class TikTokCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk TikTok. Bekerja dengan mengekstrak blok data JSON
    `__UNIVERSAL_DATA_FOR_REHYDRATION__` dari sumber halaman.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['tiktok']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_video_data(self, url: str) -> TikTokVideoData:
        """
        Metode utama untuk mengambil data video dari URL TikTok.
        """
        # 1. Atasi URL pendek jika ada
        full_url = await resolve_short_url(url)
        
        # 2. Ambil konten HTML halaman
        html = await self.fetch_text(full_url)
        soup = BeautifulSoup(html, "html.parser")
        
        # 3. Cari blok data JSON yang ter-embed
        data_script = soup.find("script", id="__UNIVERSAL_DATA_FOR_REHYDRATION__")
        if not data_script:
            # Fallback untuk struktur baru yang mungkin menggunakan __NEXT_DATA__
            data_script = soup.find("script", id="__NEXT_DATA__")
            if not data_script:
                raise ParsingError("Tidak dapat menemukan blok data JSON. Struktur halaman TikTok mungkin berubah.")
            
        try:
            # 4. Parse JSON dan navigasi ke data video yang relevan
            initial_data = json.loads(data_script.string)
            
            # Jalur navigasi ini bisa berubah, perlu pemeliharaan.
            # Ini adalah jalur yang umum ditemukan.
            item_struct = initial_data['__DEFAULT_SCOPE__']['webapp.video-detail']['itemInfo']['itemStruct']
            
        except (json.JSONDecodeError, KeyError) as e:
            raise ParsingError(f"Gagal mem-parsing atau menavigasi data JSON. Mungkin video tidak ada atau privat. Error: {e}")

        # 5. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(item_struct)

    def _transform_to_clean_data(self, raw_data: Dict[str, Any]) -> TikTokVideoData:
        """
        Mengubah dictionary data mentah dari JSON menjadi model Pydantic yang bersih.
        """
        author_details = raw_data['author']
        author_info = AuthorInfo(
            id=author_details['id'],
            uniqueId=author_details['uniqueId'],
            nickname=author_details['nickname'],
            avatar_url=author_details['avatarLarger'] # Ambil gambar avatar terbesar
        )
        
        video_details = raw_data['video']
        video_info = VideoInfo(
            id=video_details['id'],
            height=video_details['height'],
            width=video_details['width'],
            duration=video_details['duration'],
            cover_url=video_details['cover'],
            play_url_no_watermark=video_details.get('playAddr', ''), # Seringkali tanpa watermark
            download_url_watermarked=video_details.get('downloadAddr', '')
        )
        
        music_details = raw_data['music']
        music_info = MusicInfo(
            id=music_details['id'],
            title=music_details['title'],
            authorName=music_details['authorName'],
            play_url=music_details['playUrl'],
            cover_thumb_url=music_details['coverThumb']
        )

        stats_details = raw_data['stats']
        stats_info = StatisticsInfo(
            diggCount=stats_details['diggCount'],
            shareCount=stats_details['shareCount'],
            commentCount=stats_details['commentCount'],
            playCount=stats_details['playCount'],
            collectCount=stats_details['collectCount']
        )

        return TikTokVideoData(
            id=raw_data['id'],
            description=raw_data['desc'],
            created_at_timestamp=raw_data['createTime'],
            author=author_info,
            video=video_info,
            music=music_info,
            statistics=stats_info
        )