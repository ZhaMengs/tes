import os
import yaml
from typing import List, Optional
from bs4 import BeautifulSoup, Tag

from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import DonghubEndpoints
from .models import DonghuaSearchResult, DonghuaInfo, EpisodeInfo, DonghuaScheduleItem
from .utils import extract_episode_number, LanguageConverter

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class DonghubCrawler(BaseCrawler):
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['donghub']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def search(self, query: str) -> List[DonghuaSearchResult]:
        # ... (kode method search yang sudah ada) ...
        search_url = f"{DonghubEndpoints.BASE_URL}{DonghubEndpoints.SEARCH_PATH}"
        params = {"s": query}
        
        html = await self.fetch_text(search_url, params=params)
        soup = BeautifulSoup(html, "html.parser")
        
        results_container = soup.find_all("div", class_="bs")
        if not results_container:
            raise ContentNotFoundError(f"Tidak ditemukan hasil untuk pencarian: '{query}'")

        search_results = []
        for item in results_container:
            try:
                link_tag = item.find("a", href=True)
                title_tag = item.find("div", class_="tt")
                img_tag = item.find("img")

                if link_tag and title_tag and img_tag:
                    search_results.append(DonghuaSearchResult(
                        title=title_tag.get_text(strip=True),
                        url=link_tag['href'],
                        cover_url=img_tag['src']
                    ))
            except (AttributeError, KeyError) as e:
                print(f"Warning: Gagal mem-parsing item hasil pencarian, dilewati. Error: {e}")
                continue
        
        return search_results

    async def get_info(self, title_url: str) -> DonghuaInfo:
        # ... (kode method get_info yang sudah ada) ...
        if not title_url.startswith("http"):
            title_url = f"{DonghubEndpoints.BASE_URL}{title_url}" if title_url.startswith("/") else f"{DonghubEndpoints.BASE_URL}/{title_url}"

        html = await self.fetch_text(title_url)
        soup = BeautifulSoup(html, "html.parser")

        try:
            eng_title = soup.find("h1", class_="entry-title").get_text(strip=True)
            china_title_tag = soup.find("span", class_="alter")
            china_title = china_title_tag.get_text(strip=True) if china_title_tag else None
            details = {}
            info_elements = soup.select(".spe span")
            for info in info_elements:
                key = info.find("b").get_text(strip=True).replace(":", "")
                value = ' '.join([text for text in info.find_all(string=True, recursive=False) if text.strip()])
                details[key.strip()] = value.strip()
            synopsis_div = soup.find("div", class_="entry-content-single")
            synopsis_paras = synopsis_div.find_all("p")
            synopsis = {"english": synopsis_paras[0].get_text(strip=True) if synopsis_paras else "",
                        "indonesia": synopsis_paras[1].get_text(strip=True) if len(synopsis_paras) > 1 else ""}
            episodes = []
            episode_list_items = soup.select(".eplister ul li")
            for li in episode_list_items:
                link_tag = li.find("a", href=True)
                title_ep = li.find("div", class_="epl-title").get_text(strip=True)
                if link_tag and title_ep:
                    ep_info = EpisodeInfo(
                        episode_title=title_ep,
                        episode_url=link_tag['href'],
                        episode_number=extract_episode_number(link_tag['href'])
                    )
                    episodes.append(ep_info)
            cover_url = soup.find("div", class_="thumb").find("img")['src']
            return DonghuaInfo(
                english_title=eng_title,
                china_title=china_title,
                cover_url=cover_url,
                details=details,
                synopsis=synopsis,
                episodes=episodes
            )
        except (AttributeError, IndexError, KeyError) as e:
            raise ParsingError(f"Gagal mem-parsing halaman info, mungkin struktur web berubah. URL: {title_url}. Error: {e}")

    async def get_schedule(self, day: str) -> List[DonghuaScheduleItem]:
        """
        Mengambil jadwal rilis Donghua berdasarkan hari.
        """
        english_day = LanguageConverter.to_english_day(day)
        schedule_url = f"{DonghubEndpoints.BASE_URL}{DonghubEndpoints.SCHEDULE_PATH}"
        
        html = await self.fetch_text(schedule_url)
        soup = BeautifulSoup(html, "html.parser")
        
        day_container = soup.find("div", id=english_day)
        if not day_container:
            raise ContentNotFoundError(f"Tidak dapat menemukan jadwal untuk hari: '{day}' (dikonversi ke '{english_day}')")
            
        schedule_items = []
        anime_items = day_container.find_all("div", class_="bs")
        for item in anime_items:
            try:
                link_tag = item.find("a", href=True)
                title = item.find("div", class_="tt").get_text(strip=True)
                img_src = item.find("img")['src']
                
                schedule_items.append(DonghuaScheduleItem(
                    title=title,
                    url=link_tag['href'],
                    cover_url=img_src,
                    day=day
                ))
            except (AttributeError, KeyError):
                continue # Lewati jika ada item yang tidak valid
                
        return schedule_items
