# zhadev/src/zhadev/crawlers/platforms/global/twitter/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak ID Tweet dari path URL.
# Contoh: /user/status/1234567890
TWEET_ID_PATTERN = re.compile(r"/status/(\d+)")

async def extract_tweet_id(url: str) -> str:
    """
    Mengekstrak Tweet ID dari URL Twitter/X.
    
    :param url: URL Tweet.
    :return: String Tweet ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = TWEET_ID_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Tweet ID dari URL: {url}")