# zhadev/src/zhadev/crawlers/platforms/global/twitter/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

class AuthorInfo(BaseModel):
    """Informasi kreator Tweet."""
    id: str = Field(..., alias="rest_id")
    username: str = Field(..., alias="screen_name")
    display_name: str = Field(..., alias="name")
    avatar_url: str = Field(..., alias="profile_image_url_https")
    is_verified: bool = Field(..., alias="is_blue_verified")

class VideoVariant(BaseModel):
    """Mewakili satu kualitas/format video."""
    bit_rate: Optional[int] = Field(None, alias="bit_rate")
    content_type: str = Field(..., alias="content_type")
    url: str

class MediaInfo(BaseModel):
    """Mewakili satu item media (gambar atau video)."""
    type: str # 'photo' atau 'video'
    display_url: str
    media_url: str # URL media dengan kualitas terbaik
    video_variants: Optional[List[VideoVariant]] = None

class StatisticsInfo(BaseModel):
    """Statistik interaksi Tweet."""
    reply_count: int
    retweet_count: int
    like_count: int
    bookmark_count: int
    view_count: int

class TwitterTweetData(BaseModel):
    """Output akhir yang komprehensif dari Twitter Crawler."""
    status: str = "success"
    platform: str = "twitter"
    id: str
    url: str
    text: str
    created_at: str
    author: AuthorInfo
    media: List[MediaInfo]
    statistics: StatisticsInfo