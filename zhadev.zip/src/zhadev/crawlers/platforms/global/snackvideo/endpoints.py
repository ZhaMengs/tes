# zhadev/src/zhadev/crawlers/platforms/global/snackvideo/endpoints.py

class SnackVideoEndpoints:
    """
    Menyimpan endpoint utama untuk SnackVideo.
    """
    BASE_URL: str = "https://snackvideo.com"