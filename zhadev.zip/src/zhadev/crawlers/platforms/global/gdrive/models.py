# zhadev/src/zhadev/crawlers/platforms/global/gdrive/models.py

from pydantic import BaseModel
from typing import Optional

class GDriveFileData(BaseModel):
    """
    Output akhir yang komprehensif dari GDrive Crawler.
    Berisi metadata file dan link unduhan langsung.
    """
    status: str = "success"
    platform: str = "gdrive"
    file_id: str
    file_name: str
    file_size: Optional[str] = None
    direct_download_url: str