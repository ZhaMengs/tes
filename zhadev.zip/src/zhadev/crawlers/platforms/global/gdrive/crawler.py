# zhadev/src/zhadev/crawlers/platforms/global/gdrive/crawler.py

import os
import re
import yaml
import httpx
from typing import Any
from bs4 import BeautifulSoup

from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import GDriveEndpoints
from .models import GDriveFileData
from .utils import extract_file_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class GDriveCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Google Drive. Mampu menangani halaman
    peringatan virus untuk mendapatkan link unduhan langsung.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['gdrive']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        self.cookie = config.get('cookie')
        if self.cookie:
            config['headers']['Cookie'] = self.cookie
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_download_data(self, url: str) -> GDriveFileData:
        """
        Metode utama untuk mendapatkan link unduhan langsung dari GDrive.
        """
        # 1. Ekstrak File ID dari URL
        file_id = await extract_file_id(url)
        
        client = await self._get_client()
        initial_url = f"{GDriveEndpoints.DOWNLOAD_URL}&id={file_id}"
        
        try:
            # 2. Lakukan permintaan pertama
            response = await client.get(initial_url)
            
            # 3. Cek jika kita mendapatkan halaman HTML (halaman peringatan)
            if 'text/html' in response.headers.get('content-type', ''):
                return await self._handle_warning_page(response, file_id)
            
            # 4. Jika bukan HTML, berarti ini adalah redirect ke file langsung
            # dan httpx telah mengikutinya. URL final adalah link unduhan.
            else:
                # Coba dapatkan nama file dari header
                content_disposition = response.headers.get('content-disposition', '')
                filename_match = re.search(r'filename="?([^"]+)"?', content_disposition)
                filename = filename_match.group(1) if filename_match else "unknown_file"

                return GDriveFileData(
                    file_id=file_id,
                    file_name=filename,
                    file_size=response.headers.get('content-length'),
                    direct_download_url=str(response.url)
                )

        except httpx.RequestError as e:
            raise CrawlingError(f"Gagal terhubung ke Google Drive: {e}")
        except Exception as e:
            raise ParsingError(f"Terjadi error tak terduga saat memproses link GDrive: {e}")

    async def _handle_warning_page(self, response: httpx.Response, file_id: str) -> GDriveFileData:
        """
        Mem-parsing halaman peringatan virus untuk menemukan link konfirmasi.
        """
        print("Info: Halaman peringatan terdeteksi, mencoba mencari link konfirmasi...")
        soup = BeautifulSoup(await response.aread(), "html.parser")
        
        # Cari form konfirmasi
        form = soup.find('form', {'id': 'download-form'})
        if not form:
            # Cek kemungkinan error kuota di halaman ini
            if "download quota" in soup.text.lower():
                raise ContentNotFoundError("Kuota unduhan untuk file ini telah terlampaui. Coba lagi nanti atau gunakan cookie akun.")
            raise ParsingError("Tidak dapat menemukan form konfirmasi di halaman peringatan.")

        confirm_url = form.get('action')
        if not confirm_url:
            raise ParsingError("Tidak dapat menemukan URL konfirmasi di dalam form.")

        # Lakukan permintaan kedua ke URL konfirmasi
        client = await self._get_client()
        final_response = await client.get(confirm_url)

        # URL dari respons final ini adalah link unduhan langsung
        final_url = str(final_response.url)
        
        # Ekstrak metadata dari halaman peringatan
        filename = soup.find('div', class_='filename').text if soup.find('div', class_='filename') else "unknown_file"
        filesize = soup.find('div', class_='filesize').text if soup.find('div', 'filesize') else None

        return GDriveFileData(
            file_id=file_id,
            file_name=filename.strip(),
            file_size=filesize.strip() if filesize else None,
            direct_download_url=final_url
        )