# zhadev/src/zhadev/crawlers/platforms/global/gdrive/endpoints.py

class GDriveEndpoints:
    """
    Menyimpan endpoint utama untuk Google Drive.
    """
    BASE_URL: str = "https://drive.google.com"

    # Endpoint universal untuk mengunduh file, memerlukan ID file.
    DOWNLOAD_URL: str = f"{BASE_URL}/uc?export=download"