# zhadev/src/zhadev/crawlers/platforms/global/mediafire/endpoints.py

class MediafireEndpoints:
    """
    Menyimpan endpoint utama untuk MediaFire.
    """
    BASE_URL: str = "https://www.mediafire.com"