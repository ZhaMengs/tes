# zhadev/src/zhadev/crawlers/platforms/global/pixeldrain/models.py

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

class PixeldrainApiRawResponse(BaseModel):
    """Memetakan respons JSON dari endpoint /file/{id}/info."""
    success: bool
    id: str
    name: str
    size: int # dalam bytes
    views: int
    downloads: int
    bandwidth_used: int = Field(..., alias="bandwidth_used")
    mime_type: str = Field(..., alias="mime_type")
    date_upload: datetime = Field(..., alias="date_upload")

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class PixeldrainFileData(BaseModel):
    """Output akhir yang komprehensif dari PixelDrain Crawler."""
    status: str = "success"
    platform: str = "pixeldrain"
    id: str
    name: str
    size_bytes: int
    mime_type: str
    upload_date: datetime
    views: int
    downloads: int
    direct_download_url: str