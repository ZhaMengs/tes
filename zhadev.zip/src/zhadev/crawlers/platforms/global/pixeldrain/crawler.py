# zhadev/src/zhadev/crawlers/platforms/global/pixeldrain/crawler.py

import os
import yaml
from typing import Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import PixeldrainEndpoints
from .models import PixeldrainApiRawResponse, PixeldrainFileData
from .utils import extract_file_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class PixeldrainCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk PixelDrain yang menggunakan API resmi
    untuk mendapatkan metadata dan link unduhan.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['pixeldrain']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_download_data(self, url: str) -> PixeldrainFileData:
        """
        Metode utama untuk mengambil metadata dan link unduhan dari URL PixelDrain.
        """
        # 1. Ekstrak File ID dari URL
        file_id = await extract_file_id(url)
        
        # 2. Bangun URL untuk API info
        info_url = PixeldrainEndpoints.FILE_INFO.format(id=file_id)
        
        try:
            # 3. Panggil API untuk mendapatkan metadata
            response_json = await self.fetch_json(info_url)
            
            # 4. Validasi respons API dengan Pydantic
            validated_response = PixeldrainApiRawResponse.model_validate(response_json)

            if not validated_response.success:
                raise ContentNotFoundError(f"API PixelDrain mengembalikan error untuk ID: {file_id}. File mungkin tidak ada.")
            
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API PixelDrain berubah. Detail: {e}")
        except ContentNotFoundError as e:
            raise e

        # 5. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(validated_response)

    def _transform_to_clean_data(self, raw_data: PixeldrainApiRawResponse) -> PixeldrainFileData:
        """
        Mengubah objek data mentah dari API menjadi model Pydantic yang bersih.
        """
        # Bangun URL unduhan langsung berdasarkan ID file
        direct_download_url = PixeldrainEndpoints.FILE_DOWNLOAD.format(id=raw_data.id)
        
        return PixeldrainFileData(
            id=raw_data.id,
            name=raw_data.name,
            size_bytes=raw_data.size,
            mime_type=raw_data.mime_type,
            upload_date=raw_data.date_upload,
            views=raw_data.views,
            downloads=raw_data.downloads,
            direct_download_url=direct_download_url
        )