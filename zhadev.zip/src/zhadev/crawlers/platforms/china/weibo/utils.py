import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

POST_ID_PATTERN = re.compile(r"/(?:status/|detail/)?([a-zA-Z0-9]{9,})$")

async def extract_post_id(url: str) -> str:
    """
    Mengekstrak Post ID dari URL Weibo.
    
    :param url: URL postingan Weibo (mobile atau desktop).
    :return: String Post ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = POST_ID_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Post ID dari URL: {url}")
