import os
import yaml
from typing import Any, Dict

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import WeiboEndpoints
from .models import WeiboAPIRawResponse, WeiboPostData, AuthorInfo, StatisticsInfo, ImageInfo, VideoInfo
from .utils import extract_post_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class WeiboCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Weibo, menargetkan Mobile API.
    Mampu membedakan dan mem-parsing postingan teks, gambar, dan video.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['weibo']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_post_data(self, url: str) -> WeiboPostData:
        """
        Metode utama untuk mengambil data postingan Weibo.
        """
        # 1. Ekstrak Post ID dari URL
        post_id = await extract_post_id(url)
        
        # 2. Panggil API /statuses/show
        params = {"id": post_id}
        try:
            response_json = await self.fetch_json(WeiboEndpoints.STATUS_DETAIL, params=params)
            validated_response = WeiboAPIRawResponse.model_validate(response_json)

            if validated_response.ok != 1 or not validated_response.data:
                raise ContentNotFoundError(f"API Weibo mengembalikan error: {validated_response.msg}")
            
            post_data_raw = validated_response.data
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Weibo berubah. Detail: {e}")

        # 3. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(post_data_raw)

    def _transform_to_clean_data(self, raw_data: Any) -> WeiboPostData:
        """
        Mengubah objek data mentah dari API menjadi model Pydantic yang bersih.
        """
        author_info = AuthorInfo(
            id=raw_data.user.id,
            username=raw_data.user.screen_name,
            avatar_url=raw_data.user.profile_image_url,
            description=raw_data.user.description
        )
        
        stats_info = StatisticsInfo(
            reposts=raw_data.reposts_count,
            comments=raw_data.comments_count,
            likes=raw_data.attitudes_count
        )
        
        post_type = "text"
        images = []
        video = None
        
        # Cek apakah ada gambar
        if raw_data.pics:
            post_type = "image"
            for pic in raw_data.pics:
                images.append(ImageInfo(
                    id=pic.pid,
                    thumbnail_url=pic.url,
                    medium_url=pic.large.bmiddle_pic,
                    large_url=pic.large.large_pic,
                    original_url=pic.large.original_pic
                ))
        
        # Cek apakah ada video
        if raw_data.page_info and raw_data.page_info.type == 'video':
            post_type = "video"
            page_info = raw_data.page_info
            streams = {}
            
            # Coba format stream baru terlebih dahulu
            if page_info.slide_cover and page_info.slide_cover.get('streams'):
                for stream in page_info.slide_cover['streams']:
                    if stream.quality_desc and stream.url:
                        streams[stream.quality_desc] = stream.url
            # Fallback ke format lama jika ada
            elif page_info.urls:
                streams = page_info.urls

            video = VideoInfo(
                cover_url=page_info.page_pic.large_pic if page_info.page_pic else "",
                duration=page_info.media_info.get("duration", 0.0) if page_info.media_info else 0.0,
                streams=streams
            )

        return WeiboPostData(
            id=raw_data.id,
            mid=raw_data.mid,
            post_type=post_type,
            text=raw_data.text,
            created_at=raw_data.created_at,
            author=author_info,
            statistics=stats_info,
            images=images if images else None,
            video=video
        )
