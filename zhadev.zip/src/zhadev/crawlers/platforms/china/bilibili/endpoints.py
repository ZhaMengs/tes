class BilibiliEndpoints:
    """
    Menyimpan endpoint API utama untuk Bilibili (versi Web).
    """
    API_DOMAIN: str = "https://api.bilibili.com"

    VIDEO_VIEW: str = f"{API_DOMAIN}/x/web-interface/view"

    VIDEO_PLAYURL: str = f"{API_DOMAIN}/x/player/playurl"
