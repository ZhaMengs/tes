import re
import httpx
from typing import Optional, Tuple
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak BVID atau AID dari URL
BVID_PATTERN = re.compile(r"/(BV[a-zA-Z0-9]{10})")
AID_PATTERN = re.compile(r"/av(\d+)")
SHORT_URL_HOST = "b23.tv"

async def extract_video_id(url: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Mengekstrak BVID atau AID dari URL Bilibili.
    Mampu menangani URL panjang, URL pendek (b23.tv), dan URL lama (av).
    
    :param url: URL video Bilibili.
    :return: Tuple berisi (bvid, aid). Salah satunya bisa None.
    :raises ContentNotFoundError: Jika tidak ada ID yang bisa diekstrak.
    """
    parsed_url = urlparse(url)
    
    # Tangani URL pendek b23.tv dengan mengikuti redirect
    if parsed_url.hostname == SHORT_URL_HOST:
        try:
            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.head(url, timeout=10)
                final_url = str(response.url)
                return await extract_video_id(final_url) # Rekursif dengan URL final
        except httpx.RequestError as e:
            raise ContentNotFoundError(f"Gagal mengikuti redirect untuk URL pendek: {e}")

    # Cari BVID
    bvid_match = BVID_PATTERN.search(parsed_url.path)
    if bvid_match:
        return bvid_match.group(1), None

    # Jika tidak ada BVID, cari AID (format lama)
    aid_match = AID_PATTERN.search(parsed_url.path)
    if aid_match:
        return None, int(aid_match.group(1))

    raise ContentNotFoundError(f"Tidak dapat mengekstrak BVID atau AID dari URL: {url}")
