import os
import yaml
from typing import Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import BstationEndpoints
from .models import (
    BstationViewRawResponse, BstationPlayUrlRawResponse, BstationVideoData,
    StatisticsInfo, StreamInfo, EpisodeRaw
)
from .utils import extract_episode_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class BstationCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Bstation (bilibili.tv).
    Mengambil metadata season dan URL stream video secara terpisah.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['bstation']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_video_data(self, url: str) -> BstationVideoData:
        """
        Metode utama untuk mengambil data video Bstation dalam dua langkah.
        """
        # Langkah 1: Ekstrak Episode ID dari URL
        ep_id = await extract_episode_id(url)
        
        # Langkah 2: Panggil API /season untuk mendapatkan metadata dan CID
        view_params = {"ep_id": ep_id}
        try:
            view_response_json = await self.fetch_json(BstationEndpoints.SEASON_VIEW, params=view_params)
            view_data = BstationViewRawResponse.model_validate(view_response_json)
            if view_data.code != 0 or not view_data.result:
                raise ContentNotFoundError(f"API Bstation (season) mengembalikan error: {view_data.message}")
            season_meta = view_data.result
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Bstation (season) berubah. Detail: {e}")

        # Cari episode yang sesuai untuk mendapatkan CID dan metadata spesifik
        target_episode = next((ep for ep in season_meta.episodes if ep.id == ep_id), None)
        if not target_episode:
            raise ContentNotFoundError(f"Episode dengan ID {ep_id} tidak ditemukan dalam season ini.")
        cid = target_episode.cid

        # Langkah 3: Panggil API /playurl untuk mendapatkan URL stream DASH
        playurl_params = {
            "ep_id": ep_id,
            "cid": cid,
            "qn": 10000, # Minta kualitas tertinggi (DASH)
            "fnval": 4048, # Flag untuk meminta format DASH
            "fourk": 1 # Flag untuk mengizinkan kualitas 4K
        }
        try:
            playurl_response_json = await self.fetch_json(BstationEndpoints.VIDEO_PLAYURL, params=playurl_params)
            playurl_data = BstationPlayUrlRawResponse.model_validate(playurl_response_json)
            if playurl_data.code != 0 or not playurl_data.result:
                raise ContentNotFoundError(f"API Bstation (playurl) mengembalikan error: {playurl_data.message}")
            stream_meta = playurl_data.result
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Bstation (playurl) berubah. Detail: {e}")

        # Langkah 4: Gabungkan data dari kedua API call menjadi output yang bersih
        return self._transform_to_clean_data(season_meta, target_episode, stream_meta)

    def _transform_to_clean_data(self, season_meta: Any, episode: EpisodeRaw, stream_meta: Any) -> BstationVideoData:
        """
        Menggabungkan dan membersihkan data dari dua sumber API.
        """
        stats_info = StatisticsInfo(
            views=season_meta.stat.views,
            likes=season_meta.stat.likes,
            coins=season_meta.stat.coins,
            favorites=season_meta.stat.favorites
        )

        video_streams, audio_streams = [], []
        if stream_meta.dash:
            if stream_meta.dash.video:
                for stream in stream_meta.dash.video:
                    video_streams.append(StreamInfo(
                        quality_id=stream.id, url=stream.baseUrl, codecs=stream.codecs,
                        width=stream.width, height=stream.height, frame_rate=stream.frameRate,
                        bandwidth_kbps=int(stream.bandwidth / 1000)
                    ))
            if stream_meta.dash.audio:
                for stream in stream_meta.dash.audio:
                    audio_streams.append(StreamInfo(
                        quality_id=stream.id, url=stream.baseUrl, codecs=stream.codecs,
                        width=0, height=0, frame_rate="",
                        bandwidth_kbps=int(stream.bandwidth / 1000)
                    ))
        
        return BstationVideoData(
            season_id=season_meta.season_id,
            episode_id=episode.id,
            cid=episode.cid,
            season_title=season_meta.title,
            episode_title=episode.long_title,
            cover_url=episode.cover,
            duration_ms=episode.duration,
            statistics=stats_info,
            video_streams=video_streams,
            audio_streams=audio_streams
        )
