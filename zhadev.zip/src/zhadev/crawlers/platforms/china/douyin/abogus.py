import hashlib
import time
from random import choice, randint, random
from typing import List, Union, Dict
from urllib.parse import urlencode

from gmssl import sm3, func

class ABogus:
    """
    Implementasi Python yang direkayasa ulang dari algoritma `a_bogus` Douyin.
    Kelas ini mampu menghasilkan signature yang valid secara dinamis berdasarkan
    parameter input dan User-Agent, meniru perilaku skrip browser asli.
    """
    _DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36"
    _CHAR_SET = "Dkdpgh4ZKsQB80/Mfvw36XI1R25-WUAlEi7NLboqYTOPuzmFjJnryx9HVGcaStCe="
    _END_STRING = "cus"

    def __init__(self, user_agent: str = None):
        self.user_agent = user_agent or self._DEFAULT_UA
        self.ua_hash_code = self._generate_ua_code(self.user_agent)

    @staticmethod
    def _sm3_hash(data: Union[str, List[int]]) -> List[int]:
        """Menghitung hash SM3 dan mengubahnya menjadi array integer."""
        if isinstance(data, str):
            data_bytes = data.encode('utf-8')
        else:
            data_bytes = bytes(data)
        
        hash_hex = sm3.sm3_hash(func.bytes_to_list(data_bytes))
        return [int(hash_hex[i:i+2], 16) for i in range(0, len(hash_hex), 2)]

    def _generate_ua_code(self, ua_str: str) -> List[int]:
        """Menghasilkan array hash dari User-Agent, meniru langkah di JS."""
        md5_hash = hashlib.md5(ua_str.encode()).hexdigest()
        part1 = hashlib.md5(md5_hash.encode()).hexdigest()[:16]
        part2 = hashlib.md5(md5_hash[16:].encode()).hexdigest()[:16]
        combined = part1 + part2
        return [int(combined[i:i+2], 16) for i in range(0, len(combined), 2)]

    @staticmethod
    def _rc4_encrypt(key: str, data: str) -> str:
        """Implementasi standar enkripsi RC4."""
        s_box = list(range(256))
        j = 0
        key_bytes = key.encode()
        
        for i in range(256):
            j = (j + s_box[i] + key_bytes[i % len(key_bytes)]) % 256
            s_box[i], s_box[j] = s_box[j], s_box[i]

        i = j = 0
        result = []
        for char in data:
            i = (i + 1) % 256
            j = (j + s_box[i]) % 256
            s_box[i], s_box[j] = s_box[j], s_box[i]
            t = (s_box[i] + s_box[j]) % 256
            result.append(chr(ord(char) ^ s_box[t]))
            
        return "".join(result)

    @staticmethod
    def _create_random_array(seed: float, const1: int, const2: int, flags: List[int]) -> List[int]:
        """Membuat array acak berdasarkan seed dan konstanta."""
        r_val = seed or (random() * 10000)
        v1 = int(r_val) & 255
        v2 = int(r_val) >> 8
        return [
            v1 & const1 | flags[0],
            v1 & const2 | flags[1],
            v2 & const1 | flags[2],
            v2 & const2 | flags[3]
        ]

    @staticmethod
    def _from_char_code(*args: int) -> str:
        """Mengonversi serangkaian integer menjadi string."""
        return "".join(map(chr, args))

    def _get_part_one(self) -> str:
        """Menghasilkan bagian pertama dari payload, berdasarkan array acak."""
        arr1 = self._create_random_array(None, 170, 85, [1, 2, 5, 85 & 170])
        arr2 = self._create_random_array(None, 170, 85, [1, 0, 0, 0])
        arr3 = self._create_random_array(None, 170, 85, [1, 0, 5, 0])
        return self._from_char_code(*arr1) + self._from_char_code(*arr2) + self._from_char_code(*arr3)

    def _get_part_two(self, params_str: str) -> str:
        """Menghasilkan bagian kedua dari payload, yang dienkripsi RC4."""
        now = int(time.time() * 1000)
        start_time = now - randint(1000, 3000)
        end_time = now + randint(4, 8)
        
        params_array = self._sm3_hash(self._sm3_hash(params_str + self._END_STRING))
        
        core_array = [
            44, (end_time >> 24) & 255, 0, 0, 0, 0, 24, params_array[21], 3, 0,
            self.ua_hash_code[23], (end_time >> 16) & 255, 0, 0, 0, 1, 0, 239,
            params_array[22], 1, self.ua_hash_code[24], (end_time >> 8) & 255,
            0, 0, 0, 0, (end_time & 255), 0, 0, 14, (start_time >> 24) & 255,
            (start_time >> 16) & 255, 0, (start_time >> 8) & 255, (start_time & 255),
            3, int(end_time / 2**32) >> 0, 1, int(start_time / 2**32) >> 0, 1, 19, 0, 0, 0
        ]
        
        checksum = sum(core_array) & 255
        core_array.append(checksum)
        
        payload_str = self._from_char_code(*core_array)
        return self._rc4_encrypt("y", payload_str)

    @staticmethod
    def _final_encoding(data: str, char_set: str) -> str:
        """Mengenkode data biner akhir ke dalam charset kustom Douyin."""
        result = []
        for i in range(0, len(data), 3):
            chunk = data[i:i+3]
            while len(chunk) < 3:
                chunk += '\x00'
            
            b1 = ord(chunk[0])
            b2 = ord(chunk[1])
            b3 = ord(chunk[2])
            n = (b1 << 16) | (b2 << 8) | b3
            
            result.append(char_set[(n >> 18) & 63])
            result.append(char_set[(n >> 12) & 63])
            result.append(char_set[(n >> 6) & 63])
            result.append(char_set[n & 63])
        
        if len(data) % 3 == 1:
            result[-1] = result[-2] = '='
        elif len(data) % 3 == 2:
            result[-1] = '='
            
        return "".join(result)

    def generate(self, params: Union[str, Dict]) -> str:
        if isinstance(params, dict):
            params_str = urlencode(params)
        else:
            params_str = params
            
        part1 = self._get_part_one()
        part2 = self._get_part_two(params_str)
        combined_payload = part1 + part2
        
        return self._final_encoding(combined_payload, self._CHAR_SET)
