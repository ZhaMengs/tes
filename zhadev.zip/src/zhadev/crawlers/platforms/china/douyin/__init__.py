from .crawler import DouyinCrawler

__all__ = ["DouyinCrawler"]
