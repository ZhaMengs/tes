import os
import yaml
from typing import Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import DouyinEndpoints
from .models import DouyinAPIRawResponse, DouyinVideoData
from .utils import extract_aweme_id, BogusManager

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class DouyinCrawler(BaseCrawler):
    """
    Crawler Douyin versi FINAL. Menggunakan signature a_bogus dinamis
    untuk otentikasi permintaan tingkat lanjut.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)['douyin']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        self.user_agent = self.headers.get("User-Agent", "")
        self.bogus_manager = BogusManager(user_agent=self.user_agent)

    async def get_video_data(self, url: str) -> DouyinVideoData:
        aweme_id = await extract_aweme_id(url)
        
        # 1. Siapkan parameter dasar
        base_params = {
            "device_platform": "webapp",
            "aid": "6383",
            "channel": "channel_pc_web",
            "aweme_id": aweme_id,
            "pc_client_type": "1",
            "version_code": "190500",
            "version_name": "19.5.0",
            "cookie_enabled": "true"
        }
        
        # 2. Hasilkan signature a_bogus dan dapatkan parameter yang sudah ditandatangani
        signed_params = self.bogus_manager.sign_params_with_abogus(base_params)

        # 3. Lakukan panggilan API dengan parameter yang sudah lengkap
        raw_response_json = await self.fetch_json(DouyinEndpoints.POST_DETAIL, params=signed_params)
        
        # 4. Validasi dan Proses
        try:
            validated_response = DouyinAPIRawResponse.model_validate(raw_response_json)
            if validated_response.status_code != 0 or not validated_response.aweme_detail:
                raise ContentNotFoundError(f"API Error: {validated_response.status_msg}")
            return self._transform_to_clean_data(validated_response.aweme_detail)
        except ValidationError as e:
            raise ParsingError(f"Struktur API Douyin berubah. Detail: {e}")

    def _transform_to_clean_data(self, post: Any) -> DouyinVideoData:
        from .models import AuthorInfo, StatisticsInfo, MusicInfo, VideoInfo
        author_info = AuthorInfo(
            uid=post.author.uid, nickname=post.author.nickname,
            unique_id=post.author.unique_id or post.author.short_id,
            signature=post.author.signature, avatar_url=post.author.avatar_thumb.url_list[0] if post.author.avatar_thumb else None
        )
        stats_info = StatisticsInfo(
            likes=post.statistics.digg_count, comments=post.statistics.comment_count,
            favorites=post.statistics.collect_count, shares=post.statistics.share_count
        )
        music_info = None
        if post.music:
            music_info = MusicInfo(
                id=post.music.id_str, title=post.music.title, author=post.music.author,
                play_url=post.music.play_url.url_list[0] if post.music.play_url else None
            )
        video_info, is_album, image_urls = None, post.images is not None and len(post.images) > 0, []
        if not is_album and post.video:
            wm_url = post.video.play_addr_wm.url_list[0] if post.video.play_addr_wm and post.video.play_addr_wm.url_list else None
            no_wm_url = post.video.play_addr.url_list[0].replace("playwm", "play") if post.video.play_addr and post.video.play_addr.url_list else None
            video_info = VideoInfo(
                height=post.video.height, width=post.video.width, ratio=post.video.ratio,
                duration_ms=post.video.duration, url_with_watermark=wm_url,
                url_without_watermark=no_wm_url,
                cover_url=post.video.origin_cover.url_list[0] if post.video.origin_cover else post.video.cover.url_list[0]
            )
        elif is_album:
            image_urls = [img.get("url_list")[0] for img in post.images if img.get("url_list")]

        return DouyinVideoData(
            aweme_id=post.aweme_id, description=post.desc, created_at_timestamp=post.create_time,
            author=author_info, statistics=stats_info, music=music_info, video=video_info,
            is_image_album=is_album, image_urls=image_urls if is_album else None
        )
