# /zhadev/app/api/v1/ai/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Dict

class AIPrompt(BaseModel):
    """Model request body standar untuk input prompt."""
    prompt: str = Field(..., min_length=1, description="Teks prompt yang akan dikirim ke model AI.")
    # Anda bisa menambahkan parameter lain seperti `history` di sini
    # history: Optional[List[Dict[str, str]]] = None

class AIResponse(BaseModel):
    """Model data standar untuk output dari model AI."""
    text: str

class CharacterAIRequest(BaseModel):
    message: str
    character_id: Optional[str] = None
    character_name: Optional[str] = None
    use_public: bool = True