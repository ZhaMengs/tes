# /zhadev/app/api/v1/ai/felo_ai.py

import httpx
import json
import time
import random
from fastapi import APIRouter, Depends, HTTPException, status
from urllib.parse import urlencode
from ....core.config import settings
from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from typing import Optional, Dict, Any, List

router = APIRouter()

class FeloAIClient:
    def __init__(self):
        self.base_url = "https://felo.ai"
        self.api_base = "https://api.felo.ai"
        self.client = None
        self.session_cookie = None
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json",
            "Origin": "https://felo.ai",
            "Referer": "https://felo.ai/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
        }
        
    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            headers=self.headers,
            timeout=30.0,
            follow_redirects=True,
            cookies=self._get_browser_cookies()
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()
            
    def _get_browser_cookies(self) -> Dict[str, str]:
        """Mendapatkan cookies dari browser untuk bypass protection"""
        try:
            import browser_cookie3
            cookies = {}
            # Try to get cookies from Chrome
            for browser in [browser_cookie3.chrome, browser_cookie3.firefox, browser_cookie3.edge]:
                try:
                    cj = browser(domain_name='felo.ai')
                    for cookie in cj:
                        cookies[cookie.name] = cookie.value
                    if cookies:
                        break
                except:
                    continue
            return cookies
        except ImportError:
            return {}
            
    async def get_csrf_token(self) -> Optional[str]:
        """Mendapatkan CSRF token dari halaman utama"""
        try:
            response = await self.client.get(f"{self.base_url}/")
            if response.status_code == 200:
                # Extract CSRF token from HTML
                import re
                csrf_match = re.search(r'name="csrf-token"\s+content="([^"]+)"', response.text)
                if csrf_match:
                    return csrf_match.group(1)
                    
                # Alternative pattern
                csrf_match = re.search(r'"csrfToken":"([^"]+)"', response.text)
                if csrf_match:
                    return csrf_match.group(1)
                    
            return None
        except Exception as e:
            print(f"Error getting CSRF token: {e}")
            return None
            
    async def search_models(self, query: str = "") -> List[Dict[str, Any]]:
        """Mencari model yang tersedia di Felo AI"""
        try:
            params = {
                "q": query,
                "limit": 20,
                "offset": 0
            }
            
            response = await self.client.get(
                f"{self.api_base}/v1/models/search",
                params=params
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("models", [])
            return []
            
        except Exception as e:
            print(f"Error searching models: {e}")
            return []
            
    async def get_popular_models(self) -> List[Dict[str, Any]]:
        """Mendapatkan model-model populer"""
        try:
            response = await self.client.get(f"{self.api_base}/v1/models/popular")
            if response.status_code == 200:
                data = response.json()
                return data.get("models", [])
            return []
            
        except Exception as e:
            print(f"Error getting popular models: {e}")
            return []
            
    async def start_conversation(self, model_id: str) -> Optional[str]:
        """Memulai percakapan baru dengan model"""
        try:
            payload = {
                "model_id": model_id,
                "settings": {
                    "temperature": 0.7,
                    "max_tokens": 2000
                }
            }
            
            response = await self.client.post(
                f"{self.api_base}/v1/conversations",
                json=payload
            )
            
            if response.status_code == 201:
                data = response.json()
                return data.get("conversation_id")
            return None
            
        except Exception as e:
            print(f"Error starting conversation: {e}")
            return None
            
    async def send_message(self, conversation_id: str, message: str, model_id: str) -> Dict[str, Any]:
        """Mengirim pesan ke model dan mendapatkan respons"""
        try:
            payload = {
                "message": message,
                "conversation_id": conversation_id,
                "model_id": model_id,
                "stream": False
            }
            
            response = await self.client.post(
                f"{self.api_base}/v1/chat",
                json=payload
            )
            
            if response.status_code == 200:
                return self._parse_chat_response(response.json())
            else:
                # Fallback: try alternative endpoint
                return await self._try_alternative_endpoint(message, model_id)
                
        except Exception as e:
            print(f"Error sending message: {e}")
            return {"error": str(e)}
            
    async def _try_alternative_endpoint(self, message: str, model_id: str) -> Dict[str, Any]:
        """Alternative endpoint jika endpoint utama gagal"""
        try:
            payload = {
                "inputs": message,
                "parameters": {
                    "temperature": 0.7,
                    "max_new_tokens": 2000,
                    "do_sample": True
                },
                "model": model_id
            }
            
            response = await self.client.post(
                f"{self.api_base}/v1/generate",
                json=payload
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "response": data.get("generated_text", ""),
                    "model": model_id,
                    "source": "alternative_endpoint"
                }
            else:
                raise Exception(f"Alternative endpoint failed: {response.status_code}")
                
        except Exception as e:
            return {"error": f"All endpoints failed: {str(e)}"}
            
    def _parse_chat_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse response dari chat endpoint"""
        try:
            if "response" in data:
                return {
                    "response": data["response"],
                    "conversation_id": data.get("conversation_id"),
                    "model": data.get("model_id"),
                    "source": "primary_endpoint"
                }
            elif "choices" in data and len(data["choices"]) > 0:
                return {
                    "response": data["choices"][0].get("message", {}).get("content", ""),
                    "model": data.get("model"),
                    "source": "choices_format"
                }
            elif "output" in data:
                return {
                    "response": data["output"],
                    "model": data.get("model"),
                    "source": "output_format"
                }
            else:
                raise Exception("Unknown response format")
                
        except Exception as e:
            return {"error": f"Parse error: {str(e)}"}

# Global client instance
felo_client = FeloAIClient()

# Model populer sebagai fallback
POPULAR_FELO_MODELS = {
    "felo-assistant": "felo-assistant-v1",
    "felo-chat": "felo-chat-7b", 
    "felo-coder": "felo-code-13b",
    "felo-creative": "felo-creative-writer"
}

@router.post("/chat", 
             response_model=StandardResponse[AIResponse], 
             responses={500: {"model": ErrorResponse}}, 
             summary="Mengirim pesan ke Felo AI via Web Scraping")
async def ask_felo(
    request: AIPrompt, 
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk berinteraksi dengan Felo AI menggunakan teknik web scraping.
    
    Parameters:
    - model_id: ID model spesifik (opsional)
    - model_name: Nama model untuk search (opsional)
    """
    try:
        async with felo_client as client:
            model_id = getattr(request, 'model_id', None)
            
            # Jika tidak ada model_id, cari berdasarkan nama atau gunakan default
            if not model_id:
                model_name = getattr(request, 'model_name', 'felo-assistant')
                model_id = POPULAR_FELO_MODELS.get(model_name, POPULAR_FELO_MODELS["felo-assistant"])
            
            # Mulai percakapan baru
            conversation_id = await client.start_conversation(model_id)
            if not conversation_id:
                # Fallback: langsung kirim pesan tanpa conversation
                result = await client.send_message("", request.prompt, model_id)
            else:
                result = await client.send_message(conversation_id, request.prompt, model_id)
            
            if "error" in result:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error dari Felo AI: {result['error']}"
                )
            
            response_text = result.get("response", "Tidak ada respons yang diterima")
            
            return StandardResponse(data=AIResponse(
                text=response_text,
                metadata={
                    "model": result.get("model", model_id),
                    "source": result.get("source", "unknown"),
                    "conversation_id": result.get("conversation_id")
                }
            ))
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan internal: {str(e)}"
        )

@router.get("/models/search", 
             summary="Mencari model yang tersedia di Felo AI")
async def search_felo_models(
    query: str = "",
    limit: int = 10,
    api_key: str = Depends(validate_api_key)
):
    """Mencari model-model yang tersedia di platform Felo AI"""
    try:
        async with felo_client as client:
            models = await client.search_models(query)
            
            return StandardResponse(data={
                "models": models[:limit],
                "count": len(models)
            })
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error mencari model: {str(e)}"
        )

@router.get("/models/popular", 
             summary="Mendapatkan model populer Felo AI")
async def get_popular_felo_models(api_key: str = Depends(validate_api_key)):
    """Mendapatkan daftar model populer Felo AI"""
    popular_list = []
    
    for name, model_id in POPULAR_FELO_MODELS.items():
        popular_list.append({
            "name": name,
            "id": model_id,
            "description": f"Model {name} dari Felo AI"
        })
    
    return StandardResponse(data={"models": popular_list})

@router.post("/direct", 
             response_model=StandardResponse[AIResponse],
             summary="Direct message ke Felo AI (tanpa conversation)")
async def ask_felo_direct(
    request: AIPrompt,
    api_key: str = Depends(validate_api_key)
):
    """Endpoint langsung ke Felo AI tanpa membuat conversation"""
    try:
        async with felo_client as client:
            model_id = getattr(request, 'model_id', POPULAR_FELO_MODELS["felo-assistant"])
            
            result = await client.send_message("", request.prompt, model_id)
            
            if "error" in result:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error dari Felo AI: {result['error']}"
                )
            
            response_text = result.get("response", "Tidak ada respons yang diterima")
            
            return StandardResponse(data=AIResponse(text=response_text))
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan internal: {str(e)}"
        )

# Update model untuk support parameter tambahan
class FeloAIRequest(AIPrompt):
    model_id: Optional[str] = None
    model_name: Optional[str] = "felo-assistant"