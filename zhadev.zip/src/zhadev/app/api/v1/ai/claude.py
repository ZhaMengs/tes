# /zhadev/app/api/v1/ai/claude.py

import anthropic
from fastapi import APIRouter, Depends, HTTPException, status

from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from ....core.config import settings

router = APIRouter()

anthropic_client: Optional[anthropic.AsyncAnthropic] = None
if not settings.CLAUDE_API_KEY:
    print("PERINGATAN: CLAUDE_API_KEY tidak diatur. Endpoint Claude akan dinonaktifkan.")
else:
    try:
        anthropic_client = anthropic.AsyncAnthropic(api_key=settings.CLAUDE_API_KEY)
    except Exception as e:
        print(f"ERROR: Gagal menginisialisasi Anthropic client: {e}")

@router.post("/", response_model=StandardResponse[AIResponse], responses={500: {"model": ErrorResponse}}, summary="Mengirim prompt ke Anthropic Claude")
async def ask_claude(request: AIPrompt, api_key: str = Depends(validate_api_key)):
    if not anthropic_client:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan Claude tidak dikonfigurasi di server.")
    try:
        message = await anthropic_client.messages.create(
            model="claude-3-haiku-20240307", max_tokens=2048,
            system="You are a helpful assistant.", messages=[{"role": "user", "content": request.prompt}]
        )
        response_text = message.content[0].text
        result = AIResponse(text=response_text)
        return StandardResponse(data=result)
    except anthropic.APIError as e:
        print(f"ERROR: Terjadi kesalahan pada API Anthropic: {e}")
        raise HTTPException(status_code=e.status_code or 500, detail=f"Error dari API Claude: {e.message}")