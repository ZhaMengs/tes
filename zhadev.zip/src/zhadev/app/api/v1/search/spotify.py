# /zhadev/app/api/v1/search/spotify.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
# Kita bisa menggunakan kembali model TrackInfo dari crawler
from ....crawlers import SpotifyCrawler, TrackInfo, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[TrackInfo]],
    responses={
        404: {"model": ErrorResponse, "description": "Tidak ada hasil yang ditemukan."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mencari lagu (track) di Spotify",
    description="Masukkan query pencarian untuk mendapatkan daftar lagu yang relevan via API resmi Spotify."
)
async def search_spotify_tracks(
    q: str = Query(..., description="Judul lagu, artis, atau kata kunci lainnya."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian lagu di Spotify.
    """
    start_time = time.time()
    
    try:
        crawler = SpotifyCrawler()
        from ....crawlers.platforms.global_.spotify.models import ArtistInfo, AlbumInfo, AlbumImage
        
        data = await crawler.search_tracks(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")