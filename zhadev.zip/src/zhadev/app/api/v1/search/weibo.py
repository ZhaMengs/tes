# /zhadev/app/api/v1/search/weibo.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import WeiboCrawler, WeiboPostData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    # Gunakan kembali model WeiboPostData
    response_model=StandardResponse[List[WeiboPostData]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mencari postingan di Weibo",
)
async def search_weibo(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian postingan di Weibo.
    """
    start_time = time.time()
    
    try:
        async with WeiboCrawler() as crawler:
            from ....crawlers.platforms.china.weibo.models import AuthorInfo, StatisticsInfo
            
            data = await crawler.search(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")