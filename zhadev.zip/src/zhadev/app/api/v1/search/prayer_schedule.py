# /zhadev/app/api/v1/search/prayer_schedule.py

import time
from datetime import date
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel
from typing import Dict

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BaseCrawler, APIError, CrawlerError

class PrayerTimings(BaseModel):
    Fajr: str
    Sunrise: str
    Dhuhr: str
    Asr: str
    Maghrib: str
    Isha: str
    Imsak: str

class PrayerScheduleData(BaseModel):
    city: str
    country: str
    date: date
    timings: PrayerTimings

router = APIRouter()
PRAYER_API_URL = "http://googleusercontent.com/aladhan.com/0"

@router.get(
    "/",
    response_model=StandardResponse[PrayerScheduleData],
    responses={404: {"model": ErrorResponse}},
    summary="Mendapatkan jadwal sholat untuk sebuah kota",
    description="Menggunakan API dari Aladhan untuk menyediakan jadwal sholat harian."
)
async def get_prayer_schedule(
    city: str = Query(..., description="Nama kota, contoh: 'Jakarta'."),
    country: str = Query(..., description="Nama negara, contoh: 'Indonesia'."),
    api_key: str = Depends(validate_api_key)
):
    """
    Mengambil jadwal sholat dari Aladhan API.
    """
    start_time = time.time()
    
    params = {"city": city, "country": country}
    try:
        async with BaseCrawler() as crawler:
            data = await crawler.fetch_json(PRAYER_API_URL, params=params)
        
        # Ekstrak dan transformasikan data
        timings_data = data['data']['timings']
        date_data = data['data']['date']['gregorian']['date']
        
        result = PrayerScheduleData(
            city=city,
            country=country,
            date=date.fromisoformat(date_data.replace('-', '')),
            timings=PrayerTimings(**timings_data)
        )
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)
        
    except APIError as e:
        raise HTTPException(status_code=e.status_code, detail=f"Error dari API jadwal sholat: {e.response_text}")
    except (CrawlerError, KeyError) as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal mem-parsing data jadwal sholat: {e}")