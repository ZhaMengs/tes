# /zhadev/app/api/v1/search/douyin.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import DouyinCrawler, ContentNotFoundError, CrawlerError

class DouyinSearchResult(BaseModel):
    title: str
    url: str
    cover_url: str
    author: str
    like_count: int

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[DouyinSearchResult]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mencari video atau pengguna di Douyin",
)
async def search_douyin(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian di Douyin.
    """
    start_time = time.time()
    
    try:
        async with DouyinCrawler() as crawler:
          
          data = await crawler.search(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")