# /zhadev/app/api/v1/search/xiaohongshu.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import XiaohongshuCrawler, ContentNotFoundError, CrawlerError

class XiaohongshuSearchResult(BaseModel):
    note_id: str
    title: str
    cover_url: str
    author_name: str
    author_avatar: str
    likes: int

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[XiaohongshuSearchResult]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mencari postingan (Note) di Xiaohongshu",
)
async def search_xiaohongshu(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian di Xiaohongshu.
    """
    start_time = time.time()
    
    try:
        async with XiaohongshuCrawler() as crawler:
          
            data = await crawler.search(q)
            
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")