# /zhadev/app/api/v1/search/donghub.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import DonghubCrawler, DonghuaSearchResult, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[DonghuaSearchResult]],
    responses={
        404: {"model": ErrorResponse, "description": "Tidak ada hasil yang ditemukan."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mencari Donghua di Donghub.vip",
    description="Masukkan query pencarian untuk mendapatkan daftar Donghua yang relevan."
)
async def search_donghub(
    q: str = Query(..., description="Kata kunci pencarian untuk judul Donghua."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian di Donghub.
    """
    start_time = time.time()
    
    try:
        async with DonghubCrawler() as crawler:
            # Panggil method `search` yang sudah kita definisikan di crawler Donghub
            data = await crawler.search(query=q)
            if not data:
                raise ContentNotFoundError(f"Tidak ada hasil pencarian untuk '{q}' di Donghub.")

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")