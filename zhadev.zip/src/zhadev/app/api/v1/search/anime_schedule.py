# /zhadev/app/api/v1/search/anime_schedule.py

import time
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel
from bs4 import BeautifulSoup

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BaseCrawler, CrawlerError, ParsingError

class AnimeScheduleItem(BaseModel):
    title: str
    url: str
    image_url: str
    synopsis: str
    studio: str
    day: str

router = APIRouter()
MAL_SCHEDULE_URL = "http://googleusercontent.com/myanimelist.net/0"

# Kelas crawler sederhana khusus untuk endpoint ini
class MyAnimeListCrawler(BaseCrawler):
    async def get_full_schedule(self) -> List[AnimeScheduleItem]:
        html = await self.fetch_text(MAL_SCHEDULE_URL)
        soup = BeautifulSoup(html, "html.parser")
        
        schedule_items = []
        day_containers = soup.find_all("div", class_="js-seasonal-broadcast")
        
        for container in day_containers:
            day_name = container.find("div", class_="broadcast-title").text.strip()
            anime_nodes = container.find_all("div", class_="js-anime-category-producer")
            
            for node in anime_nodes:
                try:
                    title_node = node.find("h2", class_="h2_anime_title").find("a")
                    img_node = node.find("div", class_="image").find("img")
                    synopsis_node = node.find("div", class_="synopsis")
                    studio_node = synopsis_node.find_next_sibling("div", class_="properties").find("span", class_="producer")

                    item = AnimeScheduleItem(
                        title=title_node.text.strip(),
                        url=title_node['href'],
                        image_url=img_node['data-src'],
                        synopsis=synopsis_node.text.strip(),
                        studio=studio_node.text.strip(),
                        day=day_name
                    )
                    schedule_items.append(item)
                except (AttributeError, KeyError):
                    continue # Lewati jika ada elemen yang hilang
        return schedule_items

@router.get(
    "/",
    response_model=StandardResponse[List[AnimeScheduleItem]],
    responses={500: {"model": ErrorResponse}},
    summary="Mendapatkan jadwal rilis anime mingguan dari MyAnimeList"
)
async def get_anime_schedule(
    day: Optional[str] = Query(None, description="Filter berdasarkan hari (contoh: 'Mondays', 'Tuesdays'). Case-insensitive."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    try:
        async with MyAnimeListCrawler() as crawler:
            full_schedule = await crawler.get_full_schedule()
        
        if day:
            # Filter hasil jika parameter hari diberikan
            filtered_schedule = [item for item in full_schedule if item.day.lower() == day.lower()]
        else:
            filtered_schedule = full_schedule

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=filtered_schedule, execution_time_ms=execution_time)
        
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal mengambil data dari MyAnimeList: {e}")