# /zhadev/app/api/v1/stalker/__init__.py

from fastapi import APIRouter

# Impor router dari semua file implementasi platform
from . import bstation, bilibili, capcut, douyin
from . import tiktok, facebook, instagram, twitter
from . import xiaohongshu, weibo, youtube, donghub

# Buat router utama untuk semua endpoint stalker
stalker_router = APIRouter()

# --- Batch 1 ---
stalker_router.include_router(bstation.router, prefix="/bstation", tags=["Stalker - Bstation"])
stalker_router.include_router(bilibili.router, prefix="/bilibili", tags=["Stalker - Bilibili"])
stalker_router.include_router(capcut.router, prefix="/capcut", tags=["Stalker - Capcut"])
stalker_router.include_router(douyin.router, prefix="/douyin", tags=["Stalker - Douyin"])

# --- Batch 2 ---
stalker_router.include_router(tiktok.router, prefix="/tiktok", tags=["Stalker - TikTok"])
stalker_router.include_router(facebook.router, prefix="/facebook", tags=["Stalker - Facebook"])
stalker_router.include_router(instagram.router, prefix="/instagram", tags=["Stalker - Instagram"])
stalker_router.include_router(twitter.router, prefix="/twitter", tags=["Stalker - Twitter"])

# --- Batch 3 (Final) ---
stalker_router.include_router(xiaohongshu.router, prefix="/xiaohongshu", tags=["Stalker - Xiaohongshu"])
stalker_router.include_router(weibo.router, prefix="/weibo", tags=["Stalker - Weibo"])
stalker_router.include_router(youtube.router, prefix="/youtube", tags=["Stalker - YouTube"])