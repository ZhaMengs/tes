# /zhadev/app/api/v1/stalker/capcut.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import CapcutCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk data profil kreator CapCut
class CapcutProfileData(BaseModel):
    id: str
    name: str
    avatar_url: str
    follower_count: int
    following_count: int
    template_count: int
    is_verified: bool

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[CapcutProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Kreator tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil kreator dari CapCut",
    description="Masukkan URL profil kreator CapCut untuk mendapatkan informasi detail."
)
async def get_capcut_profile(
    url: str = Query(..., description="URL lengkap profil kreator dari capcut.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil kreator dari CapCut.
    """
    start_time = time.time()
    
    try:
        async with CapcutCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")