# /zhadev/app/api/v1/stalker/twitter.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import TwitterCrawler, ContentNotFoundError, CrawlerError

# Model data yang kaya, karena kita berasumsi menggunakan autentikasi
class TwitterProfileData(BaseModel):
    id: str = Field(..., alias="rest_id")
    username: str = Field(..., alias="screen_name")
    display_name: str = Field(..., alias="name")
    avatar_url: str
    banner_url: Optional[str] = None
    description: str
    location: str
    created_at: str
    follower_count: int
    following_count: int
    tweet_count: int
    is_verified: bool

    class Config:
        allow_population_by_field_name = True

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[TwitterProfileData],
    responses={
        403: {"model": ErrorResponse, "description": "Crawler tidak dikonfigurasi dengan benar (token autentikasi hilang)."},
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Twitter/X (Wajib Autentikasi)",
    description="Memerlukan `auth_token` dan `ct0` yang valid di konfigurasi crawler."
)
async def get_twitter_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari twitter.com atau x.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Twitter/X.
    """
    start_time = time.time()
    
    try:
        async with TwitterCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        if "wajib diisi" in str(e).lower() or "autentikasi" in str(e).lower() or "token" in str(e).lower():
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")