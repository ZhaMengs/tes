# /zhadev/app/api/v1/stalker/facebook.py

import time
from typing import Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import FacebookCrawler, ContentNotFoundError, CrawlerError

# Model ini memiliki banyak field opsional karena data seringkali tidak tersedia tanpa login
class FacebookProfileData(BaseModel):
    id: Optional[str] = None
    name: str
    avatar_url: Optional[str] = None
    url: str
    bio: Optional[str] = None
    follower_count: Optional[int] = None

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[FacebookProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil publik dari Facebook (Terbatas)",
    description="Hanya dapat mengambil informasi yang sangat mendasar (nama & URL) tanpa cookie login. Untuk data lengkap, konfigurasikan cookie di crawler."
)
async def get_facebook_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari facebook.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil publik dari Facebook.
    """
    start_time = time.time()
    
    try:
        async with FacebookCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")