# /zhadev/app/api/v1/stalker/douyin.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import DouyinCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk data profil pengguna Douyin
class DouyinProfileData(BaseModel):
    sec_uid: str
    nickname: str
    unique_id: str
    avatar_url: str
    signature: str
    follower_count: int
    following_count: int
    total_favorited: int # Total likes yang diterima
    aweme_count: int # Jumlah postingan

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[DouyinProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Douyin",
    description="Masukkan URL profil pengguna Douyin untuk mendapatkan informasi detail."
)
async def get_douyin_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari douyin.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Douyin.
    """
    start_time = time.time()
    
    try:
        async with DouyinCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")