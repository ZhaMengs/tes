# /zhadev/app/api/v1/tools/penghitaman.py

import time
import replicate
from enum import Enum
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class SkinTone(str, Enum):
    hitam = "hitam"
    coklat = "coklat"
    nerd = "nerd"
    albino = "albino"
    botak = "botak"

class WpwOutput(BaseModel):
    output_url: str
    prompt_used: str

# ID Model InstructPix2Pix di Replicate
PIX2PIX_MODEL_VERSION = "19b56f2695240502616f7347da5cc9d3514a60e0a5146b00874c5d5e3c153706"

# Mapping dari pilihan simpel ke prompt instruksional yang kompleks
SKIN_TONE_TO_PROMPT = {
    "hitam": "make the person have dark black skin",
    "coklat": "make the person have brown tan skin",
    "nerd": "give the person nerdy glasses and slightly messy hair",
    "albino": "make the person have pale albino skin and white hair",
    "botak": "make the person bald"
}

@router.get(
    "/wpw",
    response_model=StandardResponse[WpwOutput],
    summary="Mengubah tampilan karakter anime (Waifu Penghitaman)",
    description="Menggunakan AI InstructPix2Pix untuk mengedit gambar karakter berdasarkan pilihan `skin`."
)
async def waifu_penghitaman(
    url: str = Query(..., description="URL ke gambar karakter anime (png, jpg)."),
    skin: SkinTone = Query(..., description="Tipe perubahan yang diinginkan."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    # Rekayasa Prompt: Mengubah pilihan simpel menjadi instruksi yang dimengerti AI
    instruction_prompt = SKIN_TONE_TO_PROMPT.get(skin.value)
    if not instruction_prompt:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Tipe skin '{skin.value}' tidak valid.")

    try:
        # Menjalankan model image-to-image di Replicate
        # Outputnya adalah list berisi satu URL gambar
        output = replicate.run(
            f"timothybrooks/instruct-pix2pix:{PIX2PIX_MODEL_VERSION}",
            input={
                "image": url,
                "prompt": instruction_prompt
            }
        )
        
        result = WpwOutput(
            output_url=output[0],
            prompt_used=instruction_prompt
        )
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model editing gambar: {str(e)}")