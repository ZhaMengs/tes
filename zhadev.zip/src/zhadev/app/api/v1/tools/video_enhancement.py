# /zhadev/app/api/v1/tools/video_enhancement.py

import time
import replicate
from enum import Enum
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class VideoType(str, Enum):
    game = "game"
    anime = "anime"
    donghua = "donghua"
    hd = "hd"
    fhd = "fhd"
    ai = "ai"

class ScaleType(str, Enum):
    p1080 = "1080p"
    k2 = "2K"
    k4 = "4K"

class VideoProcessingOutput(BaseModel):
    output_url: str

# ID Model Video Real-ESRGAN di Replicate
VIDEO_ESRGAN_VERSION = "e5e3630d6b1d4512e83b0f5b47a06a5833b2b48bb109e9e248b9ee348f9363a0"

@router.get(
    "/",
    response_model=StandardResponse[VideoProcessingOutput],
    summary="Meningkatkan kualitas dan detail video (Enhance)"
)
async def enhance_video(
    url: str = Query(..., description="URL ke file video (mp4)."),
    type: VideoType = Query(VideoType.hd, description="Tipe video untuk penyesuaian model."),
    scale: ScaleType = Query(ScaleType.k2, description="Target skala output."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    scale_map = {"1080p": "2x", "2K": "2x", "4K": "4x"}

    try:
        output_url = replicate.run(
            f"lucataco/real-esrgan-video:{VIDEO_ESRGAN_VERSION}",
            input={"video_path": url, "scale": scale_map.get(scale, "2x")}
        )
        
        result = VideoProcessingOutput(output_url=output_url)
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model: {str(e)}")