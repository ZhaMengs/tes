# /zhadev/app/api/v1/tools/shipment_tracking.py

import time
import httpx
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()
BITESHIP_API_URL = "http://googleusercontent.com/biteship.com/0"

class TrackingHistory(BaseModel):
    note: str
    updated_at: str
    status: str

class ShipmentTrackingData(BaseModel):
    id: str
    status: str
    courier: str
    waybill_id: str
    origin: str
    destination: str
    history: List[TrackingHistory]

@router.get(
    "/",
    response_model=StandardResponse[ShipmentTrackingData],
    summary="Melacak resi pengiriman berbagai kurir"
)
async def track_shipment(
    courier: str = Query(..., description="Kode kurir (contoh: jne, sicepat, jnt)."),
    resi: str = Query(..., description="Nomor resi pengiriman."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    biteship_key = settings.BITESHIP_API_KEY
    if not biteship_key:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan pelacakan tidak dikonfigurasi.")
        
    headers = {"Authorization": biteship_key}
    track_url = f"{BITESHIP_API_URL}/{courier}/{resi}"
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(track_url, headers=headers)
            response.raise_for_status()
            data = response.json()

        if not data.get('success', False):
            raise ContentNotFoundError(data.get('error', 'Nomor resi tidak ditemukan atau tidak valid.'))

        raw = data['data']
        result = ShipmentTrackingData(
            id=raw['id'], status=raw['status'], courier=f"{raw['courier']['company']} ({raw['courier']['name']})",
            waybill_id=raw['waybill_id'], origin=raw['origin']['contact_name'], destination=raw['destination']['contact_name'],
            history=[TrackingHistory(**h) for h in raw['history']]
        )

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)
        
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"Error dari Biteship API: {e.response.text}")
    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))