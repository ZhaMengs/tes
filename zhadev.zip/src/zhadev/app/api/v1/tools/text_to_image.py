# /zhadev/app/api/v1/tools/text_to_image.py

import time
import replicate
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field
from typing import List, Optional

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class TextToImageInput(BaseModel):
    prompt: str = Field(..., description="Deskripsi detail dari gambar yang ingin dibuat.")
    negative_prompt: Optional[str] = Field("ugly, blurry, low quality", description="Hal-hal yang ingin dihindari dalam gambar.")
    width: int = Field(1024, description="Lebar gambar dalam piksel.")
    height: int = Field(1024, description="Tinggi gambar dalam piksel.")

class TextToImageOutput(BaseModel):
    image_urls: List[str]
    model_version: str

# ID Model Stable Diffusion XL (SDXL) di Replicate
SDXL_MODEL_VERSION = "39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b"

@router.post(
    "/",
    response_model=StandardResponse[TextToImageOutput],
    summary="Membuat gambar dari teks (Text-to-Image)"
)
async def text_to_image(
    request: TextToImageInput,
    api_key: str = Depends(validate_api_key)
):
    """
    Menggunakan model AI Stable Diffusion XL untuk menghasilkan gambar
    berdasarkan deskripsi teks yang diberikan.
    """
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    try:
        # Menjalankan model text-to-image di Replicate
        output = replicate.run(
            f"stability-ai/sdxl:{SDXL_MODEL_VERSION}",
            input={
                "prompt": request.prompt,
                "negative_prompt": request.negative_prompt,
                "width": request.width,
                "height": request.height
            }
        )
        
        result = TextToImageOutput(
            image_urls=output,
            model_version=SDXL_MODEL_VERSION
        )
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model Text-to-Image: {str(e)}")