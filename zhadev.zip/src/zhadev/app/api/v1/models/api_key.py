# /zhadev/app/api/v1/models/api_key.py

import re
from typing import Set

from fastapi import Security, HTTPException, status
from fastapi.security import APIKeyQuery

# Nama parameter di URL, contoh: ?apikey=...
API_KEY_NAME = "apikey"

# Definisikan kunci-kunci gratis Anda di sini
FREE_KEYS: Set[str] = {
    "zhadev_restapi",
    "zhadev_freekey",
    "zhadev_freeapi",
}

# Pola Regex untuk memvalidasi format kunci premium
# ^zhadev-prem- : Diawali dengan "zhadev-prem-"
# [a-zA-Z0-9]{16} : Diikuti oleh 16 karakter alfanumerik (case-sensitive)
# $ : Akhir dari string
PREM_KEY_PATTERN = re.compile(r"^zhadev-prem-[a-zA-Z0-9]{16}$")

# Inisialisasi mekanisme keamanan FastAPI untuk membaca apikey dari query
api_key_query = APIKeyQuery(name=API_KEY_NAME, auto_error=False)

async def validate_api_key(api_key: str = Security(api_key_query)):
    """
    Dependency FastAPI untuk memvalidasi API Key.
    Akan dipanggil di setiap endpoint yang memerlukan autentikasi.
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API Key tidak ditemukan. Silakan sertakan parameter 'apikey'.",
        )

    # Cek apakah kunci ada di daftar FREE_KEYS atau cocok dengan pola PREM_KEY
    if api_key in FREE_KEYS or PREM_KEY_PATTERN.match(api_key):
        return api_key  # Validasi berhasil, kembalikan kunci
    else:
        # Jika tidak valid, tolak permintaan
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API Key yang Anda berikan tidak valid atau tidak sah.",
        )