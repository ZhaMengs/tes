# /zhadev/app/api/v1/downloader/spotify.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import SpotifyCrawler, TrackInfo, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/track",
    response_model=StandardResponse[TrackInfo],
    responses={
        404: {"model": ErrorResponse, "description": "Lagu tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil metadata lagu (Track) dari Spotify",
    description="Masukkan URL lagu Spotify untuk mendapatkan metadata lengkap via API resmi, termasuk `preview_url` (MP3 30 detik)."
)
async def get_spotify_track_data(
    url: str = Query(..., description="URL lengkap lagu dari open.spotify.com/track/."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mendapatkan detail lagu dari Spotify.
    """
    start_time = time.time()
    
    try:
        # Spotify crawler tidak perlu `async with` karena kliennya dikelola secara internal
        crawler = SpotifyCrawler()
        data = await crawler.get_track_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")