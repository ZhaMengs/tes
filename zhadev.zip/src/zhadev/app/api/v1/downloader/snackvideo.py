# /zhadev/app/api/v1/downloader/snackvideo.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import SnackVideoCrawler, SnackVideoData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[SnackVideoData],
    responses={
        404: {"model": ErrorResponse, "description": "Konten tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data video dari SnackVideo",
    description="Masukkan URL video SnackVideo (termasuk URL pendek sck.io) untuk mendapatkan metadata lengkap dan link unduhan."
)
async def get_snackvideo_data(
    url: str = Query(..., description="URL lengkap video dari snackvideo.com atau sck.io."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi video dari SnackVideo.
    """
    start_time = time.time()
    
    try:
        async with SnackVideoCrawler() as crawler:
            data = await crawler.get_video_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")