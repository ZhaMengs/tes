# /zhadev/app/api/v1/downloader/mediafire.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import MediafireCrawler, MediafireFileData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[MediafireFileData],
    responses={
        404: {"model": ErrorResponse, "description": "File tidak ditemukan atau link tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil link unduhan langsung dari MediaFire",
    description="Masukkan URL file MediaFire untuk mendapatkan metadata dan link unduhan langsung."
)
async def get_mediafire_data(
    url: str = Query(..., description="URL lengkap file dari mediafire.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak link unduhan langsung dari MediaFire.
    """
    start_time = time.time()
    
    try:
        async with MediafireCrawler() as crawler:
            data = await crawler.get_download_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")