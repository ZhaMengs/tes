# /zhadev/app/api/v1/downloader/facebook.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import FacebookCrawler, FacebookVideoData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[FacebookVideoData],
    responses={
        404: {"model": ErrorResponse, "description": "Konten tidak ditemukan, bersifat privat, atau memerlukan cookie login."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data video publik dari Facebook",
    description="Masukkan URL video Facebook publik untuk mendapatkan metadata dan link unduhan stream SD/HD."
)
async def get_facebook_data(
    url: str = Query(..., description="URL lengkap video dari facebook.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi video publik dari Facebook.
    """
    start_time = time.time()
    
    try:
        async with FacebookCrawler() as crawler:
            data = await crawler.get_video_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")