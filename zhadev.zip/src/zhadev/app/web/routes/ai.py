# /zhadev/app/web/routes/ai.py

import httpx
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

# Asumsi API berjalan di localhost:8000
API_BASE_URL = "http://localhost:8000/api/v1"
# Gunakan salah satu API key gratis Anda untuk web UI
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman AI Assistant."""
    set_env(title="ZhaDev Tools - AI Assistant")
    render_navbar(active_page='ai')
    put_html("<h1 align='center'><strong>AI Assistant</strong></h1>")
    
    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            data = await input_group("Kirim prompt ke model AI", [
                select("Pilih Model AI", name="model", options=["gemini", "claude", "chatgpt4", "deepseek"]),
                textarea("Masukkan Prompt Anda", name="prompt", required=True, placeholder="Contoh: Apa itu FastAPI?"),
            ])
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')
            put_text("AI sedang berpikir...", align='center')

        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    f"{API_BASE_URL}/ai/{data['model']}/?apikey={INTERNAL_API_KEY}",
                    json={"prompt": data['prompt']}
                )
                response.raise_for_status()
                result = response.json()
                
            with use_scope("result_scope", clear=True):
                put_markdown("### Jawaban dari AI:")
                put_markdown(result['data']['text'])

        except httpx.HTTPStatusError as e:
            with use_scope("result_scope", clear=True):
                put_error(f"Error {e.response.status_code}", f"Gagal menghubungi API: {e.response.text}")
        except Exception as e:
            with use_scope("result_scope", clear=True):
                put_error("Terjadi Kesalahan", str(e))
        
        run_js('document.getElementById("pywebio-scope-form_scope").scrollIntoView()')