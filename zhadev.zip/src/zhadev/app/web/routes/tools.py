# /zhadev/app/web/routes/tools.py

import httpx
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/tools"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Tools."""
    set_env(title="ZhaDev Tools - AI Tools")
    render_navbar(active_page='tools')
    put_html("<h1 align='center'><strong>AI-Powered Tools</strong></h1>")
    
    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            tool = await select("Pilih Alat AI", options=[
                ("Buat Gambar dari Teks", "text2img"),
                ("Hapus Vokal dari Audio", "vocal-remover"),
                ("Tingkatkan Resolusi Gambar (Remini)", "remini"),
                ("Hapus Latar Belakang Gambar", "remove-bg"),
                ("Ubah Tampilan Waifu (WPW)", "wpw"),
                ("Baca Teks dari Gambar (OCR)", "ocr"),
            ])

        # Form dinamis berdasarkan pilihan
        if tool == "text2img":
            data = await input_group("Text-to-Image", [
                textarea("Prompt", name="prompt", required=True, placeholder="A beautiful anime girl standing in a neon-lit city"),
                input("Negative Prompt", name="negative_prompt", value="ugly, blurry"),
            ])
            await run_tool(tool, data)
        elif tool == "wpw":
            data = await input_group("Waifu Penghitaman", [
                input("URL Gambar Waifu", name="url", type="url", required=True),
                select("Pilih Efek", name="skin", options=["hitam", "coklat", "nerd", "albino", "botak"])
            ])
            await run_tool(tool, data)
        else: # Untuk tool lain yang hanya butuh URL
            endpoint_map = {"vocal-remover": "/audio/vocal-remover", "remini": "/remini/", "remove-bg": "/remove-bg/", "ocr": "/ocr/"}
            data = await input_group(tool, [
                input("URL Media (Gambar/Audio)", name="url", type="url", required=True)
            ])
            await run_tool(endpoint_map[tool], data)

async def run_tool(endpoint, data):
    with use_scope("result_scope", clear=True):
        put_loading(shape='grow')
        put_text(f"Memproses dengan model AI... Ini mungkin memakan waktu beberapa saat.", align='center')

    try:
        # Tentukan metode dan payload
        if endpoint == "text2img":
            method = "POST"
            api_url = f"{API_BASE_URL}/text2img/?apikey={INTERNAL_API_KEY}"
            payload = {"json": data}
        else:
            method = "GET"
            api_url = f"{API_BASE_URL}{endpoint}"
            payload = {"params": {**data, "apikey": INTERNAL_API_KEY}}

        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.request(method, api_url, **payload)
            response.raise_for_status()
            result = response.json()['data']

        with use_scope("result_scope", clear=True):
            put_success("Proses Selesai!")
            if 'output_url' in result or 'image_urls' in result:
                urls = result.get('image_urls', [result.get('output_url')])
                put_image(urls[0])
            elif 'vocals_url' in result:
                put_table([
                    ['Vokal', put_link("Unduh Vokal", result['vocals_url'], new_window=True)],
                    ['Instrumental', put_link("Unduh Instrumental", result['instrumental_url'], new_window=True)],
                ])
            else:
                put_code(json.dumps(result, indent=2), 'json')

    except Exception as e:
        with use_scope("result_scope", clear=True):
            error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
            put_error("Terjadi Kesalahan", str(error_detail))