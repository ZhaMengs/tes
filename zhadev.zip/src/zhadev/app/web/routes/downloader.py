# /zhadev/app/web/routes/downloader.py

import httpx
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env

from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/downloader"
INTERNAL_API_KEY = "zhadev_restapi"

PLATFORM_MAP = {
    "douyin.com": "douyin", "tiktok.com": "tiktok", "vm.tiktok.com": "tiktok",
    "bilibili.com": "bilibili", "bilibili.tv": "bstation", "b23.tv": "bilibili",
    "instagram.com": "instagram", "threads.net": "threads",
    "youtube.com": "youtube", "youtu.be": "youtube", "twitter.com": "twitter", "x.com": "twitter",
    # ... tambahkan domain lain yang relevan
}

async def app():
    """Aplikasi PyWebIO untuk halaman Downloader."""
    set_env(title="ZhaDev Tools - Universal Downloader")
    render_navbar(active_page='downloader')
    put_html("<h1 align='center'><strong>Universal Content Downloader</strong></h1>")

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input("Masukkan URL Konten", type="text", required=True,
                              placeholder="Contoh: https://www.tiktok.com/@username/video/123...")
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')
            put_text("Menganalisis URL dan mengambil data...", align='center')

        try:
            domain = urlparse(url).hostname.replace("www.", "")
            platform = None
            for key, value in PLATFORM_MAP.items():
                if key in domain:
                    platform = value
                    break
            
            if not platform:
                raise ValueError(f"Platform untuk domain '{domain}' tidak didukung atau tidak terdaftar.")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                put_success("Data Berhasil Diambil!")
                # Tampilkan data dalam format JSON yang rapi
                put_code(json.dumps(result['data'], indent=2), language='json')

        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
                put_error("Terjadi Kesalahan", str(error_detail))