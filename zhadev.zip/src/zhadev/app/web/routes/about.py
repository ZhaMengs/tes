# /zhadev/app/web/routes/about.py

from pywebio.output import *
from pywebio.session import set_env
from .utils import render_navbar
from ....version import __version__

async def app():
    """Halaman "About" untuk aplikasi ZhaDev."""
    set_env(title="ZhaDev Tools - About")
    render_navbar(active_page='about')

    put_html("<h1><img src='https://zhadev.my.id/wp-content/uploads/2024/07/Zha-1-1.png' width='50px' style='vertical-align: middle;'> About ZhaDev Project</h1>")
    put_markdown(f"**Versi Aplikasi:** `{__version__}`")
    put_markdown("""
    Proyek ini adalah demonstrasi pembuatan RESTful API dan antarmuka web yang komprehensif menggunakan Python.
    
    ## Teknologi yang Digunakan
    - **Backend API**: **FastAPI**
    - **Antarmuka Web**: **PyWebIO**
    - **HTTP Client (Crawler)**: **HTTPX**
    - **AI & Tools**: Berbagai API pihak ketiga (Replicate, OpenAI, dll.)
    
    Proyek ini dirancang untuk menjadi modular, kuat, dan mudah diperluas. Setiap *crawler* dan *endpoint* dibuat dengan penanganan *error* dan validasi data yang cermat.
    """)

    put_table(
        header=["Komponen", "Deskripsi"],
        tdata=[
            ["`/crawlers`", "Lapisan pengambilan data, berisi logika untuk setiap platform."],
            ["`/app/api`", "Lapisan RESTful API yang mengekspos fungsionalitas ke publik."],
            ["`/app/web`", "Lapisan antarmuka pengguna interaktif yang Anda gunakan sekarang."],
        ]
    )