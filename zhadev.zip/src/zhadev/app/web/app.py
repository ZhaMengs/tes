from pywebio.platform.fastapi import webio_routes
from pywebio.session import go_app

# Impor semua fungsi aplikasi dari direktori routes
from .routes import (
    about, ai, downloader, random, stalker, documentation, 
    easter_egg, tools, search, parser, shortcuts
)

# Halaman default, langsung arahkan ke downloader.
def index():
    """Halaman utama, langsung arahkan ke aplikasi downloader."""
    go_app('downloader', new_window=False)

# Gabungkan semua fungsi aplikasi PyWebIO menjadi satu router FastAPI.
web_router = webio_routes(applications={
    'index': index, # Halaman root
    'about': about.app,
    'ai': ai.app,
    'downloader': downloader.app,
    'random': random.app,
    'stalker': stalker.app,
    'documentation': documentation.app,
    'easter_egg': easter_egg.app,
    'tools': tools.app,
    'search': search.app,
    'parser': parser.app,
    'shortcuts': shortcuts.app, # Endpoint khusus untuk iOS Shortcuts
})