# zhadev/src/zhadev/cli/utils.py

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.spinner import Spinner
from typing import List, Any
import time

from ...crawlers.platforms.douyin.models import DouyinVideoData
from ...crawlers.platforms.bilibili.models import BilibiliVideoData
# ... (impor model data bersih dari setiap crawler)

console = Console()

def display_results(data: Any):
    """
    Fungsi dispatcher untuk menampilkan data dalam format tabel yang sesuai.
    """
    if isinstance(data, DouyinVideoData):
        _display_douyin_table(data)
    elif isinstance(data, BilibiliVideoData):
        _display_bilibili_table(data)
    # ... (tambahkan elif untuk setiap tipe data crawler lainnya)
    else:
        console.print(data) # Fallback ke print biasa jika tidak ada format tabel

def _display_douyin_table(data: DouyinVideoData):
    """Menampilkan data Douyin dalam format tabel Rich."""
    table = Table(title=f"[bold cyan]Hasil Crawling Douyin[/bold cyan]", show_header=False)
    table.add_column("Key", style="magenta", no_wrap=True)
    table.add_column("Value", style="green")

    table.add_row("Deskripsi", data.description)
    table.add_row("Author", data.author.nickname)
    table.add_row("Likes", str(data.statistics.likes))
    table.add_row("Komentar", str(data.statistics.comments))
    table.add_row("Cover", f"[link={data.cover_image_url}]Link Gambar[/link]")
    table.add_row("[bold]Video (No WM)[/bold]", f"[link={data.video_without_watermark.url}]Link Video[/link]")
    
    console.print(table)
    
def _display_bilibili_table(data: BilibiliVideoData):
    """Menampilkan data Bilibili dalam format tabel Rich."""
    table = Table(title=f"[bold blue]Hasil Crawling Bilibili[/bold blue]", show_header=False)
    table.add_column("Key", style="magenta", no_wrap=True)
    table.add_column("Value", style="green")

    table.add_row("Judul", data.title)
    table.add_row("Deskripsi", data.description[:100] + "..." if data.description else "")
    table.add_row("Author", data.author.name)
    table.add_row("Views", str(data.statistics.views))
    table.add_row("Likes", str(data.statistics.likes))
    table.add_row("Cover", f"[link={data.cover_url}]Link Gambar[/link]")
    
    stream_table = Table(title="Video Streams Available")
    stream_table.add_column("Kualitas", style="cyan")
    stream_table.add_column("Codec", style="yellow")
    stream_table.add_column("URL", style="green")
    
    for stream in data.video_streams[:3]: # Tampilkan 3 stream terbaik
        stream_table.add_row(f"{stream.height}p", stream.codecs, f"[link={stream.url}]Link[/link]")

    console.print(table)
    console.print(stream_table)