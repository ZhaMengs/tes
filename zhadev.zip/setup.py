from setuptools import setup, find_packages

if name == "main":

setup(
packages=find_packages(where="src"),
package_dir={"": "src"},
)